﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sunat.Logica
{
   public class Ltiponotacredito
    {
        public int id { get; set; }
        public string codigo { get; set; }
        public string descripcion  { get; set; }
    }
}
