﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sunat.Logica
{
   public  class Lcombaja
    {
       public int Idventa { get; set; }
        public string Ticket { get; set; }
        public string Estadosunat { get; set; }
        public int IdcomBaja { get; set; }
        public string codigo { get; set; }
    }
}
