﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sunat.Logica
{
   public class Lserializacion
    {
        public int Id_serializacion { get; set; }
        public string Serie { get; set; }
        public string Cantidadnumeros { get; set; }
        public string numerofin { get; set; }
        public string destino { get; set; }
        public string tipodoc { get; set; }
        public string pordefecto { get; set; }
        public string codigo { get; set; }
        public string Envioinmediato { get; set; }

    }
}
