﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sunat.Logica
{
 public   class Lclientes
    {
        public int idcliente { set; get; }
        public string Nombre { set; get; }
        public string Direccion { set; get; }
        public string Nrodoc { set; get; }
        public string Celular { set; get; }
        public string Estado { set; get; }
        public double Saldo { set; get; }
        public string Tipodoc { set; get; }
    }
}
