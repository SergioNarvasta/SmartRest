﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sunat.Logica
{
  public  class Lnotacredito
    {
        public int idventa { get; set; }
        public string serie { get; set; }
        public string correlativo { get; set; }
        public string estadosunat { get; set; }
        public int idcomprobante { get; set; }
        public string codTiponc { get; set; }

    }
}
