﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sunat.Logica
{
   public class Lnotasdebito
    {
        public int tipond { get; set; }
        public string codigo { get; set; }
        public string descripcion { get; set; }
        public int idventa { get; set; }
        public string serie { get; set; }
        public string correlativo { get; set; }
        public string estadosunat { get; set; }
        public int idcomprobante { get; set; }
        public string codTipond { get; set; }

    }
}
