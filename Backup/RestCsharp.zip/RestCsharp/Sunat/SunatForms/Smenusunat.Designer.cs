﻿
namespace RestCsharp.Sunat.SunatForms
{
    partial class Smenusunat
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panelbotones = new System.Windows.Forms.FlowLayoutPanel();
            this.btnSunat = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnNotascredito = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.panelVisor = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panelbotones.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.panel1.Controls.Add(this.panelbotones);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(858, 85);
            this.panel1.TabIndex = 5;
            // 
            // panelbotones
            // 
            this.panelbotones.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
            this.panelbotones.Controls.Add(this.btnSunat);
            this.panelbotones.Controls.Add(this.button2);
            this.panelbotones.Controls.Add(this.btnNotascredito);
            this.panelbotones.Controls.Add(this.button3);
            this.panelbotones.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelbotones.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.panelbotones.Location = new System.Drawing.Point(0, 0);
            this.panelbotones.Name = "panelbotones";
            this.panelbotones.Size = new System.Drawing.Size(858, 85);
            this.panelbotones.TabIndex = 1;
            // 
            // btnSunat
            // 
            this.btnSunat.BackColor = System.Drawing.Color.Transparent;
            this.btnSunat.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSunat.FlatAppearance.BorderSize = 0;
            this.btnSunat.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnSunat.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnSunat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSunat.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSunat.ForeColor = System.Drawing.Color.White;
            this.btnSunat.Location = new System.Drawing.Point(3, 3);
            this.btnSunat.Name = "btnSunat";
            this.btnSunat.Size = new System.Drawing.Size(153, 69);
            this.btnSunat.TabIndex = 633;
            this.btnSunat.Text = "Facturas por enviar";
            this.btnSunat.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(162, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(153, 69);
            this.button2.TabIndex = 634;
            this.button2.Text = "Facturas emitidas";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // btnNotascredito
            // 
            this.btnNotascredito.BackColor = System.Drawing.Color.Transparent;
            this.btnNotascredito.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnNotascredito.FlatAppearance.BorderSize = 0;
            this.btnNotascredito.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnNotascredito.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnNotascredito.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNotascredito.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNotascredito.ForeColor = System.Drawing.Color.White;
            this.btnNotascredito.Location = new System.Drawing.Point(321, 3);
            this.btnNotascredito.Name = "btnNotascredito";
            this.btnNotascredito.Size = new System.Drawing.Size(153, 69);
            this.btnNotascredito.TabIndex = 632;
            this.btnNotascredito.Text = "Notas de credito";
            this.btnNotascredito.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(480, 3);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(153, 69);
            this.button3.TabIndex = 635;
            this.button3.Text = "Notas de debito";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // panelVisor
            // 
            this.panelVisor.BackColor = System.Drawing.Color.Transparent;
            this.panelVisor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelVisor.Location = new System.Drawing.Point(0, 87);
            this.panelVisor.Name = "panelVisor";
            this.panelVisor.Size = new System.Drawing.Size(858, 423);
            this.panelVisor.TabIndex = 6;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 85);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(858, 2);
            this.panel2.TabIndex = 7;
            // 
            // Smenusunat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
            this.Controls.Add(this.panelVisor);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Smenusunat";
            this.Size = new System.Drawing.Size(858, 510);
            this.Load += new System.EventHandler(this.Smenusunat_Load);
            this.panel1.ResumeLayout(false);
            this.panelbotones.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.FlowLayoutPanel panelbotones;
        private System.Windows.Forms.Button btnSunat;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnNotascredito;
        private System.Windows.Forms.Button button3;
        public System.Windows.Forms.Panel panelVisor;
        private System.Windows.Forms.Panel panel2;
    }
}
