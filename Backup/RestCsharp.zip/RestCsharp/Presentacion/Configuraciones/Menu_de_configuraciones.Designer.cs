﻿namespace RestCsharp.Presentacion.Configuraciones
{
    partial class Menu_de_configuraciones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu_de_configuraciones));
            this.panel1 = new System.Windows.Forms.Panel();
            this.PanelContenedor = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.btnlicencia = new System.Windows.Forms.Button();
            this.btnrestaurar = new System.Windows.Forms.Button();
            this.btncopia = new System.Windows.Forms.Button();
            this.btnSerie = new System.Windows.Forms.Button();
            this.Label3 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.btnImpresoras = new System.Windows.Forms.Button();
            this.btnformatoticket = new System.Windows.Forms.Button();
            this.btnReportes = new System.Windows.Forms.Button();
            this.Label2 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btnsalir = new System.Windows.Forms.Button();
            this.btnClientes = new System.Windows.Forms.Button();
            this.btnempresa = new System.Windows.Forms.Button();
            this.btnproductos = new System.Windows.Forms.Button();
            this.btnmesas = new System.Windows.Forms.Button();
            this.btnusuarios = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dlg = new System.Windows.Forms.OpenFileDialog();
            this.panel1.SuspendLayout();
            this.PanelContenedor.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.PanelContenedor);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1095, 737);
            this.panel1.TabIndex = 0;
            // 
            // PanelContenedor
            // 
            this.PanelContenedor.BackColor = System.Drawing.Color.Transparent;
            this.PanelContenedor.Controls.Add(this.panel9);
            this.PanelContenedor.Controls.Add(this.panel8);
            this.PanelContenedor.Controls.Add(this.panel7);
            this.PanelContenedor.Location = new System.Drawing.Point(44, 3);
            this.PanelContenedor.Name = "PanelContenedor";
            this.PanelContenedor.Size = new System.Drawing.Size(919, 716);
            this.PanelContenedor.TabIndex = 0;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Transparent;
            this.panel9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel9.Controls.Add(this.btnlicencia);
            this.panel9.Controls.Add(this.btnrestaurar);
            this.panel9.Controls.Add(this.btncopia);
            this.panel9.Controls.Add(this.btnSerie);
            this.panel9.Controls.Add(this.Label3);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel9.Location = new System.Drawing.Point(588, 0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(294, 716);
            this.panel9.TabIndex = 6;
            // 
            // btnlicencia
            // 
            this.btnlicencia.BackColor = System.Drawing.Color.Transparent;
            this.btnlicencia.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnlicencia.BackgroundImage")));
            this.btnlicencia.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnlicencia.FlatAppearance.BorderSize = 0;
            this.btnlicencia.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnlicencia.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnlicencia.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnlicencia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnlicencia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnlicencia.ForeColor = System.Drawing.Color.White;
            this.btnlicencia.Location = new System.Drawing.Point(51, 435);
            this.btnlicencia.Name = "btnlicencia";
            this.btnlicencia.Size = new System.Drawing.Size(192, 54);
            this.btnlicencia.TabIndex = 541;
            this.btnlicencia.Text = "Licencia";
            this.btnlicencia.UseVisualStyleBackColor = false;
            this.btnlicencia.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnrestaurar
            // 
            this.btnrestaurar.BackColor = System.Drawing.Color.Transparent;
            this.btnrestaurar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnrestaurar.BackgroundImage")));
            this.btnrestaurar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnrestaurar.FlatAppearance.BorderSize = 0;
            this.btnrestaurar.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnrestaurar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnrestaurar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnrestaurar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnrestaurar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnrestaurar.ForeColor = System.Drawing.Color.White;
            this.btnrestaurar.Location = new System.Drawing.Point(51, 373);
            this.btnrestaurar.Name = "btnrestaurar";
            this.btnrestaurar.Size = new System.Drawing.Size(192, 54);
            this.btnrestaurar.TabIndex = 540;
            this.btnrestaurar.Text = "Restaurar base de datos";
            this.btnrestaurar.UseVisualStyleBackColor = false;
            this.btnrestaurar.Click += new System.EventHandler(this.btnrestaurar_Click);
            // 
            // btncopia
            // 
            this.btncopia.BackColor = System.Drawing.Color.Transparent;
            this.btncopia.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btncopia.BackgroundImage")));
            this.btncopia.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btncopia.FlatAppearance.BorderSize = 0;
            this.btncopia.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btncopia.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btncopia.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btncopia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncopia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btncopia.ForeColor = System.Drawing.Color.White;
            this.btncopia.Location = new System.Drawing.Point(51, 304);
            this.btncopia.Name = "btncopia";
            this.btncopia.Size = new System.Drawing.Size(192, 54);
            this.btncopia.TabIndex = 539;
            this.btncopia.Text = "Generar copia de seguridad";
            this.btncopia.UseVisualStyleBackColor = false;
            this.btncopia.Click += new System.EventHandler(this.btncopia_Click);
            // 
            // btnSerie
            // 
            this.btnSerie.BackColor = System.Drawing.Color.Transparent;
            this.btnSerie.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSerie.BackgroundImage")));
            this.btnSerie.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSerie.FlatAppearance.BorderSize = 0;
            this.btnSerie.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnSerie.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnSerie.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnSerie.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSerie.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnSerie.ForeColor = System.Drawing.Color.White;
            this.btnSerie.Location = new System.Drawing.Point(51, 235);
            this.btnSerie.Name = "btnSerie";
            this.btnSerie.Size = new System.Drawing.Size(192, 54);
            this.btnSerie.TabIndex = 538;
            this.btnSerie.Text = "Serializacion de Comprobantes";
            this.btnSerie.UseVisualStyleBackColor = false;
            this.btnSerie.Click += new System.EventHandler(this.btnSerie_Click);
            // 
            // Label3
            // 
            this.Label3.BackColor = System.Drawing.Color.Transparent;
            this.Label3.Dock = System.Windows.Forms.DockStyle.Top;
            this.Label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.ForeColor = System.Drawing.Color.White;
            this.Label3.Location = new System.Drawing.Point(0, 0);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(294, 327);
            this.Label3.TabIndex = 1;
            this.Label3.Text = "Operadores";
            this.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Transparent;
            this.panel8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel8.Controls.Add(this.btnImpresoras);
            this.panel8.Controls.Add(this.btnformatoticket);
            this.panel8.Controls.Add(this.btnReportes);
            this.panel8.Controls.Add(this.Label2);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel8.Location = new System.Drawing.Point(294, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(294, 716);
            this.panel8.TabIndex = 5;
            // 
            // btnImpresoras
            // 
            this.btnImpresoras.BackColor = System.Drawing.Color.Transparent;
            this.btnImpresoras.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnImpresoras.BackgroundImage")));
            this.btnImpresoras.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnImpresoras.FlatAppearance.BorderSize = 0;
            this.btnImpresoras.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnImpresoras.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnImpresoras.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnImpresoras.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnImpresoras.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnImpresoras.ForeColor = System.Drawing.Color.White;
            this.btnImpresoras.Location = new System.Drawing.Point(51, 373);
            this.btnImpresoras.Name = "btnImpresoras";
            this.btnImpresoras.Size = new System.Drawing.Size(192, 54);
            this.btnImpresoras.TabIndex = 539;
            this.btnImpresoras.Text = "Impresoras";
            this.btnImpresoras.UseVisualStyleBackColor = false;
            this.btnImpresoras.Click += new System.EventHandler(this.btnImpresoras_Click);
            // 
            // btnformatoticket
            // 
            this.btnformatoticket.BackColor = System.Drawing.Color.Transparent;
            this.btnformatoticket.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnformatoticket.BackgroundImage")));
            this.btnformatoticket.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnformatoticket.FlatAppearance.BorderSize = 0;
            this.btnformatoticket.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnformatoticket.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnformatoticket.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnformatoticket.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnformatoticket.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnformatoticket.ForeColor = System.Drawing.Color.White;
            this.btnformatoticket.Location = new System.Drawing.Point(51, 304);
            this.btnformatoticket.Name = "btnformatoticket";
            this.btnformatoticket.Size = new System.Drawing.Size(192, 54);
            this.btnformatoticket.TabIndex = 538;
            this.btnformatoticket.Text = "Formato de Ticket";
            this.btnformatoticket.UseVisualStyleBackColor = false;
            this.btnformatoticket.Click += new System.EventHandler(this.btnformatoticket_Click);
            // 
            // btnReportes
            // 
            this.btnReportes.BackColor = System.Drawing.Color.Transparent;
            this.btnReportes.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnReportes.BackgroundImage")));
            this.btnReportes.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnReportes.FlatAppearance.BorderSize = 0;
            this.btnReportes.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnReportes.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnReportes.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnReportes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReportes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnReportes.ForeColor = System.Drawing.Color.White;
            this.btnReportes.Location = new System.Drawing.Point(51, 235);
            this.btnReportes.Name = "btnReportes";
            this.btnReportes.Size = new System.Drawing.Size(192, 54);
            this.btnReportes.TabIndex = 537;
            this.btnReportes.Text = "Reportes";
            this.btnReportes.UseVisualStyleBackColor = false;
            this.btnReportes.Click += new System.EventHandler(this.btnReportes_Click);
            // 
            // Label2
            // 
            this.Label2.BackColor = System.Drawing.Color.Transparent;
            this.Label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.Label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.ForeColor = System.Drawing.Color.White;
            this.Label2.Location = new System.Drawing.Point(0, 0);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(294, 327);
            this.Label2.TabIndex = 1;
            this.Label2.Text = "Herramientas";
            this.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel7
            // 
            this.panel7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel7.Controls.Add(this.btnsalir);
            this.panel7.Controls.Add(this.btnClientes);
            this.panel7.Controls.Add(this.btnempresa);
            this.panel7.Controls.Add(this.btnproductos);
            this.panel7.Controls.Add(this.btnmesas);
            this.panel7.Controls.Add(this.btnusuarios);
            this.panel7.Controls.Add(this.label1);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(294, 716);
            this.panel7.TabIndex = 0;
            // 
            // btnsalir
            // 
            this.btnsalir.BackgroundImage = global::RestCsharp.Properties.Resources.naranja;
            this.btnsalir.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnsalir.FlatAppearance.BorderSize = 0;
            this.btnsalir.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnsalir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnsalir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsalir.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsalir.ForeColor = System.Drawing.Color.White;
            this.btnsalir.Location = new System.Drawing.Point(3, 49);
            this.btnsalir.Name = "btnsalir";
            this.btnsalir.Size = new System.Drawing.Size(117, 50);
            this.btnsalir.TabIndex = 1;
            this.btnsalir.Text = "Volver";
            this.btnsalir.UseVisualStyleBackColor = true;
            this.btnsalir.Click += new System.EventHandler(this.btnsalir_Click);
            // 
            // btnClientes
            // 
            this.btnClientes.BackColor = System.Drawing.Color.Transparent;
            this.btnClientes.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnClientes.BackgroundImage")));
            this.btnClientes.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnClientes.FlatAppearance.BorderSize = 0;
            this.btnClientes.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnClientes.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnClientes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClientes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnClientes.ForeColor = System.Drawing.Color.White;
            this.btnClientes.Location = new System.Drawing.Point(50, 512);
            this.btnClientes.Name = "btnClientes";
            this.btnClientes.Size = new System.Drawing.Size(192, 54);
            this.btnClientes.TabIndex = 542;
            this.btnClientes.Text = "Clientes";
            this.btnClientes.UseVisualStyleBackColor = false;
            this.btnClientes.Click += new System.EventHandler(this.btnClientes_Click);
            // 
            // btnempresa
            // 
            this.btnempresa.BackColor = System.Drawing.Color.Transparent;
            this.btnempresa.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnempresa.BackgroundImage")));
            this.btnempresa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnempresa.FlatAppearance.BorderSize = 0;
            this.btnempresa.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnempresa.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnempresa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnempresa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnempresa.ForeColor = System.Drawing.Color.White;
            this.btnempresa.Location = new System.Drawing.Point(50, 443);
            this.btnempresa.Name = "btnempresa";
            this.btnempresa.Size = new System.Drawing.Size(192, 54);
            this.btnempresa.TabIndex = 541;
            this.btnempresa.Text = "Empresa";
            this.btnempresa.UseVisualStyleBackColor = false;
            this.btnempresa.Click += new System.EventHandler(this.btnempresa_Click);
            // 
            // btnproductos
            // 
            this.btnproductos.BackColor = System.Drawing.Color.Transparent;
            this.btnproductos.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnproductos.BackgroundImage")));
            this.btnproductos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnproductos.FlatAppearance.BorderSize = 0;
            this.btnproductos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnproductos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnproductos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnproductos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnproductos.ForeColor = System.Drawing.Color.White;
            this.btnproductos.Location = new System.Drawing.Point(50, 373);
            this.btnproductos.Name = "btnproductos";
            this.btnproductos.Size = new System.Drawing.Size(192, 54);
            this.btnproductos.TabIndex = 540;
            this.btnproductos.Text = "Productos";
            this.btnproductos.UseVisualStyleBackColor = false;
            this.btnproductos.Click += new System.EventHandler(this.btnproductos_Click);
            // 
            // btnmesas
            // 
            this.btnmesas.BackColor = System.Drawing.Color.Transparent;
            this.btnmesas.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnmesas.BackgroundImage")));
            this.btnmesas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnmesas.FlatAppearance.BorderSize = 0;
            this.btnmesas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnmesas.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnmesas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnmesas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnmesas.ForeColor = System.Drawing.Color.White;
            this.btnmesas.Location = new System.Drawing.Point(50, 304);
            this.btnmesas.Name = "btnmesas";
            this.btnmesas.Size = new System.Drawing.Size(192, 54);
            this.btnmesas.TabIndex = 539;
            this.btnmesas.Text = "Mesas";
            this.btnmesas.UseVisualStyleBackColor = false;
            this.btnmesas.Click += new System.EventHandler(this.btnmesas_Click);
            // 
            // btnusuarios
            // 
            this.btnusuarios.BackColor = System.Drawing.Color.Transparent;
            this.btnusuarios.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.btnusuarios.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnusuarios.FlatAppearance.BorderSize = 0;
            this.btnusuarios.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnusuarios.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnusuarios.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnusuarios.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnusuarios.ForeColor = System.Drawing.Color.White;
            this.btnusuarios.Location = new System.Drawing.Point(50, 235);
            this.btnusuarios.Name = "btnusuarios";
            this.btnusuarios.Size = new System.Drawing.Size(192, 54);
            this.btnusuarios.TabIndex = 537;
            this.btnusuarios.Text = "Usuarios";
            this.btnusuarios.UseVisualStyleBackColor = false;
            this.btnusuarios.Click += new System.EventHandler(this.btnusuarios_Click);
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(294, 327);
            this.label1.TabIndex = 0;
            this.label1.Text = "Basicos";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dlg
            // 
            this.dlg.FileName = "openFileDialog1";
            // 
            // Menu_de_configuraciones
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Name = "Menu_de_configuraciones";
            this.Size = new System.Drawing.Size(1095, 737);
            this.Load += new System.EventHandler(this.Menu_de_configuraciones_Load);
            this.panel1.ResumeLayout(false);
            this.PanelContenedor.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel PanelContenedor;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label1;
        internal System.Windows.Forms.Panel panel9;
        internal System.Windows.Forms.Button btnSerie;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Panel panel8;
        internal System.Windows.Forms.Button btnImpresoras;
        internal System.Windows.Forms.Button btnformatoticket;
        internal System.Windows.Forms.Button btnReportes;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Button btnproductos;
        internal System.Windows.Forms.Button btnmesas;
        internal System.Windows.Forms.Button btnusuarios;
        internal System.Windows.Forms.Button btnempresa;
        internal System.Windows.Forms.Button btnrestaurar;
        internal System.Windows.Forms.Button btncopia;
        private System.Windows.Forms.OpenFileDialog dlg;
        internal System.Windows.Forms.Button btnlicencia;
        internal System.Windows.Forms.Button btnClientes;
        private System.Windows.Forms.Button btnsalir;
    }
}