﻿namespace RestCsharp.Presentacion.Usuarios
{
    partial class UsuariosOk
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtbuscar = new System.Windows.Forms.TextBox();
            this.btnagregar = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panelregistro = new System.Windows.Forms.Panel();
            this.panelIcono = new System.Windows.Forms.Panel();
            this.btnVolverIcono = new System.Windows.Forms.Button();
            this.AgregarIcono = new System.Windows.Forms.PictureBox();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.p8 = new System.Windows.Forms.PictureBox();
            this.p7 = new System.Windows.Forms.PictureBox();
            this.p6 = new System.Windows.Forms.PictureBox();
            this.p5 = new System.Windows.Forms.PictureBox();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.p4 = new System.Windows.Forms.PictureBox();
            this.p3 = new System.Windows.Forms.PictureBox();
            this.p2 = new System.Windows.Forms.PictureBox();
            this.p1 = new System.Windows.Forms.PictureBox();
            this.lblanuncioIcono = new System.Windows.Forms.Label();
            this.Icono = new System.Windows.Forms.PictureBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btnguardar = new System.Windows.Forms.Button();
            this.btnActualizar = new System.Windows.Forms.Button();
            this.btnvolver = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.datalistadoPermisos = new System.Windows.Forms.DataGridView();
            this.Marcar = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Label12 = new System.Windows.Forms.Label();
            this.Label11 = new System.Windows.Forms.Label();
            this.cbxRol = new System.Windows.Forms.ComboBox();
            this.txtcorreo = new System.Windows.Forms.TextBox();
            this.txtcontraseña = new System.Windows.Forms.TextBox();
            this.txtusuario = new System.Windows.Forms.TextBox();
            this.txtnombre = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.datalistadoUsuarios = new System.Windows.Forms.DataGridView();
            this.Eliminar = new System.Windows.Forms.DataGridViewImageColumn();
            this.Editar = new System.Windows.Forms.DataGridViewImageColumn();
            this.dlg = new System.Windows.Forms.OpenFileDialog();
            this.dataGridViewImageColumn1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.dataGridViewImageColumn2 = new System.Windows.Forms.DataGridViewImageColumn();
            this.btnsalir = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelregistro.SuspendLayout();
            this.panelIcono.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AgregarIcono)).BeginInit();
            this.flowLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.p8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p5)).BeginInit();
            this.flowLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.p4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Icono)).BeginInit();
            this.flowLayoutPanel1.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datalistadoPermisos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.datalistadoUsuarios)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1259, 104);
            this.panel1.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnsalir);
            this.panel4.Controls.Add(this.txtbuscar);
            this.panel4.Controls.Add(this.btnagregar);
            this.panel4.Controls.Add(this.panel3);
            this.panel4.Controls.Add(this.pictureBox1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 34);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1259, 70);
            this.panel4.TabIndex = 6;
            // 
            // txtbuscar
            // 
            this.txtbuscar.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtbuscar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbuscar.Location = new System.Drawing.Point(12, 25);
            this.txtbuscar.Name = "txtbuscar";
            this.txtbuscar.Size = new System.Drawing.Size(259, 19);
            this.txtbuscar.TabIndex = 2;
            this.txtbuscar.TextChanged += new System.EventHandler(this.txtbuscar_TextChanged);
            // 
            // btnagregar
            // 
            this.btnagregar.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.btnagregar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnagregar.FlatAppearance.BorderSize = 0;
            this.btnagregar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnagregar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnagregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnagregar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnagregar.ForeColor = System.Drawing.Color.White;
            this.btnagregar.Location = new System.Drawing.Point(354, 12);
            this.btnagregar.Name = "btnagregar";
            this.btnagregar.Size = new System.Drawing.Size(112, 46);
            this.btnagregar.TabIndex = 5;
            this.btnagregar.Text = "Agregar";
            this.btnagregar.UseVisualStyleBackColor = true;
            this.btnagregar.Click += new System.EventHandler(this.btnagregar_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(198)))), ((int)(((byte)(91)))));
            this.panel3.Location = new System.Drawing.Point(12, 50);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(262, 2);
            this.panel3.TabIndex = 3;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::RestCsharp.Properties.Resources.lupa;
            this.pictureBox1.Location = new System.Drawing.Point(277, 25);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(27, 19);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(198)))), ((int)(((byte)(91)))));
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1259, 34);
            this.label1.TabIndex = 1;
            this.label1.Text = "Usuarios";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panelregistro
            // 
            this.panelregistro.Controls.Add(this.panelIcono);
            this.panelregistro.Controls.Add(this.lblanuncioIcono);
            this.panelregistro.Controls.Add(this.Icono);
            this.panelregistro.Controls.Add(this.flowLayoutPanel1);
            this.panelregistro.Controls.Add(this.panel5);
            this.panelregistro.Controls.Add(this.Label12);
            this.panelregistro.Controls.Add(this.Label11);
            this.panelregistro.Controls.Add(this.cbxRol);
            this.panelregistro.Controls.Add(this.txtcorreo);
            this.panelregistro.Controls.Add(this.txtcontraseña);
            this.panelregistro.Controls.Add(this.txtusuario);
            this.panelregistro.Controls.Add(this.txtnombre);
            this.panelregistro.Controls.Add(this.label6);
            this.panelregistro.Controls.Add(this.label5);
            this.panelregistro.Controls.Add(this.label3);
            this.panelregistro.Controls.Add(this.label7);
            this.panelregistro.Controls.Add(this.label4);
            this.panelregistro.Controls.Add(this.label2);
            this.panelregistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelregistro.Location = new System.Drawing.Point(73, 110);
            this.panelregistro.Name = "panelregistro";
            this.panelregistro.Size = new System.Drawing.Size(1083, 593);
            this.panelregistro.TabIndex = 0;
            this.panelregistro.Visible = false;
            // 
            // panelIcono
            // 
            this.panelIcono.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
            this.panelIcono.Controls.Add(this.btnVolverIcono);
            this.panelIcono.Controls.Add(this.AgregarIcono);
            this.panelIcono.Controls.Add(this.flowLayoutPanel2);
            this.panelIcono.Controls.Add(this.flowLayoutPanel3);
            this.panelIcono.Location = new System.Drawing.Point(627, 57);
            this.panelIcono.Name = "panelIcono";
            this.panelIcono.Size = new System.Drawing.Size(208, 465);
            this.panelIcono.TabIndex = 617;
            this.panelIcono.Visible = false;
            // 
            // btnVolverIcono
            // 
            this.btnVolverIcono.BackgroundImage = global::RestCsharp.Properties.Resources.azul;
            this.btnVolverIcono.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnVolverIcono.FlatAppearance.BorderSize = 0;
            this.btnVolverIcono.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnVolverIcono.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnVolverIcono.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVolverIcono.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVolverIcono.ForeColor = System.Drawing.Color.White;
            this.btnVolverIcono.Location = new System.Drawing.Point(187, 390);
            this.btnVolverIcono.Name = "btnVolverIcono";
            this.btnVolverIcono.Size = new System.Drawing.Size(112, 46);
            this.btnVolverIcono.TabIndex = 6;
            this.btnVolverIcono.Text = "Volver";
            this.btnVolverIcono.UseVisualStyleBackColor = true;
            this.btnVolverIcono.Click += new System.EventHandler(this.btnVolverIcono_Click);
            // 
            // AgregarIcono
            // 
            this.AgregarIcono.Image = global::RestCsharp.Properties.Resources.foto__1_;
            this.AgregarIcono.Location = new System.Drawing.Point(25, 390);
            this.AgregarIcono.Name = "AgregarIcono";
            this.AgregarIcono.Size = new System.Drawing.Size(153, 155);
            this.AgregarIcono.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.AgregarIcono.TabIndex = 5;
            this.AgregarIcono.TabStop = false;
            this.AgregarIcono.Click += new System.EventHandler(this.AgregarIcono_Click);
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Controls.Add(this.p8);
            this.flowLayoutPanel2.Controls.Add(this.p7);
            this.flowLayoutPanel2.Controls.Add(this.p6);
            this.flowLayoutPanel2.Controls.Add(this.p5);
            this.flowLayoutPanel2.Location = new System.Drawing.Point(25, 27);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(681, 161);
            this.flowLayoutPanel2.TabIndex = 1;
            // 
            // p8
            // 
            this.p8.Image = global::RestCsharp.Properties.Resources.homero;
            this.p8.Location = new System.Drawing.Point(3, 3);
            this.p8.Name = "p8";
            this.p8.Size = new System.Drawing.Size(153, 155);
            this.p8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.p8.TabIndex = 0;
            this.p8.TabStop = false;
            this.p8.Click += new System.EventHandler(this.p8_Click);
            // 
            // p7
            // 
            this.p7.Image = global::RestCsharp.Properties.Resources.cerveza;
            this.p7.Location = new System.Drawing.Point(162, 3);
            this.p7.Name = "p7";
            this.p7.Size = new System.Drawing.Size(153, 155);
            this.p7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.p7.TabIndex = 1;
            this.p7.TabStop = false;
            this.p7.Click += new System.EventHandler(this.p7_Click);
            // 
            // p6
            // 
            this.p6.Image = global::RestCsharp.Properties.Resources.monster;
            this.p6.Location = new System.Drawing.Point(321, 3);
            this.p6.Name = "p6";
            this.p6.Size = new System.Drawing.Size(153, 155);
            this.p6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.p6.TabIndex = 2;
            this.p6.TabStop = false;
            this.p6.Click += new System.EventHandler(this.p6_Click);
            // 
            // p5
            // 
            this.p5.Image = global::RestCsharp.Properties.Resources.animal;
            this.p5.Location = new System.Drawing.Point(480, 3);
            this.p5.Name = "p5";
            this.p5.Size = new System.Drawing.Size(153, 155);
            this.p5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.p5.TabIndex = 3;
            this.p5.TabStop = false;
            this.p5.Click += new System.EventHandler(this.p5_Click);
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.Controls.Add(this.p4);
            this.flowLayoutPanel3.Controls.Add(this.p3);
            this.flowLayoutPanel3.Controls.Add(this.p2);
            this.flowLayoutPanel3.Controls.Add(this.p1);
            this.flowLayoutPanel3.Location = new System.Drawing.Point(25, 214);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(641, 161);
            this.flowLayoutPanel3.TabIndex = 4;
            // 
            // p4
            // 
            this.p4.Image = global::RestCsharp.Properties.Resources.extraterrestre;
            this.p4.Location = new System.Drawing.Point(3, 3);
            this.p4.Name = "p4";
            this.p4.Size = new System.Drawing.Size(153, 155);
            this.p4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.p4.TabIndex = 0;
            this.p4.TabStop = false;
            this.p4.Click += new System.EventHandler(this.p4_Click);
            // 
            // p3
            // 
            this.p3.Image = global::RestCsharp.Properties.Resources.sonreir;
            this.p3.Location = new System.Drawing.Point(162, 3);
            this.p3.Name = "p3";
            this.p3.Size = new System.Drawing.Size(153, 155);
            this.p3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.p3.TabIndex = 1;
            this.p3.TabStop = false;
            this.p3.Click += new System.EventHandler(this.p3_Click);
            // 
            // p2
            // 
            this.p2.Image = global::RestCsharp.Properties.Resources.fuego__1_;
            this.p2.Location = new System.Drawing.Point(321, 3);
            this.p2.Name = "p2";
            this.p2.Size = new System.Drawing.Size(153, 155);
            this.p2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.p2.TabIndex = 2;
            this.p2.TabStop = false;
            this.p2.Click += new System.EventHandler(this.p2_Click);
            // 
            // p1
            // 
            this.p1.Image = global::RestCsharp.Properties.Resources.nuclear;
            this.p1.Location = new System.Drawing.Point(480, 3);
            this.p1.Name = "p1";
            this.p1.Size = new System.Drawing.Size(153, 155);
            this.p1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.p1.TabIndex = 3;
            this.p1.TabStop = false;
            this.p1.Click += new System.EventHandler(this.p1_Click);
            // 
            // lblanuncioIcono
            // 
            this.lblanuncioIcono.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblanuncioIcono.ForeColor = System.Drawing.Color.White;
            this.lblanuncioIcono.Location = new System.Drawing.Point(452, 14);
            this.lblanuncioIcono.Name = "lblanuncioIcono";
            this.lblanuncioIcono.Size = new System.Drawing.Size(169, 151);
            this.lblanuncioIcono.TabIndex = 616;
            this.lblanuncioIcono.Text = "Elije un Icono";
            this.lblanuncioIcono.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblanuncioIcono.Click += new System.EventHandler(this.lblanuncioIcono_Click);
            // 
            // Icono
            // 
            this.Icono.Location = new System.Drawing.Point(452, 14);
            this.Icono.Name = "Icono";
            this.Icono.Size = new System.Drawing.Size(169, 150);
            this.Icono.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Icono.TabIndex = 615;
            this.Icono.TabStop = false;
            this.Icono.Click += new System.EventHandler(this.Icono_Click);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.btnguardar);
            this.flowLayoutPanel1.Controls.Add(this.btnActualizar);
            this.flowLayoutPanel1.Controls.Add(this.btnvolver);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(125, 466);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(372, 56);
            this.flowLayoutPanel1.TabIndex = 614;
            // 
            // btnguardar
            // 
            this.btnguardar.BackgroundImage = global::RestCsharp.Properties.Resources.azul;
            this.btnguardar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnguardar.FlatAppearance.BorderSize = 0;
            this.btnguardar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnguardar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnguardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnguardar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnguardar.ForeColor = System.Drawing.Color.White;
            this.btnguardar.Location = new System.Drawing.Point(3, 3);
            this.btnguardar.Name = "btnguardar";
            this.btnguardar.Size = new System.Drawing.Size(112, 46);
            this.btnguardar.TabIndex = 6;
            this.btnguardar.Text = "Guardar";
            this.btnguardar.UseVisualStyleBackColor = true;
            this.btnguardar.Click += new System.EventHandler(this.btnguardar_Click);
            // 
            // btnActualizar
            // 
            this.btnActualizar.BackgroundImage = global::RestCsharp.Properties.Resources.azul;
            this.btnActualizar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnActualizar.FlatAppearance.BorderSize = 0;
            this.btnActualizar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnActualizar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnActualizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnActualizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnActualizar.ForeColor = System.Drawing.Color.White;
            this.btnActualizar.Location = new System.Drawing.Point(121, 3);
            this.btnActualizar.Name = "btnActualizar";
            this.btnActualizar.Size = new System.Drawing.Size(112, 46);
            this.btnActualizar.TabIndex = 7;
            this.btnActualizar.Text = "Actualizar";
            this.btnActualizar.UseVisualStyleBackColor = true;
            this.btnActualizar.Click += new System.EventHandler(this.btnActualizar_Click);
            // 
            // btnvolver
            // 
            this.btnvolver.BackgroundImage = global::RestCsharp.Properties.Resources.naranja;
            this.btnvolver.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnvolver.FlatAppearance.BorderSize = 0;
            this.btnvolver.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnvolver.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnvolver.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnvolver.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnvolver.ForeColor = System.Drawing.Color.White;
            this.btnvolver.Location = new System.Drawing.Point(239, 3);
            this.btnvolver.Name = "btnvolver";
            this.btnvolver.Size = new System.Drawing.Size(112, 46);
            this.btnvolver.TabIndex = 8;
            this.btnvolver.Text = "Volver";
            this.btnvolver.UseVisualStyleBackColor = true;
            this.btnvolver.Click += new System.EventHandler(this.btnvolver_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.datalistadoPermisos);
            this.panel5.Location = new System.Drawing.Point(128, 259);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(478, 201);
            this.panel5.TabIndex = 613;
            // 
            // datalistadoPermisos
            // 
            this.datalistadoPermisos.AllowUserToAddRows = false;
            this.datalistadoPermisos.AllowUserToDeleteRows = false;
            this.datalistadoPermisos.AllowUserToResizeRows = false;
            this.datalistadoPermisos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.datalistadoPermisos.BackgroundColor = System.Drawing.Color.White;
            this.datalistadoPermisos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.datalistadoPermisos.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.datalistadoPermisos.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.datalistadoPermisos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datalistadoPermisos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Marcar});
            this.datalistadoPermisos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.datalistadoPermisos.EnableHeadersVisualStyles = false;
            this.datalistadoPermisos.Location = new System.Drawing.Point(0, 0);
            this.datalistadoPermisos.Name = "datalistadoPermisos";
            this.datalistadoPermisos.RowHeadersVisible = false;
            this.datalistadoPermisos.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.datalistadoPermisos.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.datalistadoPermisos.RowTemplate.Height = 30;
            this.datalistadoPermisos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datalistadoPermisos.Size = new System.Drawing.Size(478, 201);
            this.datalistadoPermisos.TabIndex = 2;
            // 
            // Marcar
            // 
            this.Marcar.HeaderText = "Marcar";
            this.Marcar.Name = "Marcar";
            this.Marcar.Width = 62;
            // 
            // Label12
            // 
            this.Label12.AutoSize = true;
            this.Label12.BackColor = System.Drawing.Color.Transparent;
            this.Label12.ForeColor = System.Drawing.Color.Green;
            this.Label12.Location = new System.Drawing.Point(205, 230);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(345, 20);
            this.Label12.TabIndex = 612;
            this.Label12.Text = "(marca los modulos a los que se tendra acceso)";
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.BackColor = System.Drawing.Color.Transparent;
            this.Label11.ForeColor = System.Drawing.Color.Black;
            this.Label11.Location = new System.Drawing.Point(121, 230);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(78, 20);
            this.Label11.TabIndex = 226;
            this.Label11.Text = "Permisos:";
            // 
            // cbxRol
            // 
            this.cbxRol.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxRol.FormattingEnabled = true;
            this.cbxRol.Items.AddRange(new object[] {
            "Mozo",
            "Cajero",
            "Administrador"});
            this.cbxRol.Location = new System.Drawing.Point(170, 181);
            this.cbxRol.Name = "cbxRol";
            this.cbxRol.Size = new System.Drawing.Size(209, 28);
            this.cbxRol.TabIndex = 2;
            this.cbxRol.SelectedIndexChanged += new System.EventHandler(this.cbxRol_SelectedIndexChanged);
            // 
            // txtcorreo
            // 
            this.txtcorreo.Location = new System.Drawing.Point(170, 139);
            this.txtcorreo.Name = "txtcorreo";
            this.txtcorreo.Size = new System.Drawing.Size(276, 26);
            this.txtcorreo.TabIndex = 1;
            // 
            // txtcontraseña
            // 
            this.txtcontraseña.Location = new System.Drawing.Point(170, 100);
            this.txtcontraseña.MaxLength = 6;
            this.txtcontraseña.Name = "txtcontraseña";
            this.txtcontraseña.Size = new System.Drawing.Size(134, 26);
            this.txtcontraseña.TabIndex = 1;
            this.txtcontraseña.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcontraseña_KeyPress);
            // 
            // txtusuario
            // 
            this.txtusuario.Location = new System.Drawing.Point(170, 57);
            this.txtusuario.Name = "txtusuario";
            this.txtusuario.Size = new System.Drawing.Size(188, 26);
            this.txtusuario.TabIndex = 1;
            // 
            // txtnombre
            // 
            this.txtnombre.Location = new System.Drawing.Point(170, 14);
            this.txtnombre.Name = "txtnombre";
            this.txtnombre.Size = new System.Drawing.Size(276, 26);
            this.txtnombre.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(121, 184);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 20);
            this.label6.TabIndex = 0;
            this.label6.Text = "Rol:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 139);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(142, 20);
            this.label5.TabIndex = 0;
            this.label5.Text = "Correo electronico:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(90, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 20);
            this.label3.TabIndex = 0;
            this.label3.Text = "Usuario:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DimGray;
            this.label7.Location = new System.Drawing.Point(310, 96);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(103, 30);
            this.label7.TabIndex = 0;
            this.label7.Text = "Se permite hasta \r\n6 numeros";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(62, 100);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 20);
            this.label4.TabIndex = 0;
            this.label4.Text = "Contraseña:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(89, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "Nombre:";
            // 
            // datalistadoUsuarios
            // 
            this.datalistadoUsuarios.AllowUserToAddRows = false;
            this.datalistadoUsuarios.AllowUserToDeleteRows = false;
            this.datalistadoUsuarios.AllowUserToResizeRows = false;
            this.datalistadoUsuarios.BackgroundColor = System.Drawing.Color.White;
            this.datalistadoUsuarios.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.datalistadoUsuarios.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.datalistadoUsuarios.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.datalistadoUsuarios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datalistadoUsuarios.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Eliminar,
            this.Editar});
            this.datalistadoUsuarios.Dock = System.Windows.Forms.DockStyle.Fill;
            this.datalistadoUsuarios.EnableHeadersVisualStyles = false;
            this.datalistadoUsuarios.Location = new System.Drawing.Point(0, 104);
            this.datalistadoUsuarios.Name = "datalistadoUsuarios";
            this.datalistadoUsuarios.ReadOnly = true;
            this.datalistadoUsuarios.RowHeadersVisible = false;
            this.datalistadoUsuarios.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.datalistadoUsuarios.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.datalistadoUsuarios.RowTemplate.Height = 40;
            this.datalistadoUsuarios.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datalistadoUsuarios.Size = new System.Drawing.Size(1259, 645);
            this.datalistadoUsuarios.TabIndex = 1;
            this.datalistadoUsuarios.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datalistadoUsuarios_CellClick);
            // 
            // Eliminar
            // 
            this.Eliminar.HeaderText = "";
            this.Eliminar.Image = global::RestCsharp.Properties.Resources.Eliminar;
            this.Eliminar.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Zoom;
            this.Eliminar.Name = "Eliminar";
            this.Eliminar.ReadOnly = true;
            // 
            // Editar
            // 
            this.Editar.HeaderText = "";
            this.Editar.Image = global::RestCsharp.Properties.Resources.editar;
            this.Editar.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Zoom;
            this.Editar.Name = "Editar";
            this.Editar.ReadOnly = true;
            // 
            // dlg
            // 
            this.dlg.FileName = "openFileDialog1";
            // 
            // dataGridViewImageColumn1
            // 
            this.dataGridViewImageColumn1.HeaderText = "Eliminar";
            this.dataGridViewImageColumn1.Image = global::RestCsharp.Properties.Resources.Eliminar;
            this.dataGridViewImageColumn1.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Zoom;
            this.dataGridViewImageColumn1.Name = "dataGridViewImageColumn1";
            // 
            // dataGridViewImageColumn2
            // 
            this.dataGridViewImageColumn2.HeaderText = "";
            this.dataGridViewImageColumn2.Image = global::RestCsharp.Properties.Resources.editar;
            this.dataGridViewImageColumn2.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Zoom;
            this.dataGridViewImageColumn2.Name = "dataGridViewImageColumn2";
            // 
            // btnsalir
            // 
            this.btnsalir.BackgroundImage = global::RestCsharp.Properties.Resources.naranja;
            this.btnsalir.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnsalir.FlatAppearance.BorderSize = 0;
            this.btnsalir.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnsalir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnsalir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsalir.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsalir.ForeColor = System.Drawing.Color.White;
            this.btnsalir.Location = new System.Drawing.Point(472, 12);
            this.btnsalir.Name = "btnsalir";
            this.btnsalir.Size = new System.Drawing.Size(112, 46);
            this.btnsalir.TabIndex = 6;
            this.btnsalir.Text = "Volver";
            this.btnsalir.UseVisualStyleBackColor = true;
            this.btnsalir.Click += new System.EventHandler(this.btnsalir_Click);
            // 
            // UsuariosOk
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.panelregistro);
            this.Controls.Add(this.datalistadoUsuarios);
            this.Controls.Add(this.panel1);
            this.Name = "UsuariosOk";
            this.Size = new System.Drawing.Size(1259, 749);
            this.Load += new System.EventHandler(this.UsuariosOk_Load);
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelregistro.ResumeLayout(false);
            this.panelregistro.PerformLayout();
            this.panelIcono.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.AgregarIcono)).EndInit();
            this.flowLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.p8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p5)).EndInit();
            this.flowLayoutPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.p4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Icono)).EndInit();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.datalistadoPermisos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.datalistadoUsuarios)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panelregistro;
        private System.Windows.Forms.DataGridView datalistadoUsuarios;
        private System.Windows.Forms.TextBox txtbuscar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnagregar;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        internal System.Windows.Forms.Label Label12;
        internal System.Windows.Forms.Label Label11;
        private System.Windows.Forms.ComboBox cbxRol;
        private System.Windows.Forms.TextBox txtcorreo;
        private System.Windows.Forms.TextBox txtcontraseña;
        private System.Windows.Forms.TextBox txtusuario;
        private System.Windows.Forms.TextBox txtnombre;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button btnguardar;
        private System.Windows.Forms.Button btnActualizar;
        private System.Windows.Forms.Button btnvolver;
        private System.Windows.Forms.Panel panelIcono;
        private System.Windows.Forms.Label lblanuncioIcono;
        private System.Windows.Forms.PictureBox Icono;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.PictureBox p8;
        private System.Windows.Forms.PictureBox AgregarIcono;
        private System.Windows.Forms.PictureBox p7;
        private System.Windows.Forms.PictureBox p6;
        private System.Windows.Forms.PictureBox p5;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private System.Windows.Forms.PictureBox p4;
        private System.Windows.Forms.PictureBox p3;
        private System.Windows.Forms.PictureBox p2;
        private System.Windows.Forms.PictureBox p1;
        private System.Windows.Forms.DataGridView datalistadoPermisos;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Marcar;
        private System.Windows.Forms.OpenFileDialog dlg;
        private System.Windows.Forms.Button btnVolverIcono;
        private System.Windows.Forms.DataGridViewImageColumn Eliminar;
        private System.Windows.Forms.DataGridViewImageColumn Editar;
        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnsalir;
    }
}