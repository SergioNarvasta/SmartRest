﻿
namespace RestCsharp.Presentacion.PUNTO_DE_VENTA
{
    partial class Cobrar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelPrincipal = new System.Windows.Forms.Panel();
            this.panelReport = new System.Windows.Forms.Panel();
            this.Label1 = new System.Windows.Forms.Label();
            this.btnAceptar = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.reportViewer1 = new Telerik.ReportViewer.WinForms.ReportViewer();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btnTecladoNum = new UIDC.UI_TecladoNumerico();
            this.btnguardar = new System.Windows.Forms.Button();
            this.lbltotal = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtrestante = new System.Windows.Forms.Label();
            this.Label8 = new System.Windows.Forms.Label();
            this.Panel8 = new System.Windows.Forms.Panel();
            this.TXTVUELTO = new System.Windows.Forms.TextBox();
            this.Label31 = new System.Windows.Forms.Label();
            this.txttarjeta = new System.Windows.Forms.TextBox();
            this.Panel21 = new System.Windows.Forms.Panel();
            this.Label19 = new System.Windows.Forms.Label();
            this.txtefectivo = new System.Windows.Forms.TextBox();
            this.Panel20 = new System.Windows.Forms.Panel();
            this.Label18 = new System.Windows.Forms.Label();
            this.btncerrar = new System.Windows.Forms.Button();
            this.panelPrincipal.SuspendLayout();
            this.panelReport.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.flowLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelPrincipal
            // 
            this.panelPrincipal.Controls.Add(this.panelReport);
            this.panelPrincipal.Controls.Add(this.flowLayoutPanel1);
            this.panelPrincipal.Controls.Add(this.btnguardar);
            this.panelPrincipal.Controls.Add(this.lbltotal);
            this.panelPrincipal.Controls.Add(this.label2);
            this.panelPrincipal.Controls.Add(this.panel1);
            this.panelPrincipal.Controls.Add(this.btncerrar);
            this.panelPrincipal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelPrincipal.Location = new System.Drawing.Point(0, 0);
            this.panelPrincipal.Name = "panelPrincipal";
            this.panelPrincipal.Size = new System.Drawing.Size(786, 402);
            this.panelPrincipal.TabIndex = 623;
            // 
            // panelReport
            // 
            this.panelReport.Controls.Add(this.Label1);
            this.panelReport.Controls.Add(this.btnAceptar);
            this.panelReport.Controls.Add(this.pictureBox2);
            this.panelReport.Controls.Add(this.reportViewer1);
            this.panelReport.Location = new System.Drawing.Point(515, 339);
            this.panelReport.Name = "panelReport";
            this.panelReport.Size = new System.Drawing.Size(231, 42);
            this.panelReport.TabIndex = 638;
            this.panelReport.Visible = false;
            // 
            // Label1
            // 
            this.Label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.Label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.ForeColor = System.Drawing.Color.Silver;
            this.Label1.Location = new System.Drawing.Point(467, 0);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(0, 149);
            this.Label1.TabIndex = 640;
            this.Label1.Text = "Venta realizada \r\ncorrectamente";
            this.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnAceptar
            // 
            this.btnAceptar.BackColor = System.Drawing.Color.Transparent;
            this.btnAceptar.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.btnAceptar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAceptar.FlatAppearance.BorderSize = 0;
            this.btnAceptar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnAceptar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnAceptar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAceptar.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAceptar.ForeColor = System.Drawing.Color.White;
            this.btnAceptar.Location = new System.Drawing.Point(477, 167);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(145, 76);
            this.btnAceptar.TabIndex = 639;
            this.btnAceptar.Text = "Aceptar";
            this.btnAceptar.UseVisualStyleBackColor = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pictureBox2.Image = global::RestCsharp.Properties.Resources.Buman;
            this.pictureBox2.Location = new System.Drawing.Point(467, -85);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(0, 127);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 638;
            this.pictureBox2.TabStop = false;
            // 
            // reportViewer1
            // 
            this.reportViewer1.AccessibilityKeyMap = null;
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Left;
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(467, 42);
            this.reportViewer1.TabIndex = 637;
            this.reportViewer1.ViewMode = Telerik.ReportViewer.WinForms.ViewMode.PrintPreview;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.btnTecladoNum);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(515, 86);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(240, 66);
            this.flowLayoutPanel1.TabIndex = 636;
            // 
            // btnTecladoNum
            // 
            this.btnTecladoNum.AddControl = null;
            this.btnTecladoNum.BackColor = System.Drawing.Color.Transparent;
            this.btnTecladoNum.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.btnTecladoNum.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTecladoNum.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTecladoNum.FlatAppearance.BorderSize = 0;
            this.btnTecladoNum.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnTecladoNum.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnTecladoNum.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTecladoNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTecladoNum.ForeColor = System.Drawing.Color.White;
            this.btnTecladoNum.IconKeyBoardColor = System.Drawing.SystemColors.ControlText;
            this.btnTecladoNum.IconKeyBoardSize = 20;
            this.btnTecladoNum.Location = new System.Drawing.Point(3, 3);
            this.btnTecladoNum.Mode = UIDC.UI_TecladoNumerico.SEE.Claro;
            this.btnTecladoNum.Name = "btnTecladoNum";
            this.btnTecladoNum.Size = new System.Drawing.Size(184, 57);
            this.btnTecladoNum.TabIndex = 635;
            this.btnTecladoNum.Text = "Teclado Virtual*";
            this.btnTecladoNum.UseVisualStyleBackColor = false;
            // 
            // btnguardar
            // 
            this.btnguardar.BackColor = System.Drawing.Color.Transparent;
            this.btnguardar.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.btnguardar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnguardar.FlatAppearance.BorderSize = 0;
            this.btnguardar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnguardar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnguardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnguardar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnguardar.ForeColor = System.Drawing.Color.White;
            this.btnguardar.Location = new System.Drawing.Point(515, 242);
            this.btnguardar.Name = "btnguardar";
            this.btnguardar.Size = new System.Drawing.Size(157, 64);
            this.btnguardar.TabIndex = 618;
            this.btnguardar.Text = "IMPRIMIR";
            this.btnguardar.UseVisualStyleBackColor = false;
            this.btnguardar.Click += new System.EventHandler(this.btnGuardarImprimirdirecto_Click);
            // 
            // lbltotal
            // 
            this.lbltotal.AutoSize = true;
            this.lbltotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold);
            this.lbltotal.ForeColor = System.Drawing.Color.White;
            this.lbltotal.Location = new System.Drawing.Point(158, 29);
            this.lbltotal.Name = "lbltotal";
            this.lbltotal.Size = new System.Drawing.Size(147, 46);
            this.lbltotal.TabIndex = 624;
            this.lbltotal.Text = "10 000";
            this.lbltotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(27, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 46);
            this.label2.TabIndex = 623;
            this.label2.Text = "Total:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtrestante);
            this.panel1.Controls.Add(this.Label8);
            this.panel1.Controls.Add(this.Panel8);
            this.panel1.Controls.Add(this.TXTVUELTO);
            this.panel1.Controls.Add(this.Label31);
            this.panel1.Controls.Add(this.txttarjeta);
            this.panel1.Controls.Add(this.Panel21);
            this.panel1.Controls.Add(this.Label19);
            this.panel1.Controls.Add(this.txtefectivo);
            this.panel1.Controls.Add(this.Panel20);
            this.panel1.Controls.Add(this.Label18);
            this.panel1.Location = new System.Drawing.Point(13, 86);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(496, 295);
            this.panel1.TabIndex = 4;
            // 
            // txtrestante
            // 
            this.txtrestante.AutoSize = true;
            this.txtrestante.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold);
            this.txtrestante.ForeColor = System.Drawing.Color.Gray;
            this.txtrestante.Location = new System.Drawing.Point(133, 231);
            this.txtrestante.Name = "txtrestante";
            this.txtrestante.Size = new System.Drawing.Size(27, 29);
            this.txtrestante.TabIndex = 626;
            this.txtrestante.Text = "0";
            this.txtrestante.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.Label8.ForeColor = System.Drawing.Color.Gray;
            this.Label8.Location = new System.Drawing.Point(16, 231);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(114, 29);
            this.Label8.TabIndex = 627;
            this.Label8.Text = "Restante:";
            this.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Panel8
            // 
            this.Panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Panel8.Location = new System.Drawing.Point(17, 226);
            this.Panel8.Name = "Panel8";
            this.Panel8.Size = new System.Drawing.Size(308, 2);
            this.Panel8.TabIndex = 625;
            // 
            // TXTVUELTO
            // 
            this.TXTVUELTO.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.TXTVUELTO.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TXTVUELTO.Enabled = false;
            this.TXTVUELTO.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold);
            this.TXTVUELTO.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.TXTVUELTO.Location = new System.Drawing.Point(167, 174);
            this.TXTVUELTO.Name = "TXTVUELTO";
            this.TXTVUELTO.Size = new System.Drawing.Size(227, 46);
            this.TXTVUELTO.TabIndex = 624;
            this.TXTVUELTO.Text = "0";
            // 
            // Label31
            // 
            this.Label31.AutoSize = true;
            this.Label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.Label31.ForeColor = System.Drawing.Color.White;
            this.Label31.Location = new System.Drawing.Point(16, 174);
            this.Label31.Name = "Label31";
            this.Label31.Size = new System.Drawing.Size(145, 46);
            this.Label31.TabIndex = 622;
            this.Label31.Text = "Vuelto:";
            this.Label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txttarjeta
            // 
            this.txttarjeta.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.txttarjeta.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txttarjeta.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold);
            this.txttarjeta.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txttarjeta.Location = new System.Drawing.Point(116, 91);
            this.txttarjeta.Name = "txttarjeta";
            this.txttarjeta.Size = new System.Drawing.Size(177, 38);
            this.txttarjeta.TabIndex = 560;
            this.txttarjeta.TextChanged += new System.EventHandler(this.txttarjeta_TextChanged);
            // 
            // Panel21
            // 
            this.Panel21.BackColor = System.Drawing.SystemColors.HotTrack;
            this.Panel21.Location = new System.Drawing.Point(116, 135);
            this.Panel21.Name = "Panel21";
            this.Panel21.Size = new System.Drawing.Size(180, 2);
            this.Panel21.TabIndex = 559;
            // 
            // Label19
            // 
            this.Label19.AutoSize = true;
            this.Label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.Label19.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.Label19.Location = new System.Drawing.Point(19, 109);
            this.Label19.Name = "Label19";
            this.Label19.Size = new System.Drawing.Size(95, 29);
            this.Label19.TabIndex = 558;
            this.Label19.Text = "Tarjeta:";
            this.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtefectivo
            // 
            this.txtefectivo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.txtefectivo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtefectivo.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold);
            this.txtefectivo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtefectivo.Location = new System.Drawing.Point(123, 28);
            this.txtefectivo.Name = "txtefectivo";
            this.txtefectivo.Size = new System.Drawing.Size(177, 38);
            this.txtefectivo.TabIndex = 557;
            this.txtefectivo.TextChanged += new System.EventHandler(this.txtefectivo_TextChanged);
            this.txtefectivo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtefectivo_KeyPress);
            // 
            // Panel20
            // 
            this.Panel20.BackColor = System.Drawing.Color.SeaGreen;
            this.Panel20.Location = new System.Drawing.Point(119, 71);
            this.Panel20.Name = "Panel20";
            this.Panel20.Size = new System.Drawing.Size(180, 2);
            this.Panel20.TabIndex = 556;
            // 
            // Label18
            // 
            this.Label18.AutoSize = true;
            this.Label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.Label18.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.Label18.Location = new System.Drawing.Point(13, 44);
            this.Label18.Name = "Label18";
            this.Label18.Size = new System.Drawing.Size(104, 29);
            this.Label18.TabIndex = 555;
            this.Label18.Text = "Efectivo:";
            this.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btncerrar
            // 
            this.btncerrar.BackColor = System.Drawing.Color.Transparent;
            this.btncerrar.BackgroundImage = global::RestCsharp.Properties.Resources.Rojo;
            this.btncerrar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btncerrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btncerrar.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btncerrar.FlatAppearance.BorderSize = 0;
            this.btncerrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btncerrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btncerrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncerrar.Font = new System.Drawing.Font("Calibri", 35F, System.Drawing.FontStyle.Bold);
            this.btncerrar.ForeColor = System.Drawing.Color.White;
            this.btncerrar.Location = new System.Drawing.Point(686, 10);
            this.btncerrar.Name = "btncerrar";
            this.btncerrar.Size = new System.Drawing.Size(69, 65);
            this.btncerrar.TabIndex = 621;
            this.btncerrar.Text = "X";
            this.btncerrar.UseVisualStyleBackColor = false;
            this.btncerrar.Click += new System.EventHandler(this.btncerrar_Click);
            // 
            // Cobrar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.ClientSize = new System.Drawing.Size(786, 402);
            this.Controls.Add(this.panelPrincipal);
            this.Name = "Cobrar";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cobrar";
            this.Load += new System.EventHandler(this.Cobrar_Load);
            this.panelPrincipal.ResumeLayout(false);
            this.panelPrincipal.PerformLayout();
            this.panelReport.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelPrincipal;
        private System.Windows.Forms.Panel panelReport;
        internal System.Windows.Forms.Label Label1;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.PictureBox pictureBox2;
        private Telerik.ReportViewer.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private UIDC.UI_TecladoNumerico btnTecladoNum;
        internal System.Windows.Forms.Button btnguardar;
        internal System.Windows.Forms.Label lbltotal;
        internal System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        internal System.Windows.Forms.Label txtrestante;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.Panel Panel8;
        internal System.Windows.Forms.TextBox TXTVUELTO;
        internal System.Windows.Forms.Label Label31;
        internal System.Windows.Forms.TextBox txttarjeta;
        internal System.Windows.Forms.Panel Panel21;
        internal System.Windows.Forms.Label Label19;
        internal System.Windows.Forms.TextBox txtefectivo;
        internal System.Windows.Forms.Panel Panel20;
        internal System.Windows.Forms.Label Label18;
        internal System.Windows.Forms.Button btncerrar;
    }
}