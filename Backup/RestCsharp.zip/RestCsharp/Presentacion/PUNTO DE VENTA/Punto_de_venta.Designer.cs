﻿namespace RestCsharp.Presentacion.PUNTO_DE_VENTA
{
    partial class Punto_de_venta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Punto_de_venta));
            this.panel2 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.btnsalir = new System.Windows.Forms.Button();
            this.btncobrar = new System.Windows.Forms.Button();
            this.Panelpagorapido = new System.Windows.Forms.FlowLayoutPanel();
            this.Bn1 = new System.Windows.Forms.Button();
            this.Bn5 = new System.Windows.Forms.Button();
            this.Bn10 = new System.Windows.Forms.Button();
            this.Bn20 = new System.Windows.Forms.Button();
            this.Bn50 = new System.Windows.Forms.Button();
            this.Bn100 = new System.Windows.Forms.Button();
            this.BnExacto = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel35 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.IndicadorTema = new UIDC.UI_MaterialToggle();
            this.lblUltimoPagoCon = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblUltimoVuelto = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblUltimoTotal = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblUltimoImpuesto = new System.Windows.Forms.Label();
            this.lbltipoimpuesto = new System.Windows.Forms.Label();
            this.lblUltimoSubtotal = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.PanelVentasGeneral = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Panel9 = new System.Windows.Forms.Panel();
            this.Panel_grupos = new System.Windows.Forms.FlowLayoutPanel();
            this.panelCobro = new System.Windows.Forms.Panel();
            this.dgClientes = new System.Windows.Forms.DataGridView();
            this.panelClienteFactura = new System.Windows.Forms.Panel();
            this.btnAgregarcliente = new System.Windows.Forms.Button();
            this.lblCliente = new System.Windows.Forms.Label();
            this.txtbuscarcliente = new System.Windows.Forms.TextBox();
            this.lblComprobante = new System.Windows.Forms.Label();
            this.Panelcomprobante = new System.Windows.Forms.FlowLayoutPanel();
            this.panelReport = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.btnAceptar = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.reportViewer1 = new Telerik.ReportViewer.WinForms.ReportViewer();
            this.btnguardar = new System.Windows.Forms.Button();
            this.lbltotal = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel34 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.txtreferencia = new System.Windows.Forms.TextBox();
            this.btnTecladodigitos = new UIDC.UI_TecladoNumerico();
            this.btnTecladoTarjeta = new UIDC.UI_TecladoNumerico();
            this.txttarjeta = new System.Windows.Forms.TextBox();
            this.btnTecladoEfectivo = new UIDC.UI_TecladoNumerico();
            this.txtefectivo = new System.Windows.Forms.TextBox();
            this.txtrestante = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.panel24 = new System.Windows.Forms.Panel();
            this.txtvuelto = new System.Windows.Forms.TextBox();
            this.Label31 = new System.Windows.Forms.Label();
            this.panel25 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.panel31 = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.btncerrar = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.btngrupoAtras = new System.Windows.Forms.Button();
            this.btnGrupoadelante = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.PanelProductos = new System.Windows.Forms.Panel();
            this.flowLayoutPanel5 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel32 = new System.Windows.Forms.Panel();
            this.Label16 = new System.Windows.Forms.Label();
            this.btnatras = new System.Windows.Forms.Button();
            this.btnadelante = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.FlowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this.btnvermesas = new System.Windows.Forms.Button();
            this.btnDividirCuenta = new System.Windows.Forms.Button();
            this.btnPrecuenta = new System.Windows.Forms.Button();
            this.btneliminarVenta = new System.Windows.Forms.Button();
            this.btnEnviarpedido = new System.Windows.Forms.Button();
            this.btnNotas = new System.Windows.Forms.Button();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.panel29 = new System.Windows.Forms.Panel();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.datalistadoPedidos = new System.Windows.Forms.DataGridView();
            this.Iddetalleventa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Importe = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rptPedidos = new Telerik.ReportViewer.WinForms.ReportViewer();
            this.panelNotas = new System.Windows.Forms.Panel();
            this.lblNota = new System.Windows.Forms.Label();
            this.panel30 = new System.Windows.Forms.Panel();
            this.label35 = new System.Windows.Forms.Label();
            this.PanelDetalleVenta = new System.Windows.Forms.Panel();
            this.detalleventa = new System.Windows.Forms.FlowLayoutPanel();
            this.PanelTotales = new System.Windows.Forms.Panel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.PanelAcumulado = new System.Windows.Forms.Panel();
            this.txtacumulado = new System.Windows.Forms.Label();
            this.panel33 = new System.Windows.Forms.Panel();
            this.Label18 = new System.Windows.Forms.Label();
            this.lblCantclientesti = new System.Windows.Forms.Label();
            this.lblcantidadPersonas = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.Paneltotal2 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.txtTotal2 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.panel26 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.lblSubtotal2 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.panel27 = new System.Windows.Forms.Panel();
            this.lblImpuestocal2 = new System.Windows.Forms.Label();
            this.lblImpuesto2 = new System.Windows.Forms.Label();
            this.panel28 = new System.Windows.Forms.Panel();
            this.label32 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.panelTotal1 = new System.Windows.Forms.Panel();
            this.Panel13 = new System.Windows.Forms.Panel();
            this.Label14 = new System.Windows.Forms.Label();
            this.Label15 = new System.Windows.Forms.Label();
            this.Panel12 = new System.Windows.Forms.Panel();
            this.lblImpuestocal1 = new System.Windows.Forms.Label();
            this.lblImpuesto1 = new System.Windows.Forms.Label();
            this.Panel11 = new System.Windows.Forms.Panel();
            this.lblSubtotal1 = new System.Windows.Forms.Label();
            this.Label11 = new System.Windows.Forms.Label();
            this.Panel15 = new System.Windows.Forms.Panel();
            this.txtTotal1 = new System.Windows.Forms.Label();
            this.Label33 = new System.Windows.Forms.Label();
            this.Panel14 = new System.Windows.Forms.Panel();
            this.panel22 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.lblcuenta = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.btncuentaadelante = new System.Windows.Forms.Button();
            this.btncuentaatras = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.PictureBox2 = new System.Windows.Forms.PictureBox();
            this.rptComunicador = new Telerik.ReportViewer.WinForms.ReportViewer();
            this.lblMesa = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.PictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblhora = new System.Windows.Forms.Label();
            this.lblfecha = new System.Windows.Forms.Label();
            this.timerFechaHora = new System.Windows.Forms.Timer(this.components);
            this.timerImprimir = new System.Windows.Forms.Timer(this.components);
            this.timerEsc = new System.Windows.Forms.Timer(this.components);
            this.dataGridViewImageColumn1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.panel2.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.Panelpagorapido.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel35.SuspendLayout();
            this.PanelVentasGeneral.SuspendLayout();
            this.panel1.SuspendLayout();
            this.Panel9.SuspendLayout();
            this.Panel_grupos.SuspendLayout();
            this.panelCobro.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgClientes)).BeginInit();
            this.panelClienteFactura.SuspendLayout();
            this.panelReport.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel4.SuspendLayout();
            this.PanelProductos.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel5.SuspendLayout();
            this.FlowLayoutPanel4.SuspendLayout();
            this.panel29.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datalistadoPedidos)).BeginInit();
            this.panelNotas.SuspendLayout();
            this.PanelDetalleVenta.SuspendLayout();
            this.PanelTotales.SuspendLayout();
            this.panel23.SuspendLayout();
            this.PanelAcumulado.SuspendLayout();
            this.panel18.SuspendLayout();
            this.Paneltotal2.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panelTotal1.SuspendLayout();
            this.Panel13.SuspendLayout();
            this.Panel12.SuspendLayout();
            this.Panel11.SuspendLayout();
            this.Panel15.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.flowLayoutPanel2);
            this.panel2.Controls.Add(this.Panelpagorapido);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 927);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1843, 58);
            this.panel2.TabIndex = 1;
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Controls.Add(this.btnsalir);
            this.flowLayoutPanel2.Controls.Add(this.btncobrar);
            this.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel2.Location = new System.Drawing.Point(768, 0);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.flowLayoutPanel2.Size = new System.Drawing.Size(1075, 58);
            this.flowLayoutPanel2.TabIndex = 2;
            // 
            // btnsalir
            // 
            this.btnsalir.BackgroundImage = global::RestCsharp.Properties.Resources.naranja;
            this.btnsalir.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnsalir.FlatAppearance.BorderSize = 0;
            this.btnsalir.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnsalir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnsalir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsalir.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsalir.ForeColor = System.Drawing.Color.White;
            this.btnsalir.Location = new System.Drawing.Point(955, 3);
            this.btnsalir.Name = "btnsalir";
            this.btnsalir.Size = new System.Drawing.Size(117, 50);
            this.btnsalir.TabIndex = 0;
            this.btnsalir.Text = "Salir";
            this.btnsalir.UseVisualStyleBackColor = true;
            this.btnsalir.Click += new System.EventHandler(this.btnsalir_Click);
            // 
            // btncobrar
            // 
            this.btncobrar.BackgroundImage = global::RestCsharp.Properties.Resources.Rojo;
            this.btncobrar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btncobrar.FlatAppearance.BorderSize = 0;
            this.btncobrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btncobrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btncobrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncobrar.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncobrar.ForeColor = System.Drawing.Color.White;
            this.btncobrar.Location = new System.Drawing.Point(832, 3);
            this.btncobrar.Name = "btncobrar";
            this.btncobrar.Size = new System.Drawing.Size(117, 50);
            this.btncobrar.TabIndex = 0;
            this.btncobrar.Text = "Cobrar";
            this.btncobrar.UseVisualStyleBackColor = true;
            this.btncobrar.Click += new System.EventHandler(this.btncobrar_Click);
            // 
            // Panelpagorapido
            // 
            this.Panelpagorapido.Controls.Add(this.Bn1);
            this.Panelpagorapido.Controls.Add(this.Bn5);
            this.Panelpagorapido.Controls.Add(this.Bn10);
            this.Panelpagorapido.Controls.Add(this.Bn20);
            this.Panelpagorapido.Controls.Add(this.Bn50);
            this.Panelpagorapido.Controls.Add(this.Bn100);
            this.Panelpagorapido.Controls.Add(this.BnExacto);
            this.Panelpagorapido.Dock = System.Windows.Forms.DockStyle.Left;
            this.Panelpagorapido.Location = new System.Drawing.Point(0, 0);
            this.Panelpagorapido.Name = "Panelpagorapido";
            this.Panelpagorapido.Size = new System.Drawing.Size(768, 58);
            this.Panelpagorapido.TabIndex = 1;
            // 
            // Bn1
            // 
            this.Bn1.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.Bn1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Bn1.FlatAppearance.BorderSize = 0;
            this.Bn1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.Bn1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.Bn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Bn1.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bn1.ForeColor = System.Drawing.Color.White;
            this.Bn1.Location = new System.Drawing.Point(3, 3);
            this.Bn1.Name = "Bn1";
            this.Bn1.Size = new System.Drawing.Size(89, 50);
            this.Bn1.TabIndex = 0;
            this.Bn1.Text = "S/. 1";
            this.Bn1.UseVisualStyleBackColor = true;
            this.Bn1.Visible = false;
            this.Bn1.Click += new System.EventHandler(this.Bn1_Click);
            // 
            // Bn5
            // 
            this.Bn5.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.Bn5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Bn5.FlatAppearance.BorderSize = 0;
            this.Bn5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.Bn5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.Bn5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Bn5.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bn5.ForeColor = System.Drawing.Color.White;
            this.Bn5.Location = new System.Drawing.Point(98, 3);
            this.Bn5.Name = "Bn5";
            this.Bn5.Size = new System.Drawing.Size(89, 50);
            this.Bn5.TabIndex = 0;
            this.Bn5.Text = "S/. 5";
            this.Bn5.UseVisualStyleBackColor = true;
            this.Bn5.Visible = false;
            this.Bn5.Click += new System.EventHandler(this.Bn5_Click);
            // 
            // Bn10
            // 
            this.Bn10.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.Bn10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Bn10.FlatAppearance.BorderSize = 0;
            this.Bn10.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.Bn10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.Bn10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Bn10.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bn10.ForeColor = System.Drawing.Color.White;
            this.Bn10.Location = new System.Drawing.Point(193, 3);
            this.Bn10.Name = "Bn10";
            this.Bn10.Size = new System.Drawing.Size(100, 50);
            this.Bn10.TabIndex = 0;
            this.Bn10.Text = "S/. 10";
            this.Bn10.UseVisualStyleBackColor = true;
            this.Bn10.Visible = false;
            this.Bn10.Click += new System.EventHandler(this.Bn10_Click);
            // 
            // Bn20
            // 
            this.Bn20.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.Bn20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Bn20.FlatAppearance.BorderSize = 0;
            this.Bn20.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.Bn20.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.Bn20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Bn20.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bn20.ForeColor = System.Drawing.Color.White;
            this.Bn20.Location = new System.Drawing.Point(299, 3);
            this.Bn20.Name = "Bn20";
            this.Bn20.Size = new System.Drawing.Size(100, 50);
            this.Bn20.TabIndex = 0;
            this.Bn20.Text = "S/. 20";
            this.Bn20.UseVisualStyleBackColor = true;
            this.Bn20.Visible = false;
            this.Bn20.Click += new System.EventHandler(this.Bn20_Click);
            // 
            // Bn50
            // 
            this.Bn50.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.Bn50.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Bn50.FlatAppearance.BorderSize = 0;
            this.Bn50.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.Bn50.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.Bn50.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Bn50.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bn50.ForeColor = System.Drawing.Color.White;
            this.Bn50.Location = new System.Drawing.Point(405, 3);
            this.Bn50.Name = "Bn50";
            this.Bn50.Size = new System.Drawing.Size(100, 50);
            this.Bn50.TabIndex = 0;
            this.Bn50.Text = "S/. 50";
            this.Bn50.UseVisualStyleBackColor = true;
            this.Bn50.Visible = false;
            this.Bn50.Click += new System.EventHandler(this.Bn50_Click);
            // 
            // Bn100
            // 
            this.Bn100.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.Bn100.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Bn100.FlatAppearance.BorderSize = 0;
            this.Bn100.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.Bn100.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.Bn100.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Bn100.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bn100.ForeColor = System.Drawing.Color.White;
            this.Bn100.Location = new System.Drawing.Point(511, 3);
            this.Bn100.Name = "Bn100";
            this.Bn100.Size = new System.Drawing.Size(116, 50);
            this.Bn100.TabIndex = 0;
            this.Bn100.Text = "S/. 100";
            this.Bn100.UseVisualStyleBackColor = true;
            this.Bn100.Visible = false;
            this.Bn100.Click += new System.EventHandler(this.Bn100_Click);
            // 
            // BnExacto
            // 
            this.BnExacto.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.BnExacto.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BnExacto.FlatAppearance.BorderSize = 0;
            this.BnExacto.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BnExacto.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BnExacto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BnExacto.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BnExacto.ForeColor = System.Drawing.Color.White;
            this.BnExacto.Location = new System.Drawing.Point(633, 3);
            this.BnExacto.Name = "BnExacto";
            this.BnExacto.Size = new System.Drawing.Size(130, 50);
            this.BnExacto.TabIndex = 0;
            this.BnExacto.Text = "EXACTO";
            this.BnExacto.UseVisualStyleBackColor = true;
            this.BnExacto.Visible = false;
            this.BnExacto.Click += new System.EventHandler(this.button7_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Black;
            this.panel3.Controls.Add(this.panel35);
            this.panel3.Controls.Add(this.lblUltimoPagoCon);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.lblUltimoVuelto);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.lblUltimoTotal);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.lblUltimoImpuesto);
            this.panel3.Controls.Add(this.lbltipoimpuesto);
            this.panel3.Controls.Add(this.lblUltimoSubtotal);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 889);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1843, 38);
            this.panel3.TabIndex = 2;
            // 
            // panel35
            // 
            this.panel35.Controls.Add(this.label4);
            this.panel35.Controls.Add(this.IndicadorTema);
            this.panel35.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel35.Location = new System.Drawing.Point(1722, 0);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(121, 38);
            this.panel35.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.Dock = System.Windows.Forms.DockStyle.Left;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DimGray;
            this.label4.Location = new System.Drawing.Point(0, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 38);
            this.label4.TabIndex = 1;
            this.label4.Text = "Tema Oscuro";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // IndicadorTema
            // 
            this.IndicadorTema.AutoSize = true;
            this.IndicadorTema.EllipseBorderColor = "#3b73d1";
            this.IndicadorTema.EllipseColor = "#508ef5";
            this.IndicadorTema.Location = new System.Drawing.Point(62, 11);
            this.IndicadorTema.Name = "IndicadorTema";
            this.IndicadorTema.Size = new System.Drawing.Size(47, 19);
            this.IndicadorTema.TabIndex = 0;
            this.IndicadorTema.Text = "uI_MaterialToggle1";
            this.IndicadorTema.UseVisualStyleBackColor = true;
            this.IndicadorTema.CheckedChanged += new System.EventHandler(this.IndicadorTema_CheckedChanged);
            // 
            // lblUltimoPagoCon
            // 
            this.lblUltimoPagoCon.BackColor = System.Drawing.Color.Transparent;
            this.lblUltimoPagoCon.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblUltimoPagoCon.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUltimoPagoCon.ForeColor = System.Drawing.Color.Gold;
            this.lblUltimoPagoCon.Location = new System.Drawing.Point(1123, 0);
            this.lblUltimoPagoCon.Name = "lblUltimoPagoCon";
            this.lblUltimoPagoCon.Size = new System.Drawing.Size(117, 38);
            this.lblUltimoPagoCon.TabIndex = 10;
            this.lblUltimoPagoCon.Text = "0.00";
            this.lblUltimoPagoCon.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Dock = System.Windows.Forms.DockStyle.Left;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(993, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(130, 38);
            this.label2.TabIndex = 9;
            this.label2.Text = "Ultimo pago con:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblUltimoVuelto
            // 
            this.lblUltimoVuelto.BackColor = System.Drawing.Color.Transparent;
            this.lblUltimoVuelto.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblUltimoVuelto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUltimoVuelto.ForeColor = System.Drawing.Color.Gold;
            this.lblUltimoVuelto.Location = new System.Drawing.Point(876, 0);
            this.lblUltimoVuelto.Name = "lblUltimoVuelto";
            this.lblUltimoVuelto.Size = new System.Drawing.Size(117, 38);
            this.lblUltimoVuelto.TabIndex = 8;
            this.lblUltimoVuelto.Text = "0.00";
            this.lblUltimoVuelto.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Dock = System.Windows.Forms.DockStyle.Left;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(746, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(130, 38);
            this.label8.TabIndex = 7;
            this.label8.Text = "Ultimo Vuelto:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblUltimoTotal
            // 
            this.lblUltimoTotal.BackColor = System.Drawing.Color.Transparent;
            this.lblUltimoTotal.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblUltimoTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUltimoTotal.ForeColor = System.Drawing.Color.Gold;
            this.lblUltimoTotal.Location = new System.Drawing.Point(629, 0);
            this.lblUltimoTotal.Name = "lblUltimoTotal";
            this.lblUltimoTotal.Size = new System.Drawing.Size(117, 38);
            this.lblUltimoTotal.TabIndex = 6;
            this.lblUltimoTotal.Text = "0.00";
            this.lblUltimoTotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Dock = System.Windows.Forms.DockStyle.Left;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(499, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(130, 38);
            this.label6.TabIndex = 5;
            this.label6.Text = "Ultimo Total:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblUltimoImpuesto
            // 
            this.lblUltimoImpuesto.BackColor = System.Drawing.Color.Transparent;
            this.lblUltimoImpuesto.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblUltimoImpuesto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUltimoImpuesto.ForeColor = System.Drawing.Color.Gold;
            this.lblUltimoImpuesto.Location = new System.Drawing.Point(382, 0);
            this.lblUltimoImpuesto.Name = "lblUltimoImpuesto";
            this.lblUltimoImpuesto.Size = new System.Drawing.Size(117, 38);
            this.lblUltimoImpuesto.TabIndex = 4;
            this.lblUltimoImpuesto.Text = "0.00";
            this.lblUltimoImpuesto.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbltipoimpuesto
            // 
            this.lbltipoimpuesto.BackColor = System.Drawing.Color.Transparent;
            this.lbltipoimpuesto.Dock = System.Windows.Forms.DockStyle.Left;
            this.lbltipoimpuesto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltipoimpuesto.ForeColor = System.Drawing.Color.White;
            this.lbltipoimpuesto.Location = new System.Drawing.Point(247, 0);
            this.lbltipoimpuesto.Name = "lbltipoimpuesto";
            this.lbltipoimpuesto.Size = new System.Drawing.Size(135, 38);
            this.lbltipoimpuesto.TabIndex = 3;
            this.lbltipoimpuesto.Text = "Ultimo IGV(18%):";
            this.lbltipoimpuesto.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblUltimoSubtotal
            // 
            this.lblUltimoSubtotal.BackColor = System.Drawing.Color.Transparent;
            this.lblUltimoSubtotal.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblUltimoSubtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUltimoSubtotal.ForeColor = System.Drawing.Color.Gold;
            this.lblUltimoSubtotal.Location = new System.Drawing.Point(130, 0);
            this.lblUltimoSubtotal.Name = "lblUltimoSubtotal";
            this.lblUltimoSubtotal.Size = new System.Drawing.Size(117, 38);
            this.lblUltimoSubtotal.TabIndex = 2;
            this.lblUltimoSubtotal.Text = "0.00";
            this.lblUltimoSubtotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Dock = System.Windows.Forms.DockStyle.Left;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 38);
            this.label1.TabIndex = 1;
            this.label1.Text = "Ultimo SubTotal:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // PanelVentasGeneral
            // 
            this.PanelVentasGeneral.Controls.Add(this.panel1);
            this.PanelVentasGeneral.Controls.Add(this.PanelDetalleVenta);
            this.PanelVentasGeneral.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelVentasGeneral.Location = new System.Drawing.Point(0, 0);
            this.PanelVentasGeneral.Name = "PanelVentasGeneral";
            this.PanelVentasGeneral.Size = new System.Drawing.Size(1843, 889);
            this.PanelVentasGeneral.TabIndex = 3;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Panel9);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(476, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1367, 889);
            this.panel1.TabIndex = 2;
            // 
            // Panel9
            // 
            this.Panel9.Controls.Add(this.Panel_grupos);
            this.Panel9.Controls.Add(this.panel7);
            this.Panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Panel9.Location = new System.Drawing.Point(270, 367);
            this.Panel9.Name = "Panel9";
            this.Panel9.Size = new System.Drawing.Size(1097, 522);
            this.Panel9.TabIndex = 3;
            // 
            // Panel_grupos
            // 
            this.Panel_grupos.AutoScroll = true;
            this.Panel_grupos.Controls.Add(this.panelCobro);
            this.Panel_grupos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Panel_grupos.Location = new System.Drawing.Point(0, 42);
            this.Panel_grupos.Name = "Panel_grupos";
            this.Panel_grupos.Size = new System.Drawing.Size(1097, 480);
            this.Panel_grupos.TabIndex = 1;
            // 
            // panelCobro
            // 
            this.panelCobro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.panelCobro.Controls.Add(this.dgClientes);
            this.panelCobro.Controls.Add(this.panelClienteFactura);
            this.panelCobro.Controls.Add(this.lblComprobante);
            this.panelCobro.Controls.Add(this.Panelcomprobante);
            this.panelCobro.Controls.Add(this.panelReport);
            this.panelCobro.Controls.Add(this.btnguardar);
            this.panelCobro.Controls.Add(this.lbltotal);
            this.panelCobro.Controls.Add(this.label10);
            this.panelCobro.Controls.Add(this.panel8);
            this.panelCobro.Controls.Add(this.btncerrar);
            this.panelCobro.Location = new System.Drawing.Point(3, 3);
            this.panelCobro.Name = "panelCobro";
            this.panelCobro.Size = new System.Drawing.Size(883, 402);
            this.panelCobro.TabIndex = 626;
            this.panelCobro.Visible = false;
            // 
            // dgClientes
            // 
            this.dgClientes.AllowUserToAddRows = false;
            this.dgClientes.AllowUserToDeleteRows = false;
            this.dgClientes.AllowUserToResizeRows = false;
            this.dgClientes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgClientes.BackgroundColor = System.Drawing.Color.White;
            this.dgClientes.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgClientes.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgClientes.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgClientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgClientes.ColumnHeadersVisible = false;
            this.dgClientes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dgClientes.EnableHeadersVisualStyles = false;
            this.dgClientes.Location = new System.Drawing.Point(524, 289);
            this.dgClientes.MultiSelect = false;
            this.dgClientes.Name = "dgClientes";
            this.dgClientes.ReadOnly = true;
            this.dgClientes.RowHeadersVisible = false;
            this.dgClientes.RowHeadersWidth = 9;
            this.dgClientes.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgClientes.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.WhiteSmoke;
            this.dgClientes.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgClientes.RowTemplate.Height = 40;
            this.dgClientes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgClientes.Size = new System.Drawing.Size(144, 78);
            this.dgClientes.TabIndex = 643;
            this.dgClientes.Visible = false;
            this.dgClientes.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgClientes_CellClick);
            // 
            // panelClienteFactura
            // 
            this.panelClienteFactura.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panelClienteFactura.Controls.Add(this.btnAgregarcliente);
            this.panelClienteFactura.Controls.Add(this.lblCliente);
            this.panelClienteFactura.Controls.Add(this.txtbuscarcliente);
            this.panelClienteFactura.Location = new System.Drawing.Point(515, 233);
            this.panelClienteFactura.Name = "panelClienteFactura";
            this.panelClienteFactura.Size = new System.Drawing.Size(362, 75);
            this.panelClienteFactura.TabIndex = 642;
            // 
            // btnAgregarcliente
            // 
            this.btnAgregarcliente.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnAgregarcliente.FlatAppearance.BorderSize = 0;
            this.btnAgregarcliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAgregarcliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAgregarcliente.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAgregarcliente.Location = new System.Drawing.Point(303, 32);
            this.btnAgregarcliente.Name = "btnAgregarcliente";
            this.btnAgregarcliente.Size = new System.Drawing.Size(55, 40);
            this.btnAgregarcliente.TabIndex = 456;
            this.btnAgregarcliente.Text = "+";
            this.btnAgregarcliente.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAgregarcliente.UseVisualStyleBackColor = false;
            this.btnAgregarcliente.Click += new System.EventHandler(this.btnAgregarcliente_Click);
            // 
            // lblCliente
            // 
            this.lblCliente.AutoSize = true;
            this.lblCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.lblCliente.ForeColor = System.Drawing.Color.DimGray;
            this.lblCliente.Location = new System.Drawing.Point(10, 9);
            this.lblCliente.Name = "lblCliente";
            this.lblCliente.Size = new System.Drawing.Size(157, 20);
            this.lblCliente.TabIndex = 0;
            this.lblCliente.Text = "Cliente: (Opcional)";
            // 
            // txtbuscarcliente
            // 
            this.txtbuscarcliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.txtbuscarcliente.Location = new System.Drawing.Point(9, 37);
            this.txtbuscarcliente.Name = "txtbuscarcliente";
            this.txtbuscarcliente.Size = new System.Drawing.Size(288, 30);
            this.txtbuscarcliente.TabIndex = 455;
            this.txtbuscarcliente.TextChanged += new System.EventHandler(this.txtbuscarcliente_TextChanged);
            // 
            // lblComprobante
            // 
            this.lblComprobante.AutoSize = true;
            this.lblComprobante.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold);
            this.lblComprobante.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblComprobante.Location = new System.Drawing.Point(515, 70);
            this.lblComprobante.Name = "lblComprobante";
            this.lblComprobante.Size = new System.Drawing.Size(24, 31);
            this.lblComprobante.TabIndex = 641;
            this.lblComprobante.Text = "-";
            this.lblComprobante.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Panelcomprobante
            // 
            this.Panelcomprobante.AutoScroll = true;
            this.Panelcomprobante.Location = new System.Drawing.Point(515, 104);
            this.Panelcomprobante.Name = "Panelcomprobante";
            this.Panelcomprobante.Size = new System.Drawing.Size(362, 123);
            this.Panelcomprobante.TabIndex = 640;
            // 
            // panelReport
            // 
            this.panelReport.Controls.Add(this.label9);
            this.panelReport.Controls.Add(this.btnAceptar);
            this.panelReport.Controls.Add(this.pictureBox3);
            this.panelReport.Controls.Add(this.reportViewer1);
            this.panelReport.Location = new System.Drawing.Point(779, 8);
            this.panelReport.Name = "panelReport";
            this.panelReport.Size = new System.Drawing.Size(23, 27);
            this.panelReport.TabIndex = 638;
            this.panelReport.Visible = false;
            // 
            // label9
            // 
            this.label9.Dock = System.Windows.Forms.DockStyle.Top;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Silver;
            this.label9.Location = new System.Drawing.Point(467, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(0, 149);
            this.label9.TabIndex = 640;
            this.label9.Text = "Venta realizada \r\ncorrectamente";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnAceptar
            // 
            this.btnAceptar.BackColor = System.Drawing.Color.Transparent;
            this.btnAceptar.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.btnAceptar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAceptar.FlatAppearance.BorderSize = 0;
            this.btnAceptar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnAceptar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnAceptar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAceptar.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAceptar.ForeColor = System.Drawing.Color.White;
            this.btnAceptar.Location = new System.Drawing.Point(477, 167);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(145, 76);
            this.btnAceptar.TabIndex = 639;
            this.btnAceptar.Text = "Aceptar";
            this.btnAceptar.UseVisualStyleBackColor = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pictureBox3.Image = global::RestCsharp.Properties.Resources.Buman;
            this.pictureBox3.Location = new System.Drawing.Point(467, -100);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(0, 127);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 638;
            this.pictureBox3.TabStop = false;
            // 
            // reportViewer1
            // 
            this.reportViewer1.AccessibilityKeyMap = null;
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Left;
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(467, 27);
            this.reportViewer1.TabIndex = 637;
            this.reportViewer1.ViewMode = Telerik.ReportViewer.WinForms.ViewMode.PrintPreview;
            // 
            // btnguardar
            // 
            this.btnguardar.BackColor = System.Drawing.Color.Transparent;
            this.btnguardar.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.btnguardar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnguardar.FlatAppearance.BorderSize = 0;
            this.btnguardar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnguardar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnguardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnguardar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnguardar.ForeColor = System.Drawing.Color.White;
            this.btnguardar.Location = new System.Drawing.Point(720, 326);
            this.btnguardar.Name = "btnguardar";
            this.btnguardar.Size = new System.Drawing.Size(157, 64);
            this.btnguardar.TabIndex = 618;
            this.btnguardar.Text = "Guardar";
            this.btnguardar.UseVisualStyleBackColor = false;
            this.btnguardar.Click += new System.EventHandler(this.btnguardar_Click);
            // 
            // lbltotal
            // 
            this.lbltotal.AutoSize = true;
            this.lbltotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold);
            this.lbltotal.ForeColor = System.Drawing.Color.White;
            this.lbltotal.Location = new System.Drawing.Point(137, 8);
            this.lbltotal.Name = "lbltotal";
            this.lbltotal.Size = new System.Drawing.Size(147, 46);
            this.lbltotal.TabIndex = 624;
            this.lbltotal.Text = "10 000";
            this.lbltotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(6, 8);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(120, 46);
            this.label10.TabIndex = 623;
            this.label10.Text = "Total:";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.panel34);
            this.panel8.Controls.Add(this.label3);
            this.panel8.Controls.Add(this.txtreferencia);
            this.panel8.Controls.Add(this.btnTecladodigitos);
            this.panel8.Controls.Add(this.btnTecladoTarjeta);
            this.panel8.Controls.Add(this.btnTecladoEfectivo);
            this.panel8.Controls.Add(this.txtrestante);
            this.panel8.Controls.Add(this.label12);
            this.panel8.Controls.Add(this.panel24);
            this.panel8.Controls.Add(this.txtvuelto);
            this.panel8.Controls.Add(this.Label31);
            this.panel8.Controls.Add(this.txttarjeta);
            this.panel8.Controls.Add(this.panel25);
            this.panel8.Controls.Add(this.label13);
            this.panel8.Controls.Add(this.txtefectivo);
            this.panel8.Controls.Add(this.panel31);
            this.panel8.Controls.Add(this.label21);
            this.panel8.Location = new System.Drawing.Point(13, 57);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(496, 324);
            this.panel8.TabIndex = 4;
            // 
            // panel34
            // 
            this.panel34.BackColor = System.Drawing.Color.White;
            this.panel34.Location = new System.Drawing.Point(123, 168);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(180, 2);
            this.panel34.TabIndex = 640;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label3.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label3.Location = new System.Drawing.Point(120, 118);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 17);
            this.label3.TabIndex = 639;
            this.label3.Text = "4 ultimos sigitos";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtreferencia
            // 
            this.txtreferencia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.txtreferencia.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtreferencia.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold);
            this.txtreferencia.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtreferencia.Location = new System.Drawing.Point(123, 133);
            this.txtreferencia.MaxLength = 4;
            this.txtreferencia.Name = "txtreferencia";
            this.txtreferencia.Size = new System.Drawing.Size(171, 31);
            this.txtreferencia.TabIndex = 641;
            this.txtreferencia.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtreferencia_KeyPress);
            // 
            // btnTecladodigitos
            // 
            this.btnTecladodigitos.AddControl = this.txtreferencia;
            this.btnTecladodigitos.BackColor = System.Drawing.Color.Transparent;
            this.btnTecladodigitos.BackgroundImage = global::RestCsharp.Properties.Resources.azul;
            this.btnTecladodigitos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTecladodigitos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTecladodigitos.FlatAppearance.BorderSize = 0;
            this.btnTecladodigitos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnTecladodigitos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnTecladodigitos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTecladodigitos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTecladodigitos.ForeColor = System.Drawing.Color.White;
            this.btnTecladodigitos.IconKeyBoardColor = System.Drawing.SystemColors.ControlText;
            this.btnTecladodigitos.IconKeyBoardSize = 20;
            this.btnTecladodigitos.Location = new System.Drawing.Point(312, 157);
            this.btnTecladodigitos.Mode = UIDC.UI_TecladoNumerico.SEE.Claro;
            this.btnTecladodigitos.Name = "btnTecladodigitos";
            this.btnTecladodigitos.Size = new System.Drawing.Size(184, 57);
            this.btnTecladodigitos.TabIndex = 635;
            this.btnTecladodigitos.Text = "Teclado 4 digitos";
            this.btnTecladodigitos.UseVisualStyleBackColor = false;
            // 
            // btnTecladoTarjeta
            // 
            this.btnTecladoTarjeta.AddControl = this.txttarjeta;
            this.btnTecladoTarjeta.BackColor = System.Drawing.Color.Transparent;
            this.btnTecladoTarjeta.BackgroundImage = global::RestCsharp.Properties.Resources.azul;
            this.btnTecladoTarjeta.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTecladoTarjeta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTecladoTarjeta.FlatAppearance.BorderSize = 0;
            this.btnTecladoTarjeta.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnTecladoTarjeta.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnTecladoTarjeta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTecladoTarjeta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTecladoTarjeta.ForeColor = System.Drawing.Color.White;
            this.btnTecladoTarjeta.IconKeyBoardColor = System.Drawing.SystemColors.ControlText;
            this.btnTecladoTarjeta.IconKeyBoardSize = 20;
            this.btnTecladoTarjeta.Location = new System.Drawing.Point(309, 76);
            this.btnTecladoTarjeta.Mode = UIDC.UI_TecladoNumerico.SEE.Claro;
            this.btnTecladoTarjeta.Name = "btnTecladoTarjeta";
            this.btnTecladoTarjeta.Size = new System.Drawing.Size(184, 57);
            this.btnTecladoTarjeta.TabIndex = 635;
            this.btnTecladoTarjeta.Text = "Teclado Tarjeta";
            this.btnTecladoTarjeta.UseVisualStyleBackColor = false;
            // 
            // txttarjeta
            // 
            this.txttarjeta.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.txttarjeta.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txttarjeta.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold);
            this.txttarjeta.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txttarjeta.Location = new System.Drawing.Point(120, 69);
            this.txttarjeta.Name = "txttarjeta";
            this.txttarjeta.Size = new System.Drawing.Size(177, 38);
            this.txttarjeta.TabIndex = 560;
            this.txttarjeta.TextChanged += new System.EventHandler(this.txttarjeta_TextChanged);
            this.txttarjeta.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txttarjeta_KeyPress);
            // 
            // btnTecladoEfectivo
            // 
            this.btnTecladoEfectivo.AddControl = this.txtefectivo;
            this.btnTecladoEfectivo.BackColor = System.Drawing.Color.Transparent;
            this.btnTecladoEfectivo.BackgroundImage = global::RestCsharp.Properties.Resources.azul;
            this.btnTecladoEfectivo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTecladoEfectivo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTecladoEfectivo.FlatAppearance.BorderSize = 0;
            this.btnTecladoEfectivo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnTecladoEfectivo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnTecladoEfectivo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTecladoEfectivo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTecladoEfectivo.ForeColor = System.Drawing.Color.White;
            this.btnTecladoEfectivo.IconKeyBoardColor = System.Drawing.SystemColors.ControlText;
            this.btnTecladoEfectivo.IconKeyBoardSize = 20;
            this.btnTecladoEfectivo.Location = new System.Drawing.Point(309, 3);
            this.btnTecladoEfectivo.Mode = UIDC.UI_TecladoNumerico.SEE.Claro;
            this.btnTecladoEfectivo.Name = "btnTecladoEfectivo";
            this.btnTecladoEfectivo.Size = new System.Drawing.Size(184, 57);
            this.btnTecladoEfectivo.TabIndex = 635;
            this.btnTecladoEfectivo.Text = "Teclado Efectivo";
            this.btnTecladoEfectivo.UseVisualStyleBackColor = false;
            // 
            // txtefectivo
            // 
            this.txtefectivo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.txtefectivo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtefectivo.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold);
            this.txtefectivo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtefectivo.Location = new System.Drawing.Point(127, 6);
            this.txtefectivo.Name = "txtefectivo";
            this.txtefectivo.Size = new System.Drawing.Size(177, 38);
            this.txtefectivo.TabIndex = 557;
            this.txtefectivo.TextChanged += new System.EventHandler(this.txtefectivo_TextChanged);
            this.txtefectivo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtefectivo_KeyPress);
            // 
            // txtrestante
            // 
            this.txtrestante.AutoSize = true;
            this.txtrestante.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold);
            this.txtrestante.ForeColor = System.Drawing.Color.Gray;
            this.txtrestante.Location = new System.Drawing.Point(127, 251);
            this.txtrestante.Name = "txtrestante";
            this.txtrestante.Size = new System.Drawing.Size(27, 29);
            this.txtrestante.TabIndex = 626;
            this.txtrestante.Text = "0";
            this.txtrestante.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label12.ForeColor = System.Drawing.Color.Gray;
            this.label12.Location = new System.Drawing.Point(10, 251);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(114, 29);
            this.label12.TabIndex = 627;
            this.label12.Text = "Restante:";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel24.Location = new System.Drawing.Point(11, 246);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(308, 2);
            this.panel24.TabIndex = 625;
            // 
            // txtvuelto
            // 
            this.txtvuelto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.txtvuelto.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtvuelto.Enabled = false;
            this.txtvuelto.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold);
            this.txtvuelto.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.txtvuelto.Location = new System.Drawing.Point(161, 194);
            this.txtvuelto.Name = "txtvuelto";
            this.txtvuelto.Size = new System.Drawing.Size(227, 46);
            this.txtvuelto.TabIndex = 624;
            this.txtvuelto.Text = "0";
            // 
            // Label31
            // 
            this.Label31.AutoSize = true;
            this.Label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.Label31.ForeColor = System.Drawing.Color.White;
            this.Label31.Location = new System.Drawing.Point(10, 194);
            this.Label31.Name = "Label31";
            this.Label31.Size = new System.Drawing.Size(145, 46);
            this.Label31.TabIndex = 622;
            this.Label31.Text = "Vuelto:";
            this.Label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel25.Location = new System.Drawing.Point(120, 113);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(180, 2);
            this.panel25.TabIndex = 559;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label13.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label13.Location = new System.Drawing.Point(23, 87);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(95, 29);
            this.label13.TabIndex = 558;
            this.label13.Text = "Tarjeta:";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel31
            // 
            this.panel31.BackColor = System.Drawing.Color.SeaGreen;
            this.panel31.Location = new System.Drawing.Point(123, 49);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(180, 2);
            this.panel31.TabIndex = 556;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label21.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label21.Location = new System.Drawing.Point(17, 22);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(104, 29);
            this.label21.TabIndex = 555;
            this.label21.Text = "Efectivo:";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btncerrar
            // 
            this.btncerrar.BackColor = System.Drawing.Color.Transparent;
            this.btncerrar.BackgroundImage = global::RestCsharp.Properties.Resources.Rojo;
            this.btncerrar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btncerrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btncerrar.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btncerrar.FlatAppearance.BorderSize = 0;
            this.btncerrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btncerrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btncerrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncerrar.Font = new System.Drawing.Font("Calibri", 35F, System.Drawing.FontStyle.Bold);
            this.btncerrar.ForeColor = System.Drawing.Color.White;
            this.btncerrar.Location = new System.Drawing.Point(808, 8);
            this.btncerrar.Name = "btncerrar";
            this.btncerrar.Size = new System.Drawing.Size(69, 65);
            this.btncerrar.TabIndex = 621;
            this.btncerrar.Text = "X";
            this.btncerrar.UseVisualStyleBackColor = false;
            this.btncerrar.Click += new System.EventHandler(this.btncerrar_Click);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.panel7.Controls.Add(this.label22);
            this.panel7.Controls.Add(this.btngrupoAtras);
            this.panel7.Controls.Add(this.btnGrupoadelante);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1097, 42);
            this.panel7.TabIndex = 2;
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(141, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(815, 42);
            this.label22.TabIndex = 639;
            this.label22.Text = "MENU";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btngrupoAtras
            // 
            this.btngrupoAtras.BackColor = System.Drawing.Color.Transparent;
            this.btngrupoAtras.BackgroundImage = global::RestCsharp.Properties.Resources.fecha_izquierda;
            this.btngrupoAtras.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btngrupoAtras.Dock = System.Windows.Forms.DockStyle.Left;
            this.btngrupoAtras.FlatAppearance.BorderSize = 0;
            this.btngrupoAtras.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btngrupoAtras.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btngrupoAtras.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btngrupoAtras.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btngrupoAtras.ForeColor = System.Drawing.Color.White;
            this.btngrupoAtras.Location = new System.Drawing.Point(0, 0);
            this.btngrupoAtras.Name = "btngrupoAtras";
            this.btngrupoAtras.Size = new System.Drawing.Size(141, 42);
            this.btngrupoAtras.TabIndex = 638;
            this.btngrupoAtras.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btngrupoAtras.UseVisualStyleBackColor = false;
            this.btngrupoAtras.Click += new System.EventHandler(this.btngrupoAtras_Click_1);
            // 
            // btnGrupoadelante
            // 
            this.btnGrupoadelante.BackColor = System.Drawing.Color.Transparent;
            this.btnGrupoadelante.BackgroundImage = global::RestCsharp.Properties.Resources.fecha_derecha;
            this.btnGrupoadelante.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnGrupoadelante.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnGrupoadelante.FlatAppearance.BorderSize = 0;
            this.btnGrupoadelante.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnGrupoadelante.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnGrupoadelante.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGrupoadelante.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGrupoadelante.ForeColor = System.Drawing.Color.White;
            this.btnGrupoadelante.Location = new System.Drawing.Point(956, 0);
            this.btnGrupoadelante.Name = "btnGrupoadelante";
            this.btnGrupoadelante.Size = new System.Drawing.Size(141, 42);
            this.btnGrupoadelante.TabIndex = 637;
            this.btnGrupoadelante.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnGrupoadelante.UseVisualStyleBackColor = false;
            this.btnGrupoadelante.Click += new System.EventHandler(this.btnGrupoadelante_Click_1);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.PanelProductos);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(270, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1097, 367);
            this.panel4.TabIndex = 2;
            // 
            // PanelProductos
            // 
            this.PanelProductos.Controls.Add(this.flowLayoutPanel5);
            this.PanelProductos.Controls.Add(this.panel32);
            this.PanelProductos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelProductos.Location = new System.Drawing.Point(0, 0);
            this.PanelProductos.Name = "PanelProductos";
            this.PanelProductos.Size = new System.Drawing.Size(1097, 367);
            this.PanelProductos.TabIndex = 1;
            // 
            // flowLayoutPanel5
            // 
            this.flowLayoutPanel5.AutoScroll = true;
            this.flowLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel5.Location = new System.Drawing.Point(0, 35);
            this.flowLayoutPanel5.Name = "flowLayoutPanel5";
            this.flowLayoutPanel5.Size = new System.Drawing.Size(1097, 332);
            this.flowLayoutPanel5.TabIndex = 5;
            // 
            // panel32
            // 
            this.panel32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(231)))), ((int)(((byte)(89)))));
            this.panel32.Controls.Add(this.Label16);
            this.panel32.Controls.Add(this.btnatras);
            this.panel32.Controls.Add(this.btnadelante);
            this.panel32.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel32.Location = new System.Drawing.Point(0, 0);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(1097, 35);
            this.panel32.TabIndex = 6;
            // 
            // Label16
            // 
            this.Label16.BackColor = System.Drawing.Color.Transparent;
            this.Label16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Label16.Location = new System.Drawing.Point(141, 0);
            this.Label16.Name = "Label16";
            this.Label16.Size = new System.Drawing.Size(815, 35);
            this.Label16.TabIndex = 11;
            this.Label16.Text = "PRODUCTOS ";
            this.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnatras
            // 
            this.btnatras.BackColor = System.Drawing.Color.Transparent;
            this.btnatras.BackgroundImage = global::RestCsharp.Properties.Resources.fecha_izquierda;
            this.btnatras.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnatras.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnatras.FlatAppearance.BorderSize = 0;
            this.btnatras.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnatras.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnatras.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnatras.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnatras.ForeColor = System.Drawing.Color.White;
            this.btnatras.Location = new System.Drawing.Point(0, 0);
            this.btnatras.Name = "btnatras";
            this.btnatras.Size = new System.Drawing.Size(141, 35);
            this.btnatras.TabIndex = 10;
            this.btnatras.UseVisualStyleBackColor = false;
            this.btnatras.Click += new System.EventHandler(this.btnatras_Click_1);
            // 
            // btnadelante
            // 
            this.btnadelante.BackColor = System.Drawing.Color.Transparent;
            this.btnadelante.BackgroundImage = global::RestCsharp.Properties.Resources.fecha_derecha;
            this.btnadelante.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnadelante.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnadelante.FlatAppearance.BorderSize = 0;
            this.btnadelante.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnadelante.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnadelante.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnadelante.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadelante.ForeColor = System.Drawing.Color.White;
            this.btnadelante.Location = new System.Drawing.Point(956, 0);
            this.btnadelante.Name = "btnadelante";
            this.btnadelante.Size = new System.Drawing.Size(141, 35);
            this.btnadelante.TabIndex = 9;
            this.btnadelante.UseVisualStyleBackColor = false;
            this.btnadelante.Click += new System.EventHandler(this.btnadelante_Click_1);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.FlowLayoutPanel4);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(270, 889);
            this.panel5.TabIndex = 1;
            // 
            // FlowLayoutPanel4
            // 
            this.FlowLayoutPanel4.Controls.Add(this.btnvermesas);
            this.FlowLayoutPanel4.Controls.Add(this.btnDividirCuenta);
            this.FlowLayoutPanel4.Controls.Add(this.btnPrecuenta);
            this.FlowLayoutPanel4.Controls.Add(this.btneliminarVenta);
            this.FlowLayoutPanel4.Controls.Add(this.btnEnviarpedido);
            this.FlowLayoutPanel4.Controls.Add(this.btnNotas);
            this.FlowLayoutPanel4.Controls.Add(this.btnBuscar);
            this.FlowLayoutPanel4.Controls.Add(this.panel29);
            this.FlowLayoutPanel4.Controls.Add(this.panelNotas);
            this.FlowLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FlowLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.FlowLayoutPanel4.Name = "FlowLayoutPanel4";
            this.FlowLayoutPanel4.Size = new System.Drawing.Size(270, 889);
            this.FlowLayoutPanel4.TabIndex = 1;
            // 
            // btnvermesas
            // 
            this.btnvermesas.BackColor = System.Drawing.Color.Transparent;
            this.btnvermesas.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.btnvermesas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnvermesas.FlatAppearance.BorderSize = 0;
            this.btnvermesas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnvermesas.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnvermesas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnvermesas.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnvermesas.ForeColor = System.Drawing.Color.White;
            this.btnvermesas.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnvermesas.Location = new System.Drawing.Point(3, 3);
            this.btnvermesas.Name = "btnvermesas";
            this.btnvermesas.Size = new System.Drawing.Size(240, 61);
            this.btnvermesas.TabIndex = 632;
            this.btnvermesas.Text = "Ver mesas";
            this.btnvermesas.UseVisualStyleBackColor = false;
            this.btnvermesas.Click += new System.EventHandler(this.btnvermesas_Click);
            // 
            // btnDividirCuenta
            // 
            this.btnDividirCuenta.BackColor = System.Drawing.Color.Transparent;
            this.btnDividirCuenta.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.btnDividirCuenta.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDividirCuenta.FlatAppearance.BorderSize = 0;
            this.btnDividirCuenta.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnDividirCuenta.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnDividirCuenta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDividirCuenta.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDividirCuenta.ForeColor = System.Drawing.Color.White;
            this.btnDividirCuenta.Location = new System.Drawing.Point(3, 70);
            this.btnDividirCuenta.Name = "btnDividirCuenta";
            this.btnDividirCuenta.Size = new System.Drawing.Size(117, 77);
            this.btnDividirCuenta.TabIndex = 633;
            this.btnDividirCuenta.Text = "Dividir Cuenta";
            this.btnDividirCuenta.UseVisualStyleBackColor = false;
            this.btnDividirCuenta.Click += new System.EventHandler(this.btnDividirCuenta_Click);
            // 
            // btnPrecuenta
            // 
            this.btnPrecuenta.BackColor = System.Drawing.Color.Transparent;
            this.btnPrecuenta.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.btnPrecuenta.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPrecuenta.FlatAppearance.BorderSize = 0;
            this.btnPrecuenta.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnPrecuenta.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnPrecuenta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrecuenta.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrecuenta.ForeColor = System.Drawing.Color.White;
            this.btnPrecuenta.Location = new System.Drawing.Point(126, 70);
            this.btnPrecuenta.Name = "btnPrecuenta";
            this.btnPrecuenta.Size = new System.Drawing.Size(117, 77);
            this.btnPrecuenta.TabIndex = 635;
            this.btnPrecuenta.Text = "PRE Cuenta";
            this.btnPrecuenta.UseVisualStyleBackColor = false;
            this.btnPrecuenta.Visible = false;
            this.btnPrecuenta.Click += new System.EventHandler(this.btnPrecuenta_Click);
            // 
            // btneliminarVenta
            // 
            this.btneliminarVenta.BackColor = System.Drawing.Color.Transparent;
            this.btneliminarVenta.BackgroundImage = global::RestCsharp.Properties.Resources.Rojo;
            this.btneliminarVenta.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btneliminarVenta.FlatAppearance.BorderSize = 0;
            this.btneliminarVenta.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btneliminarVenta.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btneliminarVenta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btneliminarVenta.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btneliminarVenta.ForeColor = System.Drawing.Color.White;
            this.btneliminarVenta.Image = global::RestCsharp.Properties.Resources.quitar;
            this.btneliminarVenta.Location = new System.Drawing.Point(3, 153);
            this.btneliminarVenta.Name = "btneliminarVenta";
            this.btneliminarVenta.Size = new System.Drawing.Size(117, 77);
            this.btneliminarVenta.TabIndex = 636;
            this.btneliminarVenta.Text = "Eliminar";
            this.btneliminarVenta.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btneliminarVenta.UseVisualStyleBackColor = false;
            this.btneliminarVenta.Click += new System.EventHandler(this.btneliminarVenta_Click);
            // 
            // btnEnviarpedido
            // 
            this.btnEnviarpedido.BackColor = System.Drawing.Color.Transparent;
            this.btnEnviarpedido.BackgroundImage = global::RestCsharp.Properties.Resources.azul;
            this.btnEnviarpedido.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnEnviarpedido.FlatAppearance.BorderSize = 0;
            this.btnEnviarpedido.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnEnviarpedido.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnEnviarpedido.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEnviarpedido.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnviarpedido.ForeColor = System.Drawing.Color.White;
            this.btnEnviarpedido.Image = global::RestCsharp.Properties.Resources.telegram__1_;
            this.btnEnviarpedido.Location = new System.Drawing.Point(126, 153);
            this.btnEnviarpedido.Name = "btnEnviarpedido";
            this.btnEnviarpedido.Size = new System.Drawing.Size(117, 77);
            this.btnEnviarpedido.TabIndex = 637;
            this.btnEnviarpedido.Text = "Enviar";
            this.btnEnviarpedido.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnEnviarpedido.UseVisualStyleBackColor = false;
            this.btnEnviarpedido.Click += new System.EventHandler(this.btnEnviarpedido_Click);
            // 
            // btnNotas
            // 
            this.btnNotas.BackColor = System.Drawing.Color.Transparent;
            this.btnNotas.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.btnNotas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnNotas.FlatAppearance.BorderSize = 0;
            this.btnNotas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnNotas.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnNotas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNotas.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.btnNotas.ForeColor = System.Drawing.Color.White;
            this.btnNotas.Location = new System.Drawing.Point(3, 236);
            this.btnNotas.Name = "btnNotas";
            this.btnNotas.Size = new System.Drawing.Size(117, 77);
            this.btnNotas.TabIndex = 644;
            this.btnNotas.Text = "NOTAS";
            this.btnNotas.UseVisualStyleBackColor = false;
            this.btnNotas.Click += new System.EventHandler(this.btnNotas_Click);
            // 
            // btnBuscar
            // 
            this.btnBuscar.BackColor = System.Drawing.Color.Transparent;
            this.btnBuscar.BackgroundImage = global::RestCsharp.Properties.Resources.negro;
            this.btnBuscar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBuscar.FlatAppearance.BorderSize = 0;
            this.btnBuscar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnBuscar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnBuscar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBuscar.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnBuscar.ForeColor = System.Drawing.Color.White;
            this.btnBuscar.Location = new System.Drawing.Point(126, 236);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(117, 77);
            this.btnBuscar.TabIndex = 645;
            this.btnBuscar.Text = "Buscar EN CONSTRUCCION";
            this.btnBuscar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBuscar.UseVisualStyleBackColor = false;
            this.btnBuscar.Visible = false;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // panel29
            // 
            this.panel29.Controls.Add(this.richTextBox1);
            this.panel29.Controls.Add(this.datalistadoPedidos);
            this.panel29.Controls.Add(this.rptPedidos);
            this.panel29.Location = new System.Drawing.Point(3, 319);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(265, 11);
            this.panel29.TabIndex = 642;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(6, 16);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(261, 79);
            this.richTextBox1.TabIndex = 638;
            this.richTextBox1.Text = "";
            // 
            // datalistadoPedidos
            // 
            this.datalistadoPedidos.AllowUserToAddRows = false;
            this.datalistadoPedidos.AllowUserToDeleteRows = false;
            this.datalistadoPedidos.AllowUserToResizeRows = false;
            this.datalistadoPedidos.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.datalistadoPedidos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.datalistadoPedidos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datalistadoPedidos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Iddetalleventa,
            this.Importe});
            this.datalistadoPedidos.Location = new System.Drawing.Point(6, 101);
            this.datalistadoPedidos.Name = "datalistadoPedidos";
            this.datalistadoPedidos.ReadOnly = true;
            this.datalistadoPedidos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datalistadoPedidos.Size = new System.Drawing.Size(117, 90);
            this.datalistadoPedidos.TabIndex = 641;
            // 
            // Iddetalleventa
            // 
            this.Iddetalleventa.HeaderText = "Iddetalleventa";
            this.Iddetalleventa.Name = "Iddetalleventa";
            this.Iddetalleventa.ReadOnly = true;
            // 
            // Importe
            // 
            this.Importe.HeaderText = "Importe";
            this.Importe.Name = "Importe";
            this.Importe.ReadOnly = true;
            // 
            // rptPedidos
            // 
            this.rptPedidos.AccessibilityKeyMap = null;
            this.rptPedidos.Location = new System.Drawing.Point(151, 101);
            this.rptPedidos.Name = "rptPedidos";
            this.rptPedidos.Size = new System.Drawing.Size(89, 51);
            this.rptPedidos.TabIndex = 2;
            // 
            // panelNotas
            // 
            this.panelNotas.Controls.Add(this.lblNota);
            this.panelNotas.Controls.Add(this.panel30);
            this.panelNotas.Controls.Add(this.label35);
            this.panelNotas.Location = new System.Drawing.Point(3, 336);
            this.panelNotas.Name = "panelNotas";
            this.panelNotas.Size = new System.Drawing.Size(261, 182);
            this.panelNotas.TabIndex = 643;
            // 
            // lblNota
            // 
            this.lblNota.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNota.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNota.ForeColor = System.Drawing.Color.White;
            this.lblNota.Location = new System.Drawing.Point(0, 32);
            this.lblNota.Name = "lblNota";
            this.lblNota.Size = new System.Drawing.Size(261, 150);
            this.lblNota.TabIndex = 644;
            this.lblNota.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel30
            // 
            this.panel30.BackColor = System.Drawing.Color.DarkGray;
            this.panel30.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel30.Location = new System.Drawing.Point(0, 31);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(261, 1);
            this.panel30.TabIndex = 645;
            // 
            // label35
            // 
            this.label35.Dock = System.Windows.Forms.DockStyle.Top;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.LightSkyBlue;
            this.label35.Location = new System.Drawing.Point(0, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(261, 31);
            this.label35.TabIndex = 643;
            this.label35.Text = "< Notas >";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PanelDetalleVenta
            // 
            this.PanelDetalleVenta.Controls.Add(this.detalleventa);
            this.PanelDetalleVenta.Controls.Add(this.PanelTotales);
            this.PanelDetalleVenta.Controls.Add(this.panel6);
            this.PanelDetalleVenta.Dock = System.Windows.Forms.DockStyle.Left;
            this.PanelDetalleVenta.Location = new System.Drawing.Point(0, 0);
            this.PanelDetalleVenta.Name = "PanelDetalleVenta";
            this.PanelDetalleVenta.Size = new System.Drawing.Size(476, 889);
            this.PanelDetalleVenta.TabIndex = 0;
            // 
            // detalleventa
            // 
            this.detalleventa.AutoScroll = true;
            this.detalleventa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.detalleventa.Location = new System.Drawing.Point(0, 45);
            this.detalleventa.Name = "detalleventa";
            this.detalleventa.Size = new System.Drawing.Size(476, 594);
            this.detalleventa.TabIndex = 2;
            // 
            // PanelTotales
            // 
            this.PanelTotales.Controls.Add(this.panel23);
            this.PanelTotales.Controls.Add(this.panel18);
            this.PanelTotales.Controls.Add(this.panel16);
            this.PanelTotales.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.PanelTotales.Location = new System.Drawing.Point(0, 639);
            this.PanelTotales.Name = "PanelTotales";
            this.PanelTotales.Size = new System.Drawing.Size(476, 250);
            this.PanelTotales.TabIndex = 1;
            // 
            // panel23
            // 
            this.panel23.Controls.Add(this.PanelAcumulado);
            this.panel23.Controls.Add(this.lblCantclientesti);
            this.panel23.Controls.Add(this.lblcantidadPersonas);
            this.panel23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel23.Location = new System.Drawing.Point(293, 89);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(183, 161);
            this.panel23.TabIndex = 5;
            // 
            // PanelAcumulado
            // 
            this.PanelAcumulado.Controls.Add(this.txtacumulado);
            this.PanelAcumulado.Controls.Add(this.panel33);
            this.PanelAcumulado.Controls.Add(this.Label18);
            this.PanelAcumulado.Location = new System.Drawing.Point(23, 82);
            this.PanelAcumulado.Name = "PanelAcumulado";
            this.PanelAcumulado.Size = new System.Drawing.Size(132, 55);
            this.PanelAcumulado.TabIndex = 14;
            // 
            // txtacumulado
            // 
            this.txtacumulado.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtacumulado.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtacumulado.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(231)))), ((int)(((byte)(89)))));
            this.txtacumulado.Location = new System.Drawing.Point(0, 26);
            this.txtacumulado.Name = "txtacumulado";
            this.txtacumulado.Size = new System.Drawing.Size(132, 27);
            this.txtacumulado.TabIndex = 8;
            this.txtacumulado.Text = "0";
            this.txtacumulado.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel33
            // 
            this.panel33.BackColor = System.Drawing.Color.White;
            this.panel33.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel33.Location = new System.Drawing.Point(0, 53);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(132, 2);
            this.panel33.TabIndex = 10;
            // 
            // Label18
            // 
            this.Label18.AutoSize = true;
            this.Label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label18.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.Label18.Location = new System.Drawing.Point(32, 6);
            this.Label18.Name = "Label18";
            this.Label18.Size = new System.Drawing.Size(69, 13);
            this.Label18.TabIndex = 8;
            this.Label18.Text = "Acumulado";
            // 
            // lblCantclientesti
            // 
            this.lblCantclientesti.AutoSize = true;
            this.lblCantclientesti.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCantclientesti.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblCantclientesti.Location = new System.Drawing.Point(32, 15);
            this.lblCantclientesti.Name = "lblCantclientesti";
            this.lblCantclientesti.Size = new System.Drawing.Size(111, 13);
            this.lblCantclientesti.TabIndex = 12;
            this.lblCantclientesti.Text = "Cant. de Personas";
            // 
            // lblcantidadPersonas
            // 
            this.lblcantidadPersonas.AutoSize = true;
            this.lblcantidadPersonas.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcantidadPersonas.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblcantidadPersonas.Location = new System.Drawing.Point(75, 38);
            this.lblcantidadPersonas.Name = "lblcantidadPersonas";
            this.lblcantidadPersonas.Size = new System.Drawing.Size(14, 13);
            this.lblcantidadPersonas.TabIndex = 13;
            this.lblcantidadPersonas.Text = "0";
            this.lblcantidadPersonas.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel18
            // 
            this.panel18.AutoScroll = true;
            this.panel18.Controls.Add(this.Paneltotal2);
            this.panel18.Controls.Add(this.panelTotal1);
            this.panel18.Controls.Add(this.panel22);
            this.panel18.Controls.Add(this.panel21);
            this.panel18.Controls.Add(this.panel20);
            this.panel18.Controls.Add(this.panel19);
            this.panel18.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel18.Location = new System.Drawing.Point(0, 89);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(293, 161);
            this.panel18.TabIndex = 4;
            // 
            // Paneltotal2
            // 
            this.Paneltotal2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Paneltotal2.Controls.Add(this.panel17);
            this.Paneltotal2.Controls.Add(this.panel10);
            this.Paneltotal2.Controls.Add(this.panel27);
            this.Paneltotal2.Controls.Add(this.panel28);
            this.Paneltotal2.Dock = System.Windows.Forms.DockStyle.Left;
            this.Paneltotal2.Location = new System.Drawing.Point(283, 10);
            this.Paneltotal2.Name = "Paneltotal2";
            this.Paneltotal2.Size = new System.Drawing.Size(266, 124);
            this.Paneltotal2.TabIndex = 551;
            this.Paneltotal2.Visible = false;
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.Transparent;
            this.panel17.Controls.Add(this.txtTotal2);
            this.panel17.Controls.Add(this.label29);
            this.panel17.Controls.Add(this.panel26);
            this.panel17.Location = new System.Drawing.Point(21, 108);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(239, 31);
            this.panel17.TabIndex = 543;
            // 
            // txtTotal2
            // 
            this.txtTotal2.BackColor = System.Drawing.Color.Transparent;
            this.txtTotal2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtTotal2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.txtTotal2.ForeColor = System.Drawing.Color.SeaGreen;
            this.txtTotal2.Location = new System.Drawing.Point(127, 1);
            this.txtTotal2.Name = "txtTotal2";
            this.txtTotal2.Size = new System.Drawing.Size(112, 30);
            this.txtTotal2.TabIndex = 507;
            this.txtTotal2.Text = "0";
            this.txtTotal2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label29
            // 
            this.label29.Dock = System.Windows.Forms.DockStyle.Left;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.label29.ForeColor = System.Drawing.Color.SeaGreen;
            this.label29.Location = new System.Drawing.Point(0, 1);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(127, 30);
            this.label29.TabIndex = 507;
            this.label29.Text = "TOTAL:";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel26
            // 
            this.panel26.BackColor = System.Drawing.Color.DimGray;
            this.panel26.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel26.Location = new System.Drawing.Point(0, 0);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(239, 1);
            this.panel26.TabIndex = 542;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Transparent;
            this.panel10.Controls.Add(this.lblSubtotal2);
            this.panel10.Controls.Add(this.label28);
            this.panel10.ForeColor = System.Drawing.Color.DimGray;
            this.panel10.Location = new System.Drawing.Point(16, 9);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(234, 26);
            this.panel10.TabIndex = 542;
            // 
            // lblSubtotal2
            // 
            this.lblSubtotal2.BackColor = System.Drawing.Color.Transparent;
            this.lblSubtotal2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSubtotal2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.lblSubtotal2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblSubtotal2.Location = new System.Drawing.Point(162, 0);
            this.lblSubtotal2.Name = "lblSubtotal2";
            this.lblSubtotal2.Size = new System.Drawing.Size(72, 26);
            this.lblSubtotal2.TabIndex = 507;
            this.lblSubtotal2.Text = "0";
            this.lblSubtotal2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label28
            // 
            this.label28.Dock = System.Windows.Forms.DockStyle.Left;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.label28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label28.Location = new System.Drawing.Point(0, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(162, 26);
            this.label28.TabIndex = 507;
            this.label28.Text = "Sub Total:";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel27
            // 
            this.panel27.BackColor = System.Drawing.Color.Transparent;
            this.panel27.Controls.Add(this.lblImpuestocal2);
            this.panel27.Controls.Add(this.lblImpuesto2);
            this.panel27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel27.Location = new System.Drawing.Point(16, 41);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(234, 26);
            this.panel27.TabIndex = 544;
            // 
            // lblImpuestocal2
            // 
            this.lblImpuestocal2.BackColor = System.Drawing.Color.Transparent;
            this.lblImpuestocal2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblImpuestocal2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.lblImpuestocal2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblImpuestocal2.Location = new System.Drawing.Point(144, 0);
            this.lblImpuestocal2.Name = "lblImpuestocal2";
            this.lblImpuestocal2.Size = new System.Drawing.Size(90, 26);
            this.lblImpuestocal2.TabIndex = 507;
            this.lblImpuestocal2.Text = "0";
            this.lblImpuestocal2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblImpuesto2
            // 
            this.lblImpuesto2.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblImpuesto2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.lblImpuesto2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblImpuesto2.Location = new System.Drawing.Point(0, 0);
            this.lblImpuesto2.Name = "lblImpuesto2";
            this.lblImpuesto2.Size = new System.Drawing.Size(144, 26);
            this.lblImpuesto2.TabIndex = 507;
            this.lblImpuesto2.Text = "IGV (18%):";
            this.lblImpuesto2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel28
            // 
            this.panel28.BackColor = System.Drawing.Color.Transparent;
            this.panel28.Controls.Add(this.label32);
            this.panel28.Controls.Add(this.label34);
            this.panel28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel28.Location = new System.Drawing.Point(16, 72);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(234, 26);
            this.panel28.TabIndex = 545;
            // 
            // label32
            // 
            this.label32.BackColor = System.Drawing.Color.Transparent;
            this.label32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.label32.ForeColor = System.Drawing.Color.Gray;
            this.label32.Location = new System.Drawing.Point(144, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(90, 26);
            this.label32.TabIndex = 507;
            this.label32.Text = "0";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label34
            // 
            this.label34.Dock = System.Windows.Forms.DockStyle.Left;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.label34.ForeColor = System.Drawing.Color.Gray;
            this.label34.Location = new System.Drawing.Point(0, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(144, 26);
            this.label34.TabIndex = 507;
            this.label34.Text = "Delibery:";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panelTotal1
            // 
            this.panelTotal1.BackColor = System.Drawing.Color.Black;
            this.panelTotal1.Controls.Add(this.Panel13);
            this.panelTotal1.Controls.Add(this.Panel12);
            this.panelTotal1.Controls.Add(this.Panel11);
            this.panelTotal1.Controls.Add(this.Panel15);
            this.panelTotal1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelTotal1.Location = new System.Drawing.Point(10, 10);
            this.panelTotal1.Name = "panelTotal1";
            this.panelTotal1.Size = new System.Drawing.Size(273, 124);
            this.panelTotal1.TabIndex = 3;
            // 
            // Panel13
            // 
            this.Panel13.BackColor = System.Drawing.Color.Transparent;
            this.Panel13.Controls.Add(this.Label14);
            this.Panel13.Controls.Add(this.Label15);
            this.Panel13.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel13.Location = new System.Drawing.Point(0, 52);
            this.Panel13.Name = "Panel13";
            this.Panel13.Size = new System.Drawing.Size(273, 26);
            this.Panel13.TabIndex = 549;
            // 
            // Label14
            // 
            this.Label14.BackColor = System.Drawing.Color.Transparent;
            this.Label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.Label14.ForeColor = System.Drawing.Color.White;
            this.Label14.Location = new System.Drawing.Point(114, 0);
            this.Label14.Name = "Label14";
            this.Label14.Size = new System.Drawing.Size(159, 26);
            this.Label14.TabIndex = 507;
            this.Label14.Text = "0";
            this.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label15
            // 
            this.Label15.Dock = System.Windows.Forms.DockStyle.Left;
            this.Label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.Label15.ForeColor = System.Drawing.Color.White;
            this.Label15.Location = new System.Drawing.Point(0, 0);
            this.Label15.Name = "Label15";
            this.Label15.Size = new System.Drawing.Size(114, 26);
            this.Label15.TabIndex = 507;
            this.Label15.Text = "Delivery:";
            this.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Panel12
            // 
            this.Panel12.BackColor = System.Drawing.Color.Transparent;
            this.Panel12.Controls.Add(this.lblImpuestocal1);
            this.Panel12.Controls.Add(this.lblImpuesto1);
            this.Panel12.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel12.Location = new System.Drawing.Point(0, 26);
            this.Panel12.Name = "Panel12";
            this.Panel12.Size = new System.Drawing.Size(273, 26);
            this.Panel12.TabIndex = 548;
            // 
            // lblImpuestocal1
            // 
            this.lblImpuestocal1.BackColor = System.Drawing.Color.Transparent;
            this.lblImpuestocal1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblImpuestocal1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.lblImpuestocal1.ForeColor = System.Drawing.Color.White;
            this.lblImpuestocal1.Location = new System.Drawing.Point(115, 0);
            this.lblImpuestocal1.Name = "lblImpuestocal1";
            this.lblImpuestocal1.Size = new System.Drawing.Size(158, 26);
            this.lblImpuestocal1.TabIndex = 507;
            this.lblImpuestocal1.Text = "0";
            this.lblImpuestocal1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblImpuesto1
            // 
            this.lblImpuesto1.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblImpuesto1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.lblImpuesto1.ForeColor = System.Drawing.Color.White;
            this.lblImpuesto1.Location = new System.Drawing.Point(0, 0);
            this.lblImpuesto1.Name = "lblImpuesto1";
            this.lblImpuesto1.Size = new System.Drawing.Size(115, 26);
            this.lblImpuesto1.TabIndex = 507;
            this.lblImpuesto1.Text = "IGV (18%):";
            this.lblImpuesto1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Panel11
            // 
            this.Panel11.BackColor = System.Drawing.Color.Transparent;
            this.Panel11.Controls.Add(this.lblSubtotal1);
            this.Panel11.Controls.Add(this.Label11);
            this.Panel11.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel11.Location = new System.Drawing.Point(0, 0);
            this.Panel11.Name = "Panel11";
            this.Panel11.Size = new System.Drawing.Size(273, 26);
            this.Panel11.TabIndex = 546;
            // 
            // lblSubtotal1
            // 
            this.lblSubtotal1.BackColor = System.Drawing.Color.Transparent;
            this.lblSubtotal1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSubtotal1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.lblSubtotal1.ForeColor = System.Drawing.Color.White;
            this.lblSubtotal1.Location = new System.Drawing.Point(115, 0);
            this.lblSubtotal1.Name = "lblSubtotal1";
            this.lblSubtotal1.Size = new System.Drawing.Size(158, 26);
            this.lblSubtotal1.TabIndex = 507;
            this.lblSubtotal1.Text = "0";
            this.lblSubtotal1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label11
            // 
            this.Label11.Dock = System.Windows.Forms.DockStyle.Left;
            this.Label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.Label11.ForeColor = System.Drawing.Color.White;
            this.Label11.Location = new System.Drawing.Point(0, 0);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(115, 26);
            this.Label11.TabIndex = 507;
            this.Label11.Text = "Sub Total:";
            this.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Panel15
            // 
            this.Panel15.BackColor = System.Drawing.Color.Transparent;
            this.Panel15.Controls.Add(this.txtTotal1);
            this.Panel15.Controls.Add(this.Label33);
            this.Panel15.Controls.Add(this.Panel14);
            this.Panel15.Location = new System.Drawing.Point(3, 105);
            this.Panel15.Name = "Panel15";
            this.Panel15.Size = new System.Drawing.Size(246, 31);
            this.Panel15.TabIndex = 547;
            // 
            // txtTotal1
            // 
            this.txtTotal1.BackColor = System.Drawing.Color.Transparent;
            this.txtTotal1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtTotal1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.txtTotal1.ForeColor = System.Drawing.Color.Gold;
            this.txtTotal1.Location = new System.Drawing.Point(111, 1);
            this.txtTotal1.Name = "txtTotal1";
            this.txtTotal1.Size = new System.Drawing.Size(135, 30);
            this.txtTotal1.TabIndex = 507;
            this.txtTotal1.Text = "0";
            this.txtTotal1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label33
            // 
            this.Label33.Dock = System.Windows.Forms.DockStyle.Left;
            this.Label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.Label33.ForeColor = System.Drawing.Color.White;
            this.Label33.Location = new System.Drawing.Point(0, 1);
            this.Label33.Name = "Label33";
            this.Label33.Size = new System.Drawing.Size(111, 30);
            this.Label33.TabIndex = 507;
            this.Label33.Text = "TOTAL:";
            this.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Panel14
            // 
            this.Panel14.BackColor = System.Drawing.Color.DimGray;
            this.Panel14.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel14.Location = new System.Drawing.Point(0, 0);
            this.Panel14.Name = "Panel14";
            this.Panel14.Size = new System.Drawing.Size(246, 1);
            this.Panel14.TabIndex = 542;
            // 
            // panel22
            // 
            this.panel22.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel22.Location = new System.Drawing.Point(0, 10);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(10, 124);
            this.panel22.TabIndex = 1;
            // 
            // panel21
            // 
            this.panel21.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel21.Location = new System.Drawing.Point(0, 134);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(549, 10);
            this.panel21.TabIndex = 1;
            // 
            // panel20
            // 
            this.panel20.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel20.Location = new System.Drawing.Point(549, 10);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(10, 134);
            this.panel20.TabIndex = 1;
            // 
            // panel19
            // 
            this.panel19.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel19.Location = new System.Drawing.Point(0, 0);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(559, 10);
            this.panel19.TabIndex = 0;
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.lblcuenta);
            this.panel16.Controls.Add(this.label20);
            this.panel16.Controls.Add(this.btncuentaadelante);
            this.panel16.Controls.Add(this.btncuentaatras);
            this.panel16.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel16.Location = new System.Drawing.Point(0, 0);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(476, 89);
            this.panel16.TabIndex = 2;
            // 
            // lblcuenta
            // 
            this.lblcuenta.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblcuenta.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcuenta.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(231)))), ((int)(((byte)(89)))));
            this.lblcuenta.Location = new System.Drawing.Point(141, 27);
            this.lblcuenta.Name = "lblcuenta";
            this.lblcuenta.Size = new System.Drawing.Size(194, 62);
            this.lblcuenta.TabIndex = 640;
            this.lblcuenta.Text = "20";
            this.lblcuenta.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.Dock = System.Windows.Forms.DockStyle.Top;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(231)))), ((int)(((byte)(89)))));
            this.label20.Location = new System.Drawing.Point(141, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(194, 27);
            this.label20.TabIndex = 639;
            this.label20.Text = "Cuenta";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btncuentaadelante
            // 
            this.btncuentaadelante.BackColor = System.Drawing.Color.Transparent;
            this.btncuentaadelante.BackgroundImage = global::RestCsharp.Properties.Resources.fecha_derecha;
            this.btncuentaadelante.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btncuentaadelante.Dock = System.Windows.Forms.DockStyle.Right;
            this.btncuentaadelante.FlatAppearance.BorderSize = 0;
            this.btncuentaadelante.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btncuentaadelante.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btncuentaadelante.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncuentaadelante.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncuentaadelante.ForeColor = System.Drawing.Color.White;
            this.btncuentaadelante.Location = new System.Drawing.Point(335, 0);
            this.btncuentaadelante.Name = "btncuentaadelante";
            this.btncuentaadelante.Size = new System.Drawing.Size(141, 89);
            this.btncuentaadelante.TabIndex = 637;
            this.btncuentaadelante.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btncuentaadelante.UseVisualStyleBackColor = false;
            this.btncuentaadelante.Click += new System.EventHandler(this.btncuentaadelante_Click);
            // 
            // btncuentaatras
            // 
            this.btncuentaatras.BackColor = System.Drawing.Color.Transparent;
            this.btncuentaatras.BackgroundImage = global::RestCsharp.Properties.Resources.fecha_izquierda;
            this.btncuentaatras.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btncuentaatras.Dock = System.Windows.Forms.DockStyle.Left;
            this.btncuentaatras.FlatAppearance.BorderSize = 0;
            this.btncuentaatras.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btncuentaatras.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btncuentaatras.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncuentaatras.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncuentaatras.ForeColor = System.Drawing.Color.White;
            this.btncuentaatras.Location = new System.Drawing.Point(0, 0);
            this.btncuentaatras.Name = "btncuentaatras";
            this.btncuentaatras.Size = new System.Drawing.Size(141, 89);
            this.btncuentaatras.TabIndex = 636;
            this.btncuentaatras.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btncuentaatras.UseVisualStyleBackColor = false;
            this.btncuentaatras.Click += new System.EventHandler(this.btncuentaatras_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.PictureBox2);
            this.panel6.Controls.Add(this.rptComunicador);
            this.panel6.Controls.Add(this.lblMesa);
            this.panel6.Controls.Add(this.label19);
            this.panel6.Controls.Add(this.PictureBox1);
            this.panel6.Controls.Add(this.lblhora);
            this.panel6.Controls.Add(this.lblfecha);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(476, 45);
            this.panel6.TabIndex = 0;
            // 
            // PictureBox2
            // 
            this.PictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox2.Image")));
            this.PictureBox2.Location = new System.Drawing.Point(156, 12);
            this.PictureBox2.Name = "PictureBox2";
            this.PictureBox2.Size = new System.Drawing.Size(28, 24);
            this.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PictureBox2.TabIndex = 5;
            this.PictureBox2.TabStop = false;
            // 
            // rptComunicador
            // 
            this.rptComunicador.AccessibilityKeyMap = null;
            this.rptComunicador.Location = new System.Drawing.Point(173, 14);
            this.rptComunicador.Name = "rptComunicador";
            this.rptComunicador.Size = new System.Drawing.Size(11, 13);
            this.rptComunicador.TabIndex = 11;
            // 
            // lblMesa
            // 
            this.lblMesa.Dock = System.Windows.Forms.DockStyle.Right;
            this.lblMesa.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMesa.ForeColor = System.Drawing.Color.Silver;
            this.lblMesa.Location = new System.Drawing.Point(396, 0);
            this.lblMesa.Name = "lblMesa";
            this.lblMesa.Size = new System.Drawing.Size(80, 45);
            this.lblMesa.TabIndex = 9;
            this.lblMesa.Text = "0";
            this.lblMesa.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Silver;
            this.label19.Location = new System.Drawing.Point(323, 9);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(76, 26);
            this.label19.TabIndex = 10;
            this.label19.Text = "Mesa:";
            // 
            // PictureBox1
            // 
            this.PictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox1.Image")));
            this.PictureBox1.Location = new System.Drawing.Point(3, 12);
            this.PictureBox1.Name = "PictureBox1";
            this.PictureBox1.Size = new System.Drawing.Size(28, 24);
            this.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PictureBox1.TabIndex = 6;
            this.PictureBox1.TabStop = false;
            // 
            // lblhora
            // 
            this.lblhora.AutoSize = true;
            this.lblhora.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblhora.ForeColor = System.Drawing.Color.Silver;
            this.lblhora.Location = new System.Drawing.Point(190, 11);
            this.lblhora.Name = "lblhora";
            this.lblhora.Size = new System.Drawing.Size(59, 26);
            this.lblhora.TabIndex = 3;
            this.lblhora.Text = "hora";
            // 
            // lblfecha
            // 
            this.lblfecha.AutoSize = true;
            this.lblfecha.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfecha.ForeColor = System.Drawing.Color.LightGray;
            this.lblfecha.Location = new System.Drawing.Point(37, 14);
            this.lblfecha.Name = "lblfecha";
            this.lblfecha.Size = new System.Drawing.Size(54, 22);
            this.lblfecha.TabIndex = 4;
            this.lblfecha.Text = "fecha";
            // 
            // timerFechaHora
            // 
            this.timerFechaHora.Enabled = true;
            this.timerFechaHora.Tick += new System.EventHandler(this.timerFechaHora_Tick);
            // 
            // timerImprimir
            // 
            this.timerImprimir.Enabled = true;
            this.timerImprimir.Tick += new System.EventHandler(this.timerImprimir_Tick);
            // 
            // timerEsc
            // 
            this.timerEsc.Enabled = true;
            this.timerEsc.Tick += new System.EventHandler(this.timerEsc_Tick);
            // 
            // dataGridViewImageColumn1
            // 
            this.dataGridViewImageColumn1.HeaderText = "";
            this.dataGridViewImageColumn1.Image = ((System.Drawing.Image)(resources.GetObject("dataGridViewImageColumn1.Image")));
            this.dataGridViewImageColumn1.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Zoom;
            this.dataGridViewImageColumn1.Name = "dataGridViewImageColumn1";
            // 
            // Punto_de_venta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.Controls.Add(this.PanelVentasGeneral);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Name = "Punto_de_venta";
            this.Size = new System.Drawing.Size(1843, 985);
            this.Load += new System.EventHandler(this.Punto_de_venta_Load);
            this.panel2.ResumeLayout(false);
            this.flowLayoutPanel2.ResumeLayout(false);
            this.Panelpagorapido.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel35.ResumeLayout(false);
            this.panel35.PerformLayout();
            this.PanelVentasGeneral.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.Panel9.ResumeLayout(false);
            this.Panel_grupos.ResumeLayout(false);
            this.panelCobro.ResumeLayout(false);
            this.panelCobro.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgClientes)).EndInit();
            this.panelClienteFactura.ResumeLayout(false);
            this.panelClienteFactura.PerformLayout();
            this.panelReport.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.PanelProductos.ResumeLayout(false);
            this.panel32.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.FlowLayoutPanel4.ResumeLayout(false);
            this.panel29.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.datalistadoPedidos)).EndInit();
            this.panelNotas.ResumeLayout(false);
            this.PanelDetalleVenta.ResumeLayout(false);
            this.PanelTotales.ResumeLayout(false);
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.PanelAcumulado.ResumeLayout(false);
            this.PanelAcumulado.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.Paneltotal2.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.panel28.ResumeLayout(false);
            this.panelTotal1.ResumeLayout(false);
            this.Panel13.ResumeLayout(false);
            this.Panel12.ResumeLayout(false);
            this.Panel11.ResumeLayout(false);
            this.Panel15.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button Bn5;
        private System.Windows.Forms.FlowLayoutPanel Panelpagorapido;
        private System.Windows.Forms.Button Bn1;
        private System.Windows.Forms.Button Bn10;
        private System.Windows.Forms.Button Bn20;
        private System.Windows.Forms.Button Bn50;
        private System.Windows.Forms.Button Bn100;
        private System.Windows.Forms.Button BnExacto;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.Button btnsalir;
        private System.Windows.Forms.Button btncobrar;
        internal System.Windows.Forms.Panel PanelVentasGeneral;
        internal System.Windows.Forms.Panel panel1;
        internal System.Windows.Forms.Panel Panel9;
        internal System.Windows.Forms.Panel panel4;
        internal System.Windows.Forms.Panel PanelProductos;
        internal System.Windows.Forms.Panel panel5;
        internal System.Windows.Forms.FlowLayoutPanel FlowLayoutPanel4;
        internal System.Windows.Forms.Button btnvermesas;
        internal System.Windows.Forms.Button btnDividirCuenta;
        internal System.Windows.Forms.Button btnPrecuenta;
        internal System.Windows.Forms.Button btneliminarVenta;
        internal System.Windows.Forms.Button btnEnviarpedido;
        internal System.Windows.Forms.Panel PanelDetalleVenta;
        internal System.Windows.Forms.Panel PanelTotales;
        internal System.Windows.Forms.Panel panel6;
        internal System.Windows.Forms.PictureBox PictureBox2;
        internal System.Windows.Forms.PictureBox PictureBox1;
        internal System.Windows.Forms.Label lblhora;
        internal System.Windows.Forms.Label lblfecha;
        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel5;
        private System.Windows.Forms.Timer timerFechaHora;
        internal System.Windows.Forms.Label label19;
        internal System.Windows.Forms.Label lblMesa;
        private System.Windows.Forms.Panel panelTotal1;
        internal System.Windows.Forms.Panel Panel11;
        internal System.Windows.Forms.Label lblSubtotal1;
        internal System.Windows.Forms.Label Label11;
        internal System.Windows.Forms.Panel Panel15;
        internal System.Windows.Forms.Label txtTotal1;
        internal System.Windows.Forms.Label Label33;
        internal System.Windows.Forms.Panel Panel14;
        internal System.Windows.Forms.Panel Panel12;
        internal System.Windows.Forms.Label lblImpuestocal1;
        internal System.Windows.Forms.Label lblImpuesto1;
        internal System.Windows.Forms.Panel Panel13;
        internal System.Windows.Forms.Label Label14;
        internal System.Windows.Forms.Label Label15;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel23;
        internal System.Windows.Forms.Panel PanelAcumulado;
        internal System.Windows.Forms.Label Label18;
        internal System.Windows.Forms.Label lblCantclientesti;
        internal System.Windows.Forms.Label lblcantidadPersonas;
        internal System.Windows.Forms.Button btncuentaadelante;
        internal System.Windows.Forms.Button btncuentaatras;
        internal System.Windows.Forms.Label lblcuenta;
        internal System.Windows.Forms.Label label20;
        private System.Windows.Forms.FlowLayoutPanel detalleventa;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.DataGridView datalistadoPedidos;
        private System.Windows.Forms.DataGridViewTextBoxColumn Iddetalleventa;
        private System.Windows.Forms.DataGridViewTextBoxColumn Importe;
        internal System.Windows.Forms.Panel Paneltotal2;
        internal System.Windows.Forms.Panel panel10;
        internal System.Windows.Forms.Label lblSubtotal2;
        internal System.Windows.Forms.Label label28;
        internal System.Windows.Forms.Panel panel17;
        internal System.Windows.Forms.Label txtTotal2;
        internal System.Windows.Forms.Label label29;
        internal System.Windows.Forms.Panel panel26;
        internal System.Windows.Forms.Panel panel27;
        internal System.Windows.Forms.Label lblImpuestocal2;
        internal System.Windows.Forms.Label lblImpuesto2;
        internal System.Windows.Forms.Panel panel28;
        internal System.Windows.Forms.Label label32;
        internal System.Windows.Forms.Label label34;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panelNotas;
        public System.Windows.Forms.Label lblNota;
        private System.Windows.Forms.Panel panel30;
        internal System.Windows.Forms.Label label35;
        internal System.Windows.Forms.Button btnNotas;
        private Telerik.ReportViewer.WinForms.ReportViewer rptPedidos;
        private System.Windows.Forms.Panel panelCobro;
        private System.Windows.Forms.Panel panelReport;
        internal System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.PictureBox pictureBox3;
        private Telerik.ReportViewer.WinForms.ReportViewer reportViewer1;
        private UIDC.UI_TecladoNumerico btnTecladoEfectivo;
        internal System.Windows.Forms.Button btnguardar;
        internal System.Windows.Forms.Label lbltotal;
        internal System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel8;
        internal System.Windows.Forms.Label txtrestante;
        internal System.Windows.Forms.Label label12;
        internal System.Windows.Forms.Panel panel24;
        internal System.Windows.Forms.TextBox txtvuelto;
        internal System.Windows.Forms.Label Label31;
        internal System.Windows.Forms.TextBox txttarjeta;
        internal System.Windows.Forms.Panel panel25;
        internal System.Windows.Forms.Label label13;
        internal System.Windows.Forms.TextBox txtefectivo;
        internal System.Windows.Forms.Panel panel31;
        internal System.Windows.Forms.Label label21;
        internal System.Windows.Forms.Button btncerrar;
        private System.Windows.Forms.Label lblUltimoVuelto;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblUltimoTotal;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblUltimoImpuesto;
        private System.Windows.Forms.Label lbltipoimpuesto;
        private System.Windows.Forms.Label lblUltimoSubtotal;
        private System.Windows.Forms.Label label1;
        internal System.Windows.Forms.Button btnGrupoadelante;
        internal System.Windows.Forms.Button btngrupoAtras;
        internal System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel panel32;
        internal System.Windows.Forms.Button btnadelante;
        internal System.Windows.Forms.Button btnatras;
        internal System.Windows.Forms.Label Label16;
        private System.Windows.Forms.Panel panel33;
        private UIDC.UI_TecladoNumerico btnTecladoTarjeta;
        private System.Windows.Forms.Label lblUltimoPagoCon;
        private System.Windows.Forms.Label label2;
        internal System.Windows.Forms.Panel panel34;
        internal System.Windows.Forms.Label label3;
        internal System.Windows.Forms.TextBox txtreferencia;
        internal System.Windows.Forms.Button btnBuscar;
        private UIDC.UI_TecladoNumerico btnTecladodigitos;
        public System.Windows.Forms.FlowLayoutPanel Panel_grupos;
        public System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Label label4;
        private UIDC.UI_MaterialToggle IndicadorTema;
        internal System.Windows.Forms.Label txtacumulado;
        private System.Windows.Forms.Timer timerImprimir;
        private Telerik.ReportViewer.WinForms.ReportViewer rptComunicador;
        private System.Windows.Forms.Timer timerEsc;
        internal System.Windows.Forms.FlowLayoutPanel Panelcomprobante;
        internal System.Windows.Forms.Label lblComprobante;
        internal System.Windows.Forms.Panel panelClienteFactura;
        private System.Windows.Forms.Button btnAgregarcliente;
        internal System.Windows.Forms.Label lblCliente;
        internal System.Windows.Forms.TextBox txtbuscarcliente;
        public System.Windows.Forms.DataGridView dgClientes;
    }
}