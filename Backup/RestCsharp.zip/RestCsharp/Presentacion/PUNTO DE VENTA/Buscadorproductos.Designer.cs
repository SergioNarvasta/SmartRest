﻿
namespace RestCsharp.Presentacion.PUNTO_DE_VENTA
{
    partial class Buscadorproductos
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Buscadorproductos));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnBorrarCaract = new System.Windows.Forms.Button();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.btnasteri = new System.Windows.Forms.Button();
            this.btnbarra = new System.Windows.Forms.Button();
            this.btncoma = new System.Windows.Forms.Button();
            this.btnespacio = new System.Windows.Forms.Button();
            this.PanelNumeros = new System.Windows.Forms.FlowLayoutPanel();
            this.PanelLetras = new System.Windows.Forms.FlowLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCerrar = new System.Windows.Forms.Button();
            this.txtnota = new System.Windows.Forms.RichTextBox();
            this.panelresultado = new System.Windows.Forms.FlowLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.btnBorrarCaract);
            this.panel1.Controls.Add(this.btnGuardar);
            this.panel1.Controls.Add(this.btnasteri);
            this.panel1.Controls.Add(this.btnbarra);
            this.panel1.Controls.Add(this.btncoma);
            this.panel1.Controls.Add(this.btnespacio);
            this.panel1.Controls.Add(this.PanelNumeros);
            this.panel1.Controls.Add(this.PanelLetras);
            this.panel1.Location = new System.Drawing.Point(48, 155);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(749, 344);
            this.panel1.TabIndex = 15;
            // 
            // btnBorrarCaract
            // 
            this.btnBorrarCaract.BackColor = System.Drawing.Color.Transparent;
            this.btnBorrarCaract.BackgroundImage = global::RestCsharp.Properties.Resources.naranja;
            this.btnBorrarCaract.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBorrarCaract.FlatAppearance.BorderSize = 0;
            this.btnBorrarCaract.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnBorrarCaract.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnBorrarCaract.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBorrarCaract.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBorrarCaract.ForeColor = System.Drawing.Color.White;
            this.btnBorrarCaract.Location = new System.Drawing.Point(649, 13);
            this.btnBorrarCaract.Name = "btnBorrarCaract";
            this.btnBorrarCaract.Size = new System.Drawing.Size(51, 48);
            this.btnBorrarCaract.TabIndex = 11;
            this.btnBorrarCaract.Text = "<";
            this.btnBorrarCaract.UseVisualStyleBackColor = false;
            // 
            // btnGuardar
            // 
            this.btnGuardar.BackColor = System.Drawing.Color.Transparent;
            this.btnGuardar.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.btnGuardar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnGuardar.FlatAppearance.BorderSize = 0;
            this.btnGuardar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnGuardar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnGuardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGuardar.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardar.ForeColor = System.Drawing.Color.White;
            this.btnGuardar.Location = new System.Drawing.Point(515, 273);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(134, 58);
            this.btnGuardar.TabIndex = 8;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = false;
            // 
            // btnasteri
            // 
            this.btnasteri.BackColor = System.Drawing.Color.Transparent;
            this.btnasteri.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnasteri.BackgroundImage")));
            this.btnasteri.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnasteri.FlatAppearance.BorderSize = 0;
            this.btnasteri.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnasteri.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnasteri.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnasteri.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnasteri.ForeColor = System.Drawing.Color.White;
            this.btnasteri.Location = new System.Drawing.Point(145, 273);
            this.btnasteri.Name = "btnasteri";
            this.btnasteri.Size = new System.Drawing.Size(51, 49);
            this.btnasteri.TabIndex = 7;
            this.btnasteri.Text = "*";
            this.btnasteri.UseVisualStyleBackColor = false;
            // 
            // btnbarra
            // 
            this.btnbarra.BackColor = System.Drawing.Color.Transparent;
            this.btnbarra.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnbarra.BackgroundImage")));
            this.btnbarra.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnbarra.FlatAppearance.BorderSize = 0;
            this.btnbarra.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnbarra.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnbarra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnbarra.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbarra.ForeColor = System.Drawing.Color.White;
            this.btnbarra.Location = new System.Drawing.Point(88, 273);
            this.btnbarra.Name = "btnbarra";
            this.btnbarra.Size = new System.Drawing.Size(51, 49);
            this.btnbarra.TabIndex = 6;
            this.btnbarra.Text = "/";
            this.btnbarra.UseVisualStyleBackColor = false;
            // 
            // btncoma
            // 
            this.btncoma.BackColor = System.Drawing.Color.Transparent;
            this.btncoma.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btncoma.BackgroundImage")));
            this.btncoma.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btncoma.FlatAppearance.BorderSize = 0;
            this.btncoma.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btncoma.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btncoma.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncoma.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncoma.ForeColor = System.Drawing.Color.White;
            this.btncoma.Location = new System.Drawing.Point(31, 273);
            this.btncoma.Name = "btncoma";
            this.btncoma.Size = new System.Drawing.Size(51, 49);
            this.btncoma.TabIndex = 5;
            this.btncoma.Text = ",";
            this.btncoma.UseVisualStyleBackColor = false;
            // 
            // btnespacio
            // 
            this.btnespacio.BackColor = System.Drawing.Color.Transparent;
            this.btnespacio.BackgroundImage = global::RestCsharp.Properties.Resources.azul;
            this.btnespacio.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnespacio.FlatAppearance.BorderSize = 0;
            this.btnespacio.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnespacio.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnespacio.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnespacio.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnespacio.ForeColor = System.Drawing.Color.White;
            this.btnespacio.Location = new System.Drawing.Point(234, 273);
            this.btnespacio.Name = "btnespacio";
            this.btnespacio.Size = new System.Drawing.Size(216, 58);
            this.btnespacio.TabIndex = 4;
            this.btnespacio.Text = "Espacio";
            this.btnespacio.UseVisualStyleBackColor = false;
            this.btnespacio.Click += new System.EventHandler(this.btnespacio_Click);
            // 
            // PanelNumeros
            // 
            this.PanelNumeros.Location = new System.Drawing.Point(29, 3);
            this.PanelNumeros.Name = "PanelNumeros";
            this.PanelNumeros.Size = new System.Drawing.Size(614, 68);
            this.PanelNumeros.TabIndex = 2;
            // 
            // PanelLetras
            // 
            this.PanelLetras.Location = new System.Drawing.Point(29, 77);
            this.PanelLetras.Name = "PanelLetras";
            this.PanelLetras.Size = new System.Drawing.Size(618, 190);
            this.PanelLetras.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(43, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(197, 26);
            this.label1.TabIndex = 18;
            this.label1.Text = "Buscar productos";
            // 
            // btnCerrar
            // 
            this.btnCerrar.BackColor = System.Drawing.Color.Transparent;
            this.btnCerrar.BackgroundImage = global::RestCsharp.Properties.Resources.Rojo;
            this.btnCerrar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCerrar.FlatAppearance.BorderSize = 0;
            this.btnCerrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnCerrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnCerrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCerrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCerrar.ForeColor = System.Drawing.Color.White;
            this.btnCerrar.Location = new System.Drawing.Point(717, 17);
            this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(69, 63);
            this.btnCerrar.TabIndex = 17;
            this.btnCerrar.Text = "X";
            this.btnCerrar.UseVisualStyleBackColor = false;
            // 
            // txtnota
            // 
            this.txtnota.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.txtnota.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtnota.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnota.ForeColor = System.Drawing.Color.White;
            this.txtnota.Location = new System.Drawing.Point(48, 47);
            this.txtnota.Name = "txtnota";
            this.txtnota.Size = new System.Drawing.Size(553, 94);
            this.txtnota.TabIndex = 16;
            this.txtnota.Text = "";
            // 
            // panelresultado
            // 
            this.panelresultado.Location = new System.Drawing.Point(48, 542);
            this.panelresultado.Name = "panelresultado";
            this.panelresultado.Size = new System.Drawing.Size(749, 190);
            this.panelresultado.TabIndex = 19;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DimGray;
            this.label2.Location = new System.Drawing.Point(47, 513);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(262, 26);
            this.label2.TabIndex = 18;
            this.label2.Text = "Resultado de busqueda";
            // 
            // Buscadorproductos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(34)))), ((int)(((byte)(34)))));
            this.Controls.Add(this.panelresultado);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCerrar);
            this.Controls.Add(this.txtnota);
            this.Controls.Add(this.panel1);
            this.Name = "Buscadorproductos";
            this.Size = new System.Drawing.Size(845, 802);
            this.Load += new System.EventHandler(this.Buscadorproductos_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnBorrarCaract;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button btnasteri;
        private System.Windows.Forms.Button btnbarra;
        private System.Windows.Forms.Button btncoma;
        private System.Windows.Forms.Button btnespacio;
        private System.Windows.Forms.FlowLayoutPanel PanelNumeros;
        private System.Windows.Forms.FlowLayoutPanel PanelLetras;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCerrar;
        private System.Windows.Forms.RichTextBox txtnota;
        private System.Windows.Forms.FlowLayoutPanel panelresultado;
        private System.Windows.Forms.Label label2;
    }
}
