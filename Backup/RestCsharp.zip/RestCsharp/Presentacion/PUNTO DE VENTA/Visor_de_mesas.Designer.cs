﻿namespace RestCsharp.Presentacion.PUNTO_DE_VENTA
{
    partial class Visor_de_mesas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Visor_de_mesas));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panelSunat = new System.Windows.Forms.Panel();
            this.PanelUNIONMesas = new System.Windows.Forms.Panel();
            this.labelPasos = new System.Windows.Forms.Label();
            this.btnvolver = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.PanelHerramientas = new System.Windows.Forms.FlowLayoutPanel();
            this.btnadministrar = new System.Windows.Forms.Button();
            this.btncocina = new System.Windows.Forms.Button();
            this.btncerrartodo = new System.Windows.Forms.Button();
            this.btncerrarcaja = new System.Windows.Forms.Button();
            this.btnIngresoSalida = new System.Windows.Forms.Button();
            this.btncodigosQR = new System.Windows.Forms.Button();
            this.PanelMesas = new System.Windows.Forms.FlowLayoutPanel();
            this.PanelBienvenida = new System.Windows.Forms.Panel();
            this.Label3 = new System.Windows.Forms.Label();
            this.PanelSalones = new System.Windows.Forms.Panel();
            this.FlowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.Panelbotones = new System.Windows.Forms.Panel();
            this.btnSunat = new System.Windows.Forms.Button();
            this.btnHerramientas = new System.Windows.Forms.Button();
            this.btnsalir = new System.Windows.Forms.Button();
            this.btnCambiomesa = new System.Windows.Forms.Button();
            this.btnVerCuentas = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.DATALISTADO_PRODUCTOS_OKA_libre = new System.Windows.Forms.DataGridView();
            this.DataGridViewCheckBoxColumn2 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.DATALISTADO_PRODUCTOS_OKA = new System.Windows.Forms.DataGridView();
            this.DataGridViewCheckBoxColumn9 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.ComboBox1 = new System.Windows.Forms.ComboBox();
            this.Button2 = new System.Windows.Forms.Button();
            this.TextBox2 = new System.Windows.Forms.TextBox();
            this.DataGridView1 = new System.Windows.Forms.DataGridView();
            this.DataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.TextBox1 = new System.Windows.Forms.TextBox();
            this.btnParallevar = new System.Windows.Forms.Button();
            this.rptComunicador = new Telerik.ReportViewer.WinForms.ReportViewer();
            this.timerImprimir = new System.Windows.Forms.Timer(this.components);
            this.timerEsc = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.PanelUNIONMesas.SuspendLayout();
            this.PanelHerramientas.SuspendLayout();
            this.PanelBienvenida.SuspendLayout();
            this.PanelSalones.SuspendLayout();
            this.Panelbotones.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DATALISTADO_PRODUCTOS_OKA_libre)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DATALISTADO_PRODUCTOS_OKA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panelSunat);
            this.panel1.Controls.Add(this.PanelUNIONMesas);
            this.panel1.Controls.Add(this.PanelHerramientas);
            this.panel1.Controls.Add(this.PanelMesas);
            this.panel1.Controls.Add(this.PanelBienvenida);
            this.panel1.Controls.Add(this.PanelSalones);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1366, 749);
            this.panel1.TabIndex = 0;
            // 
            // panelSunat
            // 
            this.panelSunat.Location = new System.Drawing.Point(301, 620);
            this.panelSunat.Name = "panelSunat";
            this.panelSunat.Size = new System.Drawing.Size(189, 76);
            this.panelSunat.TabIndex = 502;
            this.panelSunat.Visible = false;
            // 
            // PanelUNIONMesas
            // 
            this.PanelUNIONMesas.BackColor = System.Drawing.Color.Black;
            this.PanelUNIONMesas.Controls.Add(this.labelPasos);
            this.PanelUNIONMesas.Controls.Add(this.btnvolver);
            this.PanelUNIONMesas.Controls.Add(this.panel3);
            this.PanelUNIONMesas.Location = new System.Drawing.Point(301, 30);
            this.PanelUNIONMesas.Name = "PanelUNIONMesas";
            this.PanelUNIONMesas.Size = new System.Drawing.Size(413, 444);
            this.PanelUNIONMesas.TabIndex = 501;
            this.PanelUNIONMesas.Visible = false;
            // 
            // labelPasos
            // 
            this.labelPasos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelPasos.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPasos.ForeColor = System.Drawing.Color.White;
            this.labelPasos.Location = new System.Drawing.Point(0, 0);
            this.labelPasos.Name = "labelPasos";
            this.labelPasos.Size = new System.Drawing.Size(413, 299);
            this.labelPasos.TabIndex = 0;
            this.labelPasos.Text = "PASO 1 \r\n\r\nSeleccione una mesa de Origen";
            this.labelPasos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnvolver
            // 
            this.btnvolver.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btnvolver.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnvolver.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnvolver.FlatAppearance.BorderSize = 0;
            this.btnvolver.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnvolver.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnvolver.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnvolver.Image = ((System.Drawing.Image)(resources.GetObject("btnvolver.Image")));
            this.btnvolver.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnvolver.Location = new System.Drawing.Point(0, 299);
            this.btnvolver.Name = "btnvolver";
            this.btnvolver.Size = new System.Drawing.Size(413, 75);
            this.btnvolver.TabIndex = 8;
            this.btnvolver.Text = "Cancelar la UNION";
            this.btnvolver.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnvolver.UseVisualStyleBackColor = false;
            this.btnvolver.Click += new System.EventHandler(this.btnvolver_Click);
            // 
            // panel3
            // 
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 374);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(413, 70);
            this.panel3.TabIndex = 9;
            // 
            // PanelHerramientas
            // 
            this.PanelHerramientas.BackColor = System.Drawing.Color.Black;
            this.PanelHerramientas.Controls.Add(this.btnadministrar);
            this.PanelHerramientas.Controls.Add(this.btncocina);
            this.PanelHerramientas.Controls.Add(this.btncerrartodo);
            this.PanelHerramientas.Controls.Add(this.btncerrarcaja);
            this.PanelHerramientas.Controls.Add(this.btnIngresoSalida);
            this.PanelHerramientas.Controls.Add(this.btncodigosQR);
            this.PanelHerramientas.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.PanelHerramientas.Location = new System.Drawing.Point(288, 507);
            this.PanelHerramientas.Name = "PanelHerramientas";
            this.PanelHerramientas.Size = new System.Drawing.Size(992, 92);
            this.PanelHerramientas.TabIndex = 499;
            this.PanelHerramientas.Visible = false;
            // 
            // btnadministrar
            // 
            this.btnadministrar.BackColor = System.Drawing.Color.Transparent;
            this.btnadministrar.BackgroundImage = global::RestCsharp.Properties.Resources.azul;
            this.btnadministrar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnadministrar.FlatAppearance.BorderSize = 0;
            this.btnadministrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnadministrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnadministrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnadministrar.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadministrar.ForeColor = System.Drawing.Color.White;
            this.btnadministrar.Location = new System.Drawing.Point(3, 3);
            this.btnadministrar.Name = "btnadministrar";
            this.btnadministrar.Size = new System.Drawing.Size(125, 84);
            this.btnadministrar.TabIndex = 505;
            this.btnadministrar.Text = "Administrar";
            this.btnadministrar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnadministrar.UseVisualStyleBackColor = false;
            this.btnadministrar.Visible = false;
            this.btnadministrar.Click += new System.EventHandler(this.btnadministrar_Click);
            // 
            // btncocina
            // 
            this.btncocina.BackColor = System.Drawing.Color.Transparent;
            this.btncocina.BackgroundImage = global::RestCsharp.Properties.Resources.azul;
            this.btncocina.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btncocina.FlatAppearance.BorderSize = 0;
            this.btncocina.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btncocina.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btncocina.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncocina.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncocina.ForeColor = System.Drawing.Color.White;
            this.btncocina.Location = new System.Drawing.Point(134, 3);
            this.btncocina.Name = "btncocina";
            this.btncocina.Size = new System.Drawing.Size(125, 84);
            this.btncocina.TabIndex = 506;
            this.btncocina.Text = "Cocina";
            this.btncocina.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btncocina.UseVisualStyleBackColor = false;
            this.btncocina.Visible = false;
            this.btncocina.Click += new System.EventHandler(this.btncocina_Click);
            // 
            // btncerrartodo
            // 
            this.btncerrartodo.BackColor = System.Drawing.Color.Transparent;
            this.btncerrartodo.BackgroundImage = global::RestCsharp.Properties.Resources.Rojo;
            this.btncerrartodo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btncerrartodo.FlatAppearance.BorderSize = 0;
            this.btncerrartodo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btncerrartodo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btncerrartodo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncerrartodo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncerrartodo.ForeColor = System.Drawing.Color.White;
            this.btncerrartodo.Location = new System.Drawing.Point(265, 3);
            this.btncerrartodo.Name = "btncerrartodo";
            this.btncerrartodo.Size = new System.Drawing.Size(125, 84);
            this.btncerrartodo.TabIndex = 507;
            this.btncerrartodo.Text = "Cerrar Todo";
            this.btncerrartodo.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btncerrartodo.UseVisualStyleBackColor = false;
            this.btncerrartodo.Click += new System.EventHandler(this.btncerrartodo_Click);
            // 
            // btncerrarcaja
            // 
            this.btncerrarcaja.BackColor = System.Drawing.Color.Transparent;
            this.btncerrarcaja.BackgroundImage = global::RestCsharp.Properties.Resources.azul;
            this.btncerrarcaja.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btncerrarcaja.FlatAppearance.BorderSize = 0;
            this.btncerrarcaja.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btncerrarcaja.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btncerrarcaja.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncerrarcaja.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncerrarcaja.ForeColor = System.Drawing.Color.White;
            this.btncerrarcaja.Location = new System.Drawing.Point(396, 3);
            this.btncerrarcaja.Name = "btncerrarcaja";
            this.btncerrarcaja.Size = new System.Drawing.Size(125, 84);
            this.btncerrarcaja.TabIndex = 508;
            this.btncerrarcaja.Text = "Cerrar caja";
            this.btncerrarcaja.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btncerrarcaja.UseVisualStyleBackColor = false;
            this.btncerrarcaja.Visible = false;
            this.btncerrarcaja.Click += new System.EventHandler(this.btncerrarcaja_Click);
            // 
            // btnIngresoSalida
            // 
            this.btnIngresoSalida.BackColor = System.Drawing.Color.Transparent;
            this.btnIngresoSalida.BackgroundImage = global::RestCsharp.Properties.Resources.azul;
            this.btnIngresoSalida.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnIngresoSalida.FlatAppearance.BorderSize = 0;
            this.btnIngresoSalida.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnIngresoSalida.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnIngresoSalida.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnIngresoSalida.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIngresoSalida.ForeColor = System.Drawing.Color.White;
            this.btnIngresoSalida.Location = new System.Drawing.Point(527, 3);
            this.btnIngresoSalida.Name = "btnIngresoSalida";
            this.btnIngresoSalida.Size = new System.Drawing.Size(125, 84);
            this.btnIngresoSalida.TabIndex = 512;
            this.btnIngresoSalida.Text = "Ingreso / Salida de dinero";
            this.btnIngresoSalida.UseVisualStyleBackColor = false;
            this.btnIngresoSalida.Visible = false;
            this.btnIngresoSalida.Click += new System.EventHandler(this.btnIngresoSalida_Click);
            // 
            // btncodigosQR
            // 
            this.btncodigosQR.BackColor = System.Drawing.Color.Transparent;
            this.btncodigosQR.BackgroundImage = global::RestCsharp.Properties.Resources.naranja;
            this.btncodigosQR.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btncodigosQR.FlatAppearance.BorderSize = 0;
            this.btncodigosQR.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btncodigosQR.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btncodigosQR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncodigosQR.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncodigosQR.ForeColor = System.Drawing.Color.White;
            this.btncodigosQR.Location = new System.Drawing.Point(658, 3);
            this.btncodigosQR.Name = "btncodigosQR";
            this.btncodigosQR.Size = new System.Drawing.Size(125, 84);
            this.btncodigosQR.TabIndex = 513;
            this.btncodigosQR.Text = "Generar codigos QR";
            this.btncodigosQR.UseVisualStyleBackColor = false;
            this.btncodigosQR.Visible = false;
            this.btncodigosQR.Click += new System.EventHandler(this.btncodigosQR_Click);
            // 
            // PanelMesas
            // 
            this.PanelMesas.BackColor = System.Drawing.Color.Black;
            this.PanelMesas.Location = new System.Drawing.Point(679, 301);
            this.PanelMesas.Name = "PanelMesas";
            this.PanelMesas.Size = new System.Drawing.Size(396, 134);
            this.PanelMesas.TabIndex = 5;
            this.PanelMesas.Visible = false;
            // 
            // PanelBienvenida
            // 
            this.PanelBienvenida.BackColor = System.Drawing.Color.Black;
            this.PanelBienvenida.Controls.Add(this.Label3);
            this.PanelBienvenida.Location = new System.Drawing.Point(679, 150);
            this.PanelBienvenida.Name = "PanelBienvenida";
            this.PanelBienvenida.Size = new System.Drawing.Size(396, 145);
            this.PanelBienvenida.TabIndex = 6;
            // 
            // Label3
            // 
            this.Label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.ForeColor = System.Drawing.Color.DimGray;
            this.Label3.Location = new System.Drawing.Point(0, 0);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(396, 145);
            this.Label3.TabIndex = 0;
            this.Label3.Text = "Agrege mesas \r\na este salon";
            this.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PanelSalones
            // 
            this.PanelSalones.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.PanelSalones.Controls.Add(this.FlowLayoutPanel1);
            this.PanelSalones.Controls.Add(this.label1);
            this.PanelSalones.Controls.Add(this.Panelbotones);
            this.PanelSalones.Dock = System.Windows.Forms.DockStyle.Left;
            this.PanelSalones.Location = new System.Drawing.Point(0, 0);
            this.PanelSalones.Name = "PanelSalones";
            this.PanelSalones.Size = new System.Drawing.Size(279, 749);
            this.PanelSalones.TabIndex = 4;
            // 
            // FlowLayoutPanel1
            // 
            this.FlowLayoutPanel1.AutoScroll = true;
            this.FlowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FlowLayoutPanel1.Location = new System.Drawing.Point(0, 51);
            this.FlowLayoutPanel1.Name = "FlowLayoutPanel1";
            this.FlowLayoutPanel1.Size = new System.Drawing.Size(279, 367);
            this.FlowLayoutPanel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DimGray;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(279, 51);
            this.label1.TabIndex = 4;
            this.label1.Text = "Salones";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Panelbotones
            // 
            this.Panelbotones.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.Panelbotones.Controls.Add(this.btnSunat);
            this.Panelbotones.Controls.Add(this.btnHerramientas);
            this.Panelbotones.Controls.Add(this.btnsalir);
            this.Panelbotones.Controls.Add(this.btnCambiomesa);
            this.Panelbotones.Controls.Add(this.btnVerCuentas);
            this.Panelbotones.Controls.Add(this.panel2);
            this.Panelbotones.Controls.Add(this.btnParallevar);
            this.Panelbotones.Controls.Add(this.rptComunicador);
            this.Panelbotones.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.Panelbotones.Location = new System.Drawing.Point(0, 418);
            this.Panelbotones.Name = "Panelbotones";
            this.Panelbotones.Size = new System.Drawing.Size(279, 331);
            this.Panelbotones.TabIndex = 2;
            // 
            // btnSunat
            // 
            this.btnSunat.BackColor = System.Drawing.Color.Transparent;
            this.btnSunat.BackgroundImage = global::RestCsharp.Properties.Resources.azul;
            this.btnSunat.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSunat.FlatAppearance.BorderSize = 0;
            this.btnSunat.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnSunat.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnSunat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSunat.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSunat.ForeColor = System.Drawing.Color.White;
            this.btnSunat.Location = new System.Drawing.Point(12, 235);
            this.btnSunat.Name = "btnSunat";
            this.btnSunat.Size = new System.Drawing.Size(120, 84);
            this.btnSunat.TabIndex = 509;
            this.btnSunat.Text = "SUNAT";
            this.btnSunat.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSunat.UseVisualStyleBackColor = false;
            this.btnSunat.Visible = false;
            this.btnSunat.Click += new System.EventHandler(this.btnSunat_Click);
            // 
            // btnHerramientas
            // 
            this.btnHerramientas.BackColor = System.Drawing.Color.Transparent;
            this.btnHerramientas.BackgroundImage = global::RestCsharp.Properties.Resources.Rojo;
            this.btnHerramientas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnHerramientas.FlatAppearance.BorderSize = 0;
            this.btnHerramientas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnHerramientas.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnHerramientas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHerramientas.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHerramientas.ForeColor = System.Drawing.Color.White;
            this.btnHerramientas.Location = new System.Drawing.Point(143, 235);
            this.btnHerramientas.Name = "btnHerramientas";
            this.btnHerramientas.Size = new System.Drawing.Size(120, 84);
            this.btnHerramientas.TabIndex = 504;
            this.btnHerramientas.Text = "Herramientas";
            this.btnHerramientas.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnHerramientas.UseVisualStyleBackColor = false;
            this.btnHerramientas.Click += new System.EventHandler(this.btnHerramientas_Click);
            // 
            // btnsalir
            // 
            this.btnsalir.BackColor = System.Drawing.Color.Transparent;
            this.btnsalir.BackgroundImage = global::RestCsharp.Properties.Resources.naranja;
            this.btnsalir.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnsalir.FlatAppearance.BorderSize = 0;
            this.btnsalir.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnsalir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnsalir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsalir.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsalir.ForeColor = System.Drawing.Color.White;
            this.btnsalir.Location = new System.Drawing.Point(143, 145);
            this.btnsalir.Name = "btnsalir";
            this.btnsalir.Size = new System.Drawing.Size(120, 84);
            this.btnsalir.TabIndex = 503;
            this.btnsalir.Text = "Salir";
            this.btnsalir.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnsalir.UseVisualStyleBackColor = false;
            this.btnsalir.Click += new System.EventHandler(this.btnsalir_Click);
            // 
            // btnCambiomesa
            // 
            this.btnCambiomesa.BackColor = System.Drawing.Color.Transparent;
            this.btnCambiomesa.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.btnCambiomesa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCambiomesa.FlatAppearance.BorderSize = 0;
            this.btnCambiomesa.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnCambiomesa.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnCambiomesa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCambiomesa.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCambiomesa.ForeColor = System.Drawing.Color.White;
            this.btnCambiomesa.Location = new System.Drawing.Point(143, 55);
            this.btnCambiomesa.Name = "btnCambiomesa";
            this.btnCambiomesa.Size = new System.Drawing.Size(122, 84);
            this.btnCambiomesa.TabIndex = 502;
            this.btnCambiomesa.Text = "Cambio de mesa";
            this.btnCambiomesa.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCambiomesa.UseVisualStyleBackColor = false;
            this.btnCambiomesa.Visible = false;
            this.btnCambiomesa.Click += new System.EventHandler(this.btnCambiomesa_Click);
            // 
            // btnVerCuentas
            // 
            this.btnVerCuentas.BackColor = System.Drawing.Color.Transparent;
            this.btnVerCuentas.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.btnVerCuentas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnVerCuentas.FlatAppearance.BorderSize = 0;
            this.btnVerCuentas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnVerCuentas.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnVerCuentas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVerCuentas.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerCuentas.ForeColor = System.Drawing.Color.White;
            this.btnVerCuentas.Location = new System.Drawing.Point(12, 145);
            this.btnVerCuentas.Name = "btnVerCuentas";
            this.btnVerCuentas.Size = new System.Drawing.Size(120, 84);
            this.btnVerCuentas.TabIndex = 501;
            this.btnVerCuentas.Text = "Ver cuentas";
            this.btnVerCuentas.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnVerCuentas.UseVisualStyleBackColor = false;
            this.btnVerCuentas.Visible = false;
            this.btnVerCuentas.Click += new System.EventHandler(this.btnVerCuentas_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.Controls.Add(this.DATALISTADO_PRODUCTOS_OKA_libre);
            this.panel2.Controls.Add(this.DATALISTADO_PRODUCTOS_OKA);
            this.panel2.Controls.Add(this.ComboBox1);
            this.panel2.Controls.Add(this.Button2);
            this.panel2.Controls.Add(this.TextBox2);
            this.panel2.Controls.Add(this.DataGridView1);
            this.panel2.Controls.Add(this.TextBox1);
            this.panel2.Location = new System.Drawing.Point(253, 15);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(10, 10);
            this.panel2.TabIndex = 498;
            // 
            // DATALISTADO_PRODUCTOS_OKA_libre
            // 
            this.DATALISTADO_PRODUCTOS_OKA_libre.AllowUserToAddRows = false;
            this.DATALISTADO_PRODUCTOS_OKA_libre.AllowUserToDeleteRows = false;
            this.DATALISTADO_PRODUCTOS_OKA_libre.AllowUserToResizeRows = false;
            this.DATALISTADO_PRODUCTOS_OKA_libre.BackgroundColor = System.Drawing.Color.White;
            this.DATALISTADO_PRODUCTOS_OKA_libre.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.DATALISTADO_PRODUCTOS_OKA_libre.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DATALISTADO_PRODUCTOS_OKA_libre.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DataGridViewCheckBoxColumn2});
            this.DATALISTADO_PRODUCTOS_OKA_libre.EnableHeadersVisualStyles = false;
            this.DATALISTADO_PRODUCTOS_OKA_libre.Location = new System.Drawing.Point(18, 30);
            this.DATALISTADO_PRODUCTOS_OKA_libre.Name = "DATALISTADO_PRODUCTOS_OKA_libre";
            this.DATALISTADO_PRODUCTOS_OKA_libre.ReadOnly = true;
            this.DATALISTADO_PRODUCTOS_OKA_libre.RowHeadersVisible = false;
            this.DATALISTADO_PRODUCTOS_OKA_libre.RowHeadersWidth = 9;
            this.DATALISTADO_PRODUCTOS_OKA_libre.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DATALISTADO_PRODUCTOS_OKA_libre.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.DATALISTADO_PRODUCTOS_OKA_libre.RowTemplate.Height = 40;
            this.DATALISTADO_PRODUCTOS_OKA_libre.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DATALISTADO_PRODUCTOS_OKA_libre.Size = new System.Drawing.Size(165, 173);
            this.DATALISTADO_PRODUCTOS_OKA_libre.TabIndex = 495;
            // 
            // DataGridViewCheckBoxColumn2
            // 
            this.DataGridViewCheckBoxColumn2.DataPropertyName = "Marcar";
            this.DataGridViewCheckBoxColumn2.HeaderText = "Marcar";
            this.DataGridViewCheckBoxColumn2.Name = "DataGridViewCheckBoxColumn2";
            this.DataGridViewCheckBoxColumn2.ReadOnly = true;
            this.DataGridViewCheckBoxColumn2.Visible = false;
            // 
            // DATALISTADO_PRODUCTOS_OKA
            // 
            this.DATALISTADO_PRODUCTOS_OKA.AllowUserToAddRows = false;
            this.DATALISTADO_PRODUCTOS_OKA.AllowUserToDeleteRows = false;
            this.DATALISTADO_PRODUCTOS_OKA.AllowUserToResizeRows = false;
            this.DATALISTADO_PRODUCTOS_OKA.BackgroundColor = System.Drawing.Color.White;
            this.DATALISTADO_PRODUCTOS_OKA.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.DATALISTADO_PRODUCTOS_OKA.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DATALISTADO_PRODUCTOS_OKA.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DataGridViewCheckBoxColumn9});
            this.DATALISTADO_PRODUCTOS_OKA.EnableHeadersVisualStyles = false;
            this.DATALISTADO_PRODUCTOS_OKA.Location = new System.Drawing.Point(-55, 30);
            this.DATALISTADO_PRODUCTOS_OKA.Name = "DATALISTADO_PRODUCTOS_OKA";
            this.DATALISTADO_PRODUCTOS_OKA.ReadOnly = true;
            this.DATALISTADO_PRODUCTOS_OKA.RowHeadersVisible = false;
            this.DATALISTADO_PRODUCTOS_OKA.RowHeadersWidth = 9;
            this.DATALISTADO_PRODUCTOS_OKA.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DATALISTADO_PRODUCTOS_OKA.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.DATALISTADO_PRODUCTOS_OKA.RowTemplate.Height = 40;
            this.DATALISTADO_PRODUCTOS_OKA.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DATALISTADO_PRODUCTOS_OKA.Size = new System.Drawing.Size(165, 173);
            this.DATALISTADO_PRODUCTOS_OKA.TabIndex = 495;
            // 
            // DataGridViewCheckBoxColumn9
            // 
            this.DataGridViewCheckBoxColumn9.DataPropertyName = "Marcar";
            this.DataGridViewCheckBoxColumn9.HeaderText = "Marcar";
            this.DataGridViewCheckBoxColumn9.Name = "DataGridViewCheckBoxColumn9";
            this.DataGridViewCheckBoxColumn9.ReadOnly = true;
            this.DataGridViewCheckBoxColumn9.Visible = false;
            // 
            // ComboBox1
            // 
            this.ComboBox1.FormattingEnabled = true;
            this.ComboBox1.Location = new System.Drawing.Point(33, 47);
            this.ComboBox1.Name = "ComboBox1";
            this.ComboBox1.Size = new System.Drawing.Size(124, 21);
            this.ComboBox1.TabIndex = 497;
            // 
            // Button2
            // 
            this.Button2.Location = new System.Drawing.Point(18, 30);
            this.Button2.Name = "Button2";
            this.Button2.Size = new System.Drawing.Size(127, 72);
            this.Button2.TabIndex = 8;
            this.Button2.Text = "Button2";
            this.Button2.UseVisualStyleBackColor = true;
            // 
            // TextBox2
            // 
            this.TextBox2.Location = new System.Drawing.Point(3, 30);
            this.TextBox2.Name = "TextBox2";
            this.TextBox2.Size = new System.Drawing.Size(110, 22);
            this.TextBox2.TabIndex = 496;
            // 
            // DataGridView1
            // 
            this.DataGridView1.AllowUserToAddRows = false;
            this.DataGridView1.AllowUserToDeleteRows = false;
            this.DataGridView1.AllowUserToResizeRows = false;
            this.DataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.DataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DataGridViewCheckBoxColumn1});
            this.DataGridView1.EnableHeadersVisualStyles = false;
            this.DataGridView1.Location = new System.Drawing.Point(18, 30);
            this.DataGridView1.Name = "DataGridView1";
            this.DataGridView1.ReadOnly = true;
            this.DataGridView1.RowHeadersVisible = false;
            this.DataGridView1.RowHeadersWidth = 9;
            this.DataGridView1.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DataGridView1.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.DataGridView1.RowTemplate.Height = 40;
            this.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DataGridView1.Size = new System.Drawing.Size(70, 103);
            this.DataGridView1.TabIndex = 495;
            // 
            // DataGridViewCheckBoxColumn1
            // 
            this.DataGridViewCheckBoxColumn1.DataPropertyName = "Marcar";
            this.DataGridViewCheckBoxColumn1.HeaderText = "Marcar";
            this.DataGridViewCheckBoxColumn1.Name = "DataGridViewCheckBoxColumn1";
            this.DataGridViewCheckBoxColumn1.ReadOnly = true;
            this.DataGridViewCheckBoxColumn1.Visible = false;
            // 
            // TextBox1
            // 
            this.TextBox1.Location = new System.Drawing.Point(0, 47);
            this.TextBox1.Name = "TextBox1";
            this.TextBox1.Size = new System.Drawing.Size(110, 22);
            this.TextBox1.TabIndex = 496;
            // 
            // btnParallevar
            // 
            this.btnParallevar.BackColor = System.Drawing.Color.Transparent;
            this.btnParallevar.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.btnParallevar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnParallevar.FlatAppearance.BorderSize = 0;
            this.btnParallevar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnParallevar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnParallevar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnParallevar.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnParallevar.ForeColor = System.Drawing.Color.White;
            this.btnParallevar.Location = new System.Drawing.Point(12, 55);
            this.btnParallevar.Name = "btnParallevar";
            this.btnParallevar.Size = new System.Drawing.Size(120, 84);
            this.btnParallevar.TabIndex = 500;
            this.btnParallevar.Text = "Para llevar";
            this.btnParallevar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnParallevar.UseVisualStyleBackColor = false;
            this.btnParallevar.Visible = false;
            this.btnParallevar.Click += new System.EventHandler(this.btnParallevar_Click);
            // 
            // rptComunicador
            // 
            this.rptComunicador.AccessibilityKeyMap = null;
            this.rptComunicador.Location = new System.Drawing.Point(181, 169);
            this.rptComunicador.Name = "rptComunicador";
            this.rptComunicador.Size = new System.Drawing.Size(33, 30);
            this.rptComunicador.TabIndex = 0;
            // 
            // timerImprimir
            // 
            this.timerImprimir.Enabled = true;
            this.timerImprimir.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timerEsc
            // 
            this.timerEsc.Enabled = true;
            this.timerEsc.Tick += new System.EventHandler(this.timerEsc_Tick);
            // 
            // Visor_de_mesas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1366, 749);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.Name = "Visor_de_mesas";
            this.Text = "Visor de mesas";
            this.Load += new System.EventHandler(this.Visor_de_mesas_Load);
            this.panel1.ResumeLayout(false);
            this.PanelUNIONMesas.ResumeLayout(false);
            this.PanelHerramientas.ResumeLayout(false);
            this.PanelBienvenida.ResumeLayout(false);
            this.PanelSalones.ResumeLayout(false);
            this.Panelbotones.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DATALISTADO_PRODUCTOS_OKA_libre)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DATALISTADO_PRODUCTOS_OKA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        internal System.Windows.Forms.Panel PanelSalones;
        internal System.Windows.Forms.FlowLayoutPanel FlowLayoutPanel1;
        internal System.Windows.Forms.Panel Panelbotones;
        internal System.Windows.Forms.Panel panel2;
        internal System.Windows.Forms.DataGridView DATALISTADO_PRODUCTOS_OKA_libre;
        internal System.Windows.Forms.DataGridViewCheckBoxColumn DataGridViewCheckBoxColumn2;
        internal System.Windows.Forms.DataGridView DATALISTADO_PRODUCTOS_OKA;
        internal System.Windows.Forms.DataGridViewCheckBoxColumn DataGridViewCheckBoxColumn9;
        internal System.Windows.Forms.ComboBox ComboBox1;
        internal System.Windows.Forms.Button Button2;
        internal System.Windows.Forms.TextBox TextBox2;
        internal System.Windows.Forms.DataGridView DataGridView1;
        internal System.Windows.Forms.DataGridViewCheckBoxColumn DataGridViewCheckBoxColumn1;
        internal System.Windows.Forms.TextBox TextBox1;
        internal System.Windows.Forms.Panel PanelBienvenida;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.FlowLayoutPanel PanelMesas;
        private System.Windows.Forms.Button btnHerramientas;
        private System.Windows.Forms.Button btnsalir;
        private System.Windows.Forms.Button btnCambiomesa;
        private System.Windows.Forms.Button btnVerCuentas;
        private System.Windows.Forms.Button btnParallevar;
        private System.Windows.Forms.FlowLayoutPanel PanelHerramientas;
        private System.Windows.Forms.Button btnadministrar;
        private System.Windows.Forms.Button btncocina;
        private System.Windows.Forms.Button btncerrartodo;
        private System.Windows.Forms.Button btncerrarcaja;
        internal System.Windows.Forms.Label label1;
        internal System.Windows.Forms.Panel PanelUNIONMesas;
        internal System.Windows.Forms.Label labelPasos;
        internal System.Windows.Forms.Button btnvolver;
        internal System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnIngresoSalida;
        private System.Windows.Forms.Button btncodigosQR;
        private Telerik.ReportViewer.WinForms.ReportViewer rptComunicador;
        private System.Windows.Forms.Timer timerImprimir;
        private System.Windows.Forms.Timer timerEsc;
        private System.Windows.Forms.Button btnSunat;
        private System.Windows.Forms.Panel panelSunat;
    }
}