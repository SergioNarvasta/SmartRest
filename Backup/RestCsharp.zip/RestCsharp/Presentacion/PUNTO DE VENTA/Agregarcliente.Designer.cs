﻿
namespace RestCsharp.Presentacion.Ventas
{
    partial class Agregarcliente
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.PanelregistroClientes = new System.Windows.Forms.Panel();
            this.txtnroDoc = new System.Windows.Forms.TextBox();
            this.Label14 = new System.Windows.Forms.Label();
            this.RRuc = new System.Windows.Forms.RadioButton();
            this.Rdni = new System.Windows.Forms.RadioButton();
            this.btncerrar = new System.Windows.Forms.Button();
            this.lblcp = new System.Windows.Forms.Label();
            this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.BtnVolver = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtdirecciondefactura = new System.Windows.Forms.TextBox();
            this.txtcelular = new System.Windows.Forms.TextBox();
            this.txtnombrecliente = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.PanelregistroClientes.SuspendLayout();
            this.flowLayoutPanel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // PanelregistroClientes
            // 
            this.PanelregistroClientes.BackColor = System.Drawing.Color.White;
            this.PanelregistroClientes.Controls.Add(this.txtnroDoc);
            this.PanelregistroClientes.Controls.Add(this.Label14);
            this.PanelregistroClientes.Controls.Add(this.RRuc);
            this.PanelregistroClientes.Controls.Add(this.Rdni);
            this.PanelregistroClientes.Controls.Add(this.btncerrar);
            this.PanelregistroClientes.Controls.Add(this.lblcp);
            this.PanelregistroClientes.Controls.Add(this.flowLayoutPanel4);
            this.PanelregistroClientes.Controls.Add(this.panel5);
            this.PanelregistroClientes.Controls.Add(this.panel4);
            this.PanelregistroClientes.Controls.Add(this.panel2);
            this.PanelregistroClientes.Controls.Add(this.txtdirecciondefactura);
            this.PanelregistroClientes.Controls.Add(this.txtcelular);
            this.PanelregistroClientes.Controls.Add(this.txtnombrecliente);
            this.PanelregistroClientes.Controls.Add(this.label4);
            this.PanelregistroClientes.Controls.Add(this.label3);
            this.PanelregistroClientes.Controls.Add(this.label2);
            this.PanelregistroClientes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelregistroClientes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PanelregistroClientes.Location = new System.Drawing.Point(0, 0);
            this.PanelregistroClientes.Name = "PanelregistroClientes";
            this.PanelregistroClientes.Size = new System.Drawing.Size(650, 422);
            this.PanelregistroClientes.TabIndex = 633;
            // 
            // txtnroDoc
            // 
            this.txtnroDoc.Location = new System.Drawing.Point(138, 206);
            this.txtnroDoc.Name = "txtnroDoc";
            this.txtnroDoc.Size = new System.Drawing.Size(351, 26);
            this.txtnroDoc.TabIndex = 629;
            // 
            // Label14
            // 
            this.Label14.AutoSize = true;
            this.Label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label14.ForeColor = System.Drawing.Color.Black;
            this.Label14.Location = new System.Drawing.Point(3, 209);
            this.Label14.Name = "Label14";
            this.Label14.Size = new System.Drawing.Size(129, 20);
            this.Label14.TabIndex = 628;
            this.Label14.Text = "Nro. Documento:";
            // 
            // RRuc
            // 
            this.RRuc.AutoSize = true;
            this.RRuc.Location = new System.Drawing.Point(204, 173);
            this.RRuc.Name = "RRuc";
            this.RRuc.Size = new System.Drawing.Size(62, 24);
            this.RRuc.TabIndex = 627;
            this.RRuc.TabStop = true;
            this.RRuc.Text = "RUC";
            this.RRuc.UseVisualStyleBackColor = true;
            // 
            // Rdni
            // 
            this.Rdni.AutoSize = true;
            this.Rdni.Checked = true;
            this.Rdni.Location = new System.Drawing.Point(132, 173);
            this.Rdni.Name = "Rdni";
            this.Rdni.Size = new System.Drawing.Size(55, 24);
            this.Rdni.TabIndex = 626;
            this.Rdni.TabStop = true;
            this.Rdni.Text = "DNI";
            this.Rdni.UseVisualStyleBackColor = true;
            // 
            // btncerrar
            // 
            this.btncerrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(198)))), ((int)(((byte)(91)))));
            this.btncerrar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btncerrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btncerrar.FlatAppearance.BorderSize = 0;
            this.btncerrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(198)))), ((int)(((byte)(91)))));
            this.btncerrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(198)))), ((int)(((byte)(91)))));
            this.btncerrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncerrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncerrar.Location = new System.Drawing.Point(6, 10);
            this.btncerrar.Margin = new System.Windows.Forms.Padding(5);
            this.btncerrar.Name = "btncerrar";
            this.btncerrar.Size = new System.Drawing.Size(56, 29);
            this.btncerrar.TabIndex = 625;
            this.btncerrar.UseVisualStyleBackColor = false;
            this.btncerrar.Click += new System.EventHandler(this.btncerrar_Click);
            // 
            // lblcp
            // 
            this.lblcp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(198)))), ((int)(((byte)(91)))));
            this.lblcp.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblcp.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold);
            this.lblcp.ForeColor = System.Drawing.Color.White;
            this.lblcp.Location = new System.Drawing.Point(0, 0);
            this.lblcp.Name = "lblcp";
            this.lblcp.Size = new System.Drawing.Size(650, 47);
            this.lblcp.TabIndex = 624;
            this.lblcp.Text = "NUEVO CLIENTE";
            this.lblcp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // flowLayoutPanel4
            // 
            this.flowLayoutPanel4.Controls.Add(this.btnGuardar);
            this.flowLayoutPanel4.Controls.Add(this.BtnVolver);
            this.flowLayoutPanel4.Location = new System.Drawing.Point(138, 238);
            this.flowLayoutPanel4.Name = "flowLayoutPanel4";
            this.flowLayoutPanel4.Size = new System.Drawing.Size(345, 45);
            this.flowLayoutPanel4.TabIndex = 9;
            // 
            // btnGuardar
            // 
            this.btnGuardar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(204)))), ((int)(((byte)(1)))));
            this.btnGuardar.FlatAppearance.BorderSize = 0;
            this.btnGuardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGuardar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardar.Location = new System.Drawing.Point(3, 3);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(138, 38);
            this.btnGuardar.TabIndex = 8;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = false;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // BtnVolver
            // 
            this.BtnVolver.BackColor = System.Drawing.Color.White;
            this.BtnVolver.FlatAppearance.BorderSize = 0;
            this.BtnVolver.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnVolver.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnVolver.Location = new System.Drawing.Point(147, 3);
            this.BtnVolver.Name = "BtnVolver";
            this.BtnVolver.Size = new System.Drawing.Size(138, 38);
            this.BtnVolver.TabIndex = 8;
            this.BtnVolver.Text = "Volver";
            this.BtnVolver.UseVisualStyleBackColor = false;
            this.BtnVolver.Click += new System.EventHandler(this.BtnVolver_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(198)))), ((int)(((byte)(91)))));
            this.panel5.Location = new System.Drawing.Point(139, 125);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(387, 1);
            this.panel5.TabIndex = 6;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(198)))), ((int)(((byte)(91)))));
            this.panel4.Location = new System.Drawing.Point(138, 157);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(387, 1);
            this.panel4.TabIndex = 6;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(198)))), ((int)(((byte)(91)))));
            this.panel2.Location = new System.Drawing.Point(139, 93);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(387, 1);
            this.panel2.TabIndex = 6;
            // 
            // txtdirecciondefactura
            // 
            this.txtdirecciondefactura.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtdirecciondefactura.Location = new System.Drawing.Point(139, 132);
            this.txtdirecciondefactura.Name = "txtdirecciondefactura";
            this.txtdirecciondefactura.Size = new System.Drawing.Size(386, 19);
            this.txtdirecciondefactura.TabIndex = 5;
            // 
            // txtcelular
            // 
            this.txtcelular.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtcelular.Location = new System.Drawing.Point(138, 100);
            this.txtcelular.Name = "txtcelular";
            this.txtcelular.Size = new System.Drawing.Size(388, 19);
            this.txtcelular.TabIndex = 4;
            // 
            // txtnombrecliente
            // 
            this.txtnombrecliente.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtnombrecliente.Location = new System.Drawing.Point(138, 66);
            this.txtnombrecliente.Name = "txtnombrecliente";
            this.txtnombrecliente.Size = new System.Drawing.Size(387, 19);
            this.txtnombrecliente.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(54, 135);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 20);
            this.label4.TabIndex = 2;
            this.label4.Text = "Direccion:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 106);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(135, 20);
            this.label3.TabIndex = 1;
            this.label3.Text = "Celular(opcional): ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(67, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "Nombre:";
            // 
            // Agregarcliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.PanelregistroClientes);
            this.Name = "Agregarcliente";
            this.Size = new System.Drawing.Size(650, 422);
            this.Load += new System.EventHandler(this.Agregarcliente_Load);
            this.PanelregistroClientes.ResumeLayout(false);
            this.PanelregistroClientes.PerformLayout();
            this.flowLayoutPanel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel PanelregistroClientes;
        internal System.Windows.Forms.Label lblcp;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button BtnVolver;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtdirecciondefactura;
        private System.Windows.Forms.TextBox txtcelular;
        private System.Windows.Forms.TextBox txtnombrecliente;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btncerrar;
        private System.Windows.Forms.RadioButton RRuc;
        private System.Windows.Forms.RadioButton Rdni;
        private System.Windows.Forms.TextBox txtnroDoc;
        internal System.Windows.Forms.Label Label14;
    }
}
