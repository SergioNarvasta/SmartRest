﻿namespace RestCsharp.Presentacion.PUNTO_DE_VENTA
{
    partial class VisorDecuentas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VisorDecuentas));
            this.panel1 = new System.Windows.Forms.Panel();
            this.datalistadoPedidos = new System.Windows.Forms.DataGridView();
            this.Mesas = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Pedido = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Consumo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Idmesas = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.datalistadoDetalledeventa1 = new System.Windows.Forms.DataGridView();
            this.R = new System.Windows.Forms.DataGridViewButtonColumn();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.txtTotal1 = new System.Windows.Forms.Label();
            this.Label33 = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.lblOrden1 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btnPersonas1 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.lblmesa1 = new System.Windows.Forms.Label();
            this.lblfecha1 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.lblmozo1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnvermesas = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Panelcuenta2 = new System.Windows.Forms.Panel();
            this.datalistadoDetalledeventa2 = new System.Windows.Forms.DataGridView();
            this.dataGridViewImageColumn1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.lbltotal2 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.panel24 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.lblDivisiondeCuentas = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datalistadoPedidos)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datalistadoDetalledeventa1)).BeginInit();
            this.panel14.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel13.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.Panelcuenta2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datalistadoDetalledeventa2)).BeginInit();
            this.panel21.SuspendLayout();
            this.panel23.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.datalistadoPedidos);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(306, 529);
            this.panel1.TabIndex = 0;
            // 
            // datalistadoPedidos
            // 
            this.datalistadoPedidos.AllowUserToDeleteRows = false;
            this.datalistadoPedidos.AllowUserToResizeColumns = false;
            this.datalistadoPedidos.AllowUserToResizeRows = false;
            this.datalistadoPedidos.BackgroundColor = System.Drawing.SystemColors.Control;
            this.datalistadoPedidos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.datalistadoPedidos.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.RaisedHorizontal;
            this.datalistadoPedidos.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.datalistadoPedidos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datalistadoPedidos.ColumnHeadersVisible = false;
            this.datalistadoPedidos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Mesas,
            this.Pedido,
            this.Consumo,
            this.Idmesas});
            this.datalistadoPedidos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.datalistadoPedidos.Location = new System.Drawing.Point(0, 72);
            this.datalistadoPedidos.Name = "datalistadoPedidos";
            this.datalistadoPedidos.RowHeadersVisible = false;
            this.datalistadoPedidos.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.SystemColors.Control;
            this.datalistadoPedidos.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datalistadoPedidos.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(63)))), ((int)(((byte)(52)))));
            this.datalistadoPedidos.RowTemplate.Height = 50;
            this.datalistadoPedidos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datalistadoPedidos.Size = new System.Drawing.Size(306, 457);
            this.datalistadoPedidos.TabIndex = 2;
            this.datalistadoPedidos.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datalistadoPedidos_CellClick);
            // 
            // Mesas
            // 
            this.Mesas.HeaderText = "Mesas";
            this.Mesas.Name = "Mesas";
            // 
            // Pedido
            // 
            this.Pedido.HeaderText = "Pedido";
            this.Pedido.Name = "Pedido";
            // 
            // Consumo
            // 
            this.Consumo.HeaderText = "Consumo";
            this.Consumo.Name = "Consumo";
            // 
            // Idmesas
            // 
            this.Idmesas.HeaderText = "Idmesas";
            this.Idmesas.Name = "Idmesas";
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(0, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(306, 36);
            this.label2.TabIndex = 1;
            this.label2.Text = "Mesa";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(306, 36);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cuentas abiertas";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.datalistadoDetalledeventa1);
            this.panel2.Controls.Add(this.panel14);
            this.panel2.Controls.Add(this.lblOrden1);
            this.panel2.Controls.Add(this.panel13);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.panel7);
            this.panel2.Controls.Add(this.panel8);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(306, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(334, 529);
            this.panel2.TabIndex = 1;
            // 
            // datalistadoDetalledeventa1
            // 
            this.datalistadoDetalledeventa1.AllowUserToAddRows = false;
            this.datalistadoDetalledeventa1.AllowUserToDeleteRows = false;
            this.datalistadoDetalledeventa1.AllowUserToResizeRows = false;
            this.datalistadoDetalledeventa1.BackgroundColor = System.Drawing.Color.White;
            this.datalistadoDetalledeventa1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.datalistadoDetalledeventa1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.datalistadoDetalledeventa1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datalistadoDetalledeventa1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.datalistadoDetalledeventa1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datalistadoDetalledeventa1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.R});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.datalistadoDetalledeventa1.DefaultCellStyle = dataGridViewCellStyle2;
            this.datalistadoDetalledeventa1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.datalistadoDetalledeventa1.Location = new System.Drawing.Point(10, 161);
            this.datalistadoDetalledeventa1.Name = "datalistadoDetalledeventa1";
            this.datalistadoDetalledeventa1.ReadOnly = true;
            this.datalistadoDetalledeventa1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datalistadoDetalledeventa1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.datalistadoDetalledeventa1.RowHeadersVisible = false;
            this.datalistadoDetalledeventa1.RowHeadersWidth = 5;
            this.datalistadoDetalledeventa1.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.White;
            this.datalistadoDetalledeventa1.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datalistadoDetalledeventa1.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.datalistadoDetalledeventa1.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.WhiteSmoke;
            this.datalistadoDetalledeventa1.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.datalistadoDetalledeventa1.RowTemplate.Height = 30;
            this.datalistadoDetalledeventa1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datalistadoDetalledeventa1.Size = new System.Drawing.Size(314, 323);
            this.datalistadoDetalledeventa1.TabIndex = 560;
            this.datalistadoDetalledeventa1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datalistadoDetalledeventa1_CellClick);
            // 
            // R
            // 
            this.R.HeaderText = "";
            this.R.Name = "R";
            this.R.ReadOnly = true;
            this.R.Text = "-";
            this.R.UseColumnTextForButtonValue = true;
            this.R.Visible = false;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
            this.panel14.Controls.Add(this.panel16);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel14.Location = new System.Drawing.Point(10, 484);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(314, 35);
            this.panel14.TabIndex = 561;
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.Transparent;
            this.panel16.Controls.Add(this.txtTotal1);
            this.panel16.Controls.Add(this.Label33);
            this.panel16.Controls.Add(this.panel17);
            this.panel16.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel16.Location = new System.Drawing.Point(0, 0);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(314, 35);
            this.panel16.TabIndex = 547;
            // 
            // txtTotal1
            // 
            this.txtTotal1.BackColor = System.Drawing.Color.Transparent;
            this.txtTotal1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtTotal1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.txtTotal1.ForeColor = System.Drawing.Color.Gold;
            this.txtTotal1.Location = new System.Drawing.Point(91, 1);
            this.txtTotal1.Name = "txtTotal1";
            this.txtTotal1.Size = new System.Drawing.Size(223, 34);
            this.txtTotal1.TabIndex = 507;
            this.txtTotal1.Text = "0";
            this.txtTotal1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label33
            // 
            this.Label33.Dock = System.Windows.Forms.DockStyle.Left;
            this.Label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.Label33.ForeColor = System.Drawing.Color.White;
            this.Label33.Location = new System.Drawing.Point(0, 1);
            this.Label33.Name = "Label33";
            this.Label33.Size = new System.Drawing.Size(91, 34);
            this.Label33.TabIndex = 507;
            this.Label33.Text = "TOTAL:";
            this.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.DimGray;
            this.panel17.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel17.Location = new System.Drawing.Point(0, 0);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(314, 1);
            this.panel17.TabIndex = 542;
            // 
            // lblOrden1
            // 
            this.lblOrden1.BackColor = System.Drawing.Color.CornflowerBlue;
            this.lblOrden1.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblOrden1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrden1.ForeColor = System.Drawing.Color.White;
            this.lblOrden1.Location = new System.Drawing.Point(10, 132);
            this.lblOrden1.Name = "lblOrden1";
            this.lblOrden1.Size = new System.Drawing.Size(314, 29);
            this.lblOrden1.TabIndex = 3;
            this.lblOrden1.Text = "1";
            this.lblOrden1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.White;
            this.panel13.Controls.Add(this.flowLayoutPanel1);
            this.panel13.Controls.Add(this.label6);
            this.panel13.Controls.Add(this.lblmesa1);
            this.panel13.Controls.Add(this.lblfecha1);
            this.panel13.Controls.Add(this.Label4);
            this.panel13.Controls.Add(this.lblmozo1);
            this.panel13.Controls.Add(this.label5);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel13.Location = new System.Drawing.Point(10, 10);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(314, 122);
            this.panel13.TabIndex = 2;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.btnPersonas1);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(212, 0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(102, 122);
            this.flowLayoutPanel1.TabIndex = 14;
            // 
            // btnPersonas1
            // 
            this.btnPersonas1.BackColor = System.Drawing.Color.Transparent;
            this.btnPersonas1.BackgroundImage = global::RestCsharp.Properties.Resources.azul;
            this.btnPersonas1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPersonas1.FlatAppearance.BorderSize = 0;
            this.btnPersonas1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnPersonas1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnPersonas1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPersonas1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPersonas1.ForeColor = System.Drawing.Color.White;
            this.btnPersonas1.Location = new System.Drawing.Point(3, 3);
            this.btnPersonas1.Name = "btnPersonas1";
            this.btnPersonas1.Size = new System.Drawing.Size(93, 51);
            this.btnPersonas1.TabIndex = 636;
            this.btnPersonas1.Text = "# personas";
            this.btnPersonas1.UseVisualStyleBackColor = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(13, 93);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 17);
            this.label6.TabIndex = 12;
            this.label6.Text = "Mesa:";
            // 
            // lblmesa1
            // 
            this.lblmesa1.AutoSize = true;
            this.lblmesa1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmesa1.Location = new System.Drawing.Point(65, 93);
            this.lblmesa1.Name = "lblmesa1";
            this.lblmesa1.Size = new System.Drawing.Size(56, 17);
            this.lblmesa1.TabIndex = 13;
            this.lblmesa1.Text = "lblmesa";
            // 
            // lblfecha1
            // 
            this.lblfecha1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfecha1.Location = new System.Drawing.Point(65, 37);
            this.lblfecha1.Name = "lblfecha1";
            this.lblfecha1.Size = new System.Drawing.Size(141, 56);
            this.lblfecha1.TabIndex = 11;
            this.lblfecha1.Text = "-----";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label4.Location = new System.Drawing.Point(12, 37);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(51, 17);
            this.Label4.TabIndex = 10;
            this.Label4.Text = "Fecha:";
            // 
            // lblmozo1
            // 
            this.lblmozo1.AutoSize = true;
            this.lblmozo1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmozo1.Location = new System.Drawing.Point(69, 6);
            this.lblmozo1.Name = "lblmozo1";
            this.lblmozo1.Size = new System.Drawing.Size(39, 20);
            this.lblmozo1.TabIndex = 9;
            this.lblmozo1.Text = "-----";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 6);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "Mozo:";
            // 
            // panel6
            // 
            this.panel6.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel6.Location = new System.Drawing.Point(0, 10);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(10, 509);
            this.panel6.TabIndex = 1;
            // 
            // panel7
            // 
            this.panel7.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel7.Location = new System.Drawing.Point(0, 519);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(324, 10);
            this.panel7.TabIndex = 1;
            // 
            // panel8
            // 
            this.panel8.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel8.Location = new System.Drawing.Point(324, 10);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(10, 519);
            this.panel8.TabIndex = 1;
            // 
            // panel5
            // 
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(334, 10);
            this.panel5.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnvermesas);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 529);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1016, 85);
            this.panel4.TabIndex = 1;
            // 
            // btnvermesas
            // 
            this.btnvermesas.BackColor = System.Drawing.Color.Transparent;
            this.btnvermesas.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.btnvermesas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnvermesas.FlatAppearance.BorderSize = 0;
            this.btnvermesas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnvermesas.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnvermesas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnvermesas.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnvermesas.ForeColor = System.Drawing.Color.White;
            this.btnvermesas.Location = new System.Drawing.Point(12, 6);
            this.btnvermesas.Name = "btnvermesas";
            this.btnvermesas.Size = new System.Drawing.Size(116, 67);
            this.btnvermesas.TabIndex = 637;
            this.btnvermesas.Text = "Ver mesas";
            this.btnvermesas.UseVisualStyleBackColor = false;
            this.btnvermesas.Click += new System.EventHandler(this.btnvermesas_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.Panelcuenta2);
            this.panel3.Controls.Add(this.lblDivisiondeCuentas);
            this.panel3.Controls.Add(this.panel9);
            this.panel3.Controls.Add(this.panel10);
            this.panel3.Controls.Add(this.panel11);
            this.panel3.Controls.Add(this.panel12);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(640, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(334, 529);
            this.panel3.TabIndex = 2;
            // 
            // Panelcuenta2
            // 
            this.Panelcuenta2.Controls.Add(this.datalistadoDetalledeventa2);
            this.Panelcuenta2.Controls.Add(this.panel21);
            this.Panelcuenta2.Controls.Add(this.label8);
            this.Panelcuenta2.Location = new System.Drawing.Point(16, 170);
            this.Panelcuenta2.Name = "Panelcuenta2";
            this.Panelcuenta2.Size = new System.Drawing.Size(302, 343);
            this.Panelcuenta2.TabIndex = 5;
            this.Panelcuenta2.Visible = false;
            // 
            // datalistadoDetalledeventa2
            // 
            this.datalistadoDetalledeventa2.AllowUserToAddRows = false;
            this.datalistadoDetalledeventa2.AllowUserToDeleteRows = false;
            this.datalistadoDetalledeventa2.AllowUserToResizeRows = false;
            this.datalistadoDetalledeventa2.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.datalistadoDetalledeventa2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.datalistadoDetalledeventa2.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.datalistadoDetalledeventa2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datalistadoDetalledeventa2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.datalistadoDetalledeventa2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datalistadoDetalledeventa2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewImageColumn1});
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.datalistadoDetalledeventa2.DefaultCellStyle = dataGridViewCellStyle5;
            this.datalistadoDetalledeventa2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.datalistadoDetalledeventa2.Location = new System.Drawing.Point(0, 29);
            this.datalistadoDetalledeventa2.Name = "datalistadoDetalledeventa2";
            this.datalistadoDetalledeventa2.ReadOnly = true;
            this.datalistadoDetalledeventa2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datalistadoDetalledeventa2.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.datalistadoDetalledeventa2.RowHeadersVisible = false;
            this.datalistadoDetalledeventa2.RowHeadersWidth = 5;
            this.datalistadoDetalledeventa2.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.WhiteSmoke;
            this.datalistadoDetalledeventa2.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datalistadoDetalledeventa2.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.datalistadoDetalledeventa2.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.WhiteSmoke;
            this.datalistadoDetalledeventa2.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.datalistadoDetalledeventa2.RowTemplate.Height = 30;
            this.datalistadoDetalledeventa2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datalistadoDetalledeventa2.Size = new System.Drawing.Size(302, 277);
            this.datalistadoDetalledeventa2.TabIndex = 561;
            // 
            // dataGridViewImageColumn1
            // 
            this.dataGridViewImageColumn1.HeaderText = "";
            this.dataGridViewImageColumn1.Image = ((System.Drawing.Image)(resources.GetObject("dataGridViewImageColumn1.Image")));
            this.dataGridViewImageColumn1.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Zoom;
            this.dataGridViewImageColumn1.Name = "dataGridViewImageColumn1";
            this.dataGridViewImageColumn1.ReadOnly = true;
            this.dataGridViewImageColumn1.Visible = false;
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
            this.panel21.Controls.Add(this.panel23);
            this.panel21.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel21.Location = new System.Drawing.Point(0, 306);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(302, 37);
            this.panel21.TabIndex = 562;
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.Color.Transparent;
            this.panel23.Controls.Add(this.lbltotal2);
            this.panel23.Controls.Add(this.label18);
            this.panel23.Controls.Add(this.panel24);
            this.panel23.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel23.Location = new System.Drawing.Point(0, 0);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(302, 31);
            this.panel23.TabIndex = 547;
            // 
            // lbltotal2
            // 
            this.lbltotal2.BackColor = System.Drawing.Color.Transparent;
            this.lbltotal2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbltotal2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.lbltotal2.ForeColor = System.Drawing.Color.Gold;
            this.lbltotal2.Location = new System.Drawing.Point(115, 1);
            this.lbltotal2.Name = "lbltotal2";
            this.lbltotal2.Size = new System.Drawing.Size(187, 30);
            this.lbltotal2.TabIndex = 507;
            this.lbltotal2.Text = "0";
            this.lbltotal2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label18
            // 
            this.label18.Dock = System.Windows.Forms.DockStyle.Left;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(0, 1);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(115, 30);
            this.label18.TabIndex = 507;
            this.label18.Text = "TOTAL:";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.Color.DimGray;
            this.panel24.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel24.Location = new System.Drawing.Point(0, 0);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(302, 1);
            this.panel24.TabIndex = 542;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.label8.Dock = System.Windows.Forms.DockStyle.Top;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(0, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(302, 29);
            this.label8.TabIndex = 4;
            this.label8.Text = "1";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDivisiondeCuentas
            // 
            this.lblDivisiondeCuentas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
            this.lblDivisiondeCuentas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDivisiondeCuentas.ForeColor = System.Drawing.Color.White;
            this.lblDivisiondeCuentas.Location = new System.Drawing.Point(65, 23);
            this.lblDivisiondeCuentas.Name = "lblDivisiondeCuentas";
            this.lblDivisiondeCuentas.Size = new System.Drawing.Size(252, 144);
            this.lblDivisiondeCuentas.TabIndex = 4;
            this.lblDivisiondeCuentas.Text = "Seleccione los Productos y presione\r\nAQUI\r\npara crear otra cuenta";
            this.lblDivisiondeCuentas.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblDivisiondeCuentas.Click += new System.EventHandler(this.lblDivisiondeCuentas_Click);
            // 
            // panel9
            // 
            this.panel9.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel9.Location = new System.Drawing.Point(0, 10);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(10, 509);
            this.panel9.TabIndex = 1;
            // 
            // panel10
            // 
            this.panel10.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel10.Location = new System.Drawing.Point(0, 519);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(324, 10);
            this.panel10.TabIndex = 1;
            // 
            // panel11
            // 
            this.panel11.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel11.Location = new System.Drawing.Point(324, 10);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(10, 519);
            this.panel11.TabIndex = 1;
            // 
            // panel12
            // 
            this.panel12.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel12.Location = new System.Drawing.Point(0, 0);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(334, 10);
            this.panel12.TabIndex = 0;
            // 
            // VisorDecuentas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1016, 614);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel4);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "VisorDecuentas";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Visor de cuentas";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.VisorDecuentas_FormClosed);
            this.Load += new System.EventHandler(this.VisorDecuentas_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.datalistadoPedidos)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.datalistadoDetalledeventa1)).EndInit();
            this.panel14.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.Panelcuenta2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.datalistadoDetalledeventa2)).EndInit();
            this.panel21.ResumeLayout(false);
            this.panel23.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView datalistadoPedidos;
        private System.Windows.Forms.DataGridViewTextBoxColumn Mesas;
        private System.Windows.Forms.DataGridViewTextBoxColumn Pedido;
        private System.Windows.Forms.DataGridViewTextBoxColumn Consumo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Idmesas;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label lblOrden1;
        private System.Windows.Forms.Panel panel13;
        public System.Windows.Forms.DataGridView datalistadoDetalledeventa1;
        private System.Windows.Forms.Panel panel14;
        internal System.Windows.Forms.Panel panel16;
        internal System.Windows.Forms.Label txtTotal1;
        internal System.Windows.Forms.Label Label33;
        internal System.Windows.Forms.Panel panel17;
        internal System.Windows.Forms.Label label6;
        internal System.Windows.Forms.Label lblmesa1;
        internal System.Windows.Forms.Label lblfecha1;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label lblmozo1;
        internal System.Windows.Forms.Label label5;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        internal System.Windows.Forms.Button btnPersonas1;
        private System.Windows.Forms.Panel Panelcuenta2;
        public System.Windows.Forms.DataGridView datalistadoDetalledeventa2;
        private System.Windows.Forms.Panel panel21;
        internal System.Windows.Forms.Panel panel23;
        internal System.Windows.Forms.Label lbltotal2;
        internal System.Windows.Forms.Label label18;
        internal System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblDivisiondeCuentas;
        internal System.Windows.Forms.Button btnvermesas;
        private System.Windows.Forms.DataGridViewButtonColumn R;
        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn1;
    }
}