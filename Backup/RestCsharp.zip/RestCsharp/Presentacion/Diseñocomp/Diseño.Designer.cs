﻿
namespace RestCsharp.Presentacion.Diseñocomp
{
    partial class Diseño
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Diseño));
            this.PanelTICKET = new System.Windows.Forms.Panel();
            this.PictureBox3 = new System.Windows.Forms.PictureBox();
            this.Panel16 = new System.Windows.Forms.Panel();
            this.Panel15 = new System.Windows.Forms.Panel();
            this.Panel14 = new System.Windows.Forms.Panel();
            this.Panel13 = new System.Windows.Forms.Panel();
            this.lblcliente = new System.Windows.Forms.Label();
            this.Label9 = new System.Windows.Forms.Label();
            this.Panel4 = new System.Windows.Forms.Panel();
            this.Panel3 = new System.Windows.Forms.Panel();
            this.Label19 = new System.Windows.Forms.Label();
            this.Label37 = new System.Windows.Forms.Label();
            this.Label31 = new System.Windows.Forms.Label();
            this.Label16 = new System.Windows.Forms.Label();
            this.Label10 = new System.Windows.Forms.Label();
            this.Label32 = new System.Windows.Forms.Label();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.Panel5 = new System.Windows.Forms.Panel();
            this.txtMoneda_String = new System.Windows.Forms.TextBox();
            this.txtpagina_o_facebook = new System.Windows.Forms.TextBox();
            this.TextBox1 = new System.Windows.Forms.TextBox();
            this.txtAutorizacion_fiscal = new System.Windows.Forms.TextBox();
            this.TXTANUNCIO = new System.Windows.Forms.TextBox();
            this.txtAgradecimiento = new System.Windows.Forms.TextBox();
            this.txtProvincia_departamento = new System.Windows.Forms.TextBox();
            this.txtDireccion = new System.Windows.Forms.TextBox();
            this.txtEmpresa_RUC = new System.Windows.Forms.TextBox();
            this.txtempresaTICKET = new System.Windows.Forms.TextBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.Label13 = new System.Windows.Forms.Label();
            this.Label17 = new System.Windows.Forms.Label();
            this.lblcajero = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.Label8 = new System.Windows.Forms.Label();
            this.Label6 = new System.Windows.Forms.Label();
            this.Label36 = new System.Windows.Forms.Label();
            this.Label33 = new System.Windows.Forms.Label();
            this.Label24 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label11 = new System.Windows.Forms.Label();
            this.Label14 = new System.Windows.Forms.Label();
            this.Label30 = new System.Windows.Forms.Label();
            this.Label28 = new System.Windows.Forms.Label();
            this.Label25 = new System.Windows.Forms.Label();
            this.Label29 = new System.Windows.Forms.Label();
            this.Label27 = new System.Windows.Forms.Label();
            this.Label35 = new System.Windows.Forms.Label();
            this.Label34 = new System.Windows.Forms.Label();
            this.Label18 = new System.Windows.Forms.Label();
            this.Label26 = new System.Windows.Forms.Label();
            this.Label21 = new System.Windows.Forms.Label();
            this.Label15 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.lblfecha = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.PictureBox1 = new System.Windows.Forms.PictureBox();
            this.PictureBox2 = new System.Windows.Forms.PictureBox();
            this.Panel6 = new System.Windows.Forms.Panel();
            this.Label12 = new System.Windows.Forms.Label();
            this.btnguardar = new System.Windows.Forms.Button();
            this.btnFacturaBoleta = new System.Windows.Forms.Button();
            this.btnTicket = new System.Windows.Forms.Button();
            this.PanelTICKET.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox2)).BeginInit();
            this.Panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // PanelTICKET
            // 
            this.PanelTICKET.AutoScroll = true;
            this.PanelTICKET.BackColor = System.Drawing.Color.White;
            this.PanelTICKET.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PanelTICKET.BackgroundImage")));
            this.PanelTICKET.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PanelTICKET.Controls.Add(this.PictureBox3);
            this.PanelTICKET.Controls.Add(this.Panel16);
            this.PanelTICKET.Controls.Add(this.Panel15);
            this.PanelTICKET.Controls.Add(this.Panel14);
            this.PanelTICKET.Controls.Add(this.Panel13);
            this.PanelTICKET.Controls.Add(this.lblcliente);
            this.PanelTICKET.Controls.Add(this.Label9);
            this.PanelTICKET.Controls.Add(this.Panel4);
            this.PanelTICKET.Controls.Add(this.Panel3);
            this.PanelTICKET.Controls.Add(this.Label19);
            this.PanelTICKET.Controls.Add(this.Label37);
            this.PanelTICKET.Controls.Add(this.Label31);
            this.PanelTICKET.Controls.Add(this.Label16);
            this.PanelTICKET.Controls.Add(this.Label10);
            this.PanelTICKET.Controls.Add(this.Label32);
            this.PanelTICKET.Controls.Add(this.Panel1);
            this.PanelTICKET.Controls.Add(this.Panel5);
            this.PanelTICKET.Controls.Add(this.txtMoneda_String);
            this.PanelTICKET.Controls.Add(this.txtpagina_o_facebook);
            this.PanelTICKET.Controls.Add(this.TextBox1);
            this.PanelTICKET.Controls.Add(this.txtAutorizacion_fiscal);
            this.PanelTICKET.Controls.Add(this.TXTANUNCIO);
            this.PanelTICKET.Controls.Add(this.txtAgradecimiento);
            this.PanelTICKET.Controls.Add(this.txtProvincia_departamento);
            this.PanelTICKET.Controls.Add(this.txtDireccion);
            this.PanelTICKET.Controls.Add(this.txtEmpresa_RUC);
            this.PanelTICKET.Controls.Add(this.txtempresaTICKET);
            this.PanelTICKET.Controls.Add(this.Label5);
            this.PanelTICKET.Controls.Add(this.Label13);
            this.PanelTICKET.Controls.Add(this.Label17);
            this.PanelTICKET.Controls.Add(this.lblcajero);
            this.PanelTICKET.Controls.Add(this.Label1);
            this.PanelTICKET.Controls.Add(this.Label8);
            this.PanelTICKET.Controls.Add(this.Label6);
            this.PanelTICKET.Controls.Add(this.Label36);
            this.PanelTICKET.Controls.Add(this.Label33);
            this.PanelTICKET.Controls.Add(this.Label24);
            this.PanelTICKET.Controls.Add(this.Label4);
            this.PanelTICKET.Controls.Add(this.Label11);
            this.PanelTICKET.Controls.Add(this.Label14);
            this.PanelTICKET.Controls.Add(this.Label30);
            this.PanelTICKET.Controls.Add(this.Label28);
            this.PanelTICKET.Controls.Add(this.Label25);
            this.PanelTICKET.Controls.Add(this.Label29);
            this.PanelTICKET.Controls.Add(this.Label27);
            this.PanelTICKET.Controls.Add(this.Label35);
            this.PanelTICKET.Controls.Add(this.Label34);
            this.PanelTICKET.Controls.Add(this.Label18);
            this.PanelTICKET.Controls.Add(this.Label26);
            this.PanelTICKET.Controls.Add(this.Label21);
            this.PanelTICKET.Controls.Add(this.Label15);
            this.PanelTICKET.Controls.Add(this.Label3);
            this.PanelTICKET.Controls.Add(this.lblfecha);
            this.PanelTICKET.Controls.Add(this.Label7);
            this.PanelTICKET.Controls.Add(this.PictureBox1);
            this.PanelTICKET.Controls.Add(this.PictureBox2);
            this.PanelTICKET.Dock = System.Windows.Forms.DockStyle.Left;
            this.PanelTICKET.Location = new System.Drawing.Point(0, 0);
            this.PanelTICKET.Name = "PanelTICKET";
            this.PanelTICKET.Size = new System.Drawing.Size(460, 715);
            this.PanelTICKET.TabIndex = 567;
            // 
            // PictureBox3
            // 
            this.PictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox3.Image")));
            this.PictureBox3.Location = new System.Drawing.Point(32, 178);
            this.PictureBox3.Name = "PictureBox3";
            this.PictureBox3.Size = new System.Drawing.Size(378, 51);
            this.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PictureBox3.TabIndex = 610;
            this.PictureBox3.TabStop = false;
            // 
            // Panel16
            // 
            this.Panel16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(204)))), ((int)(((byte)(1)))));
            this.Panel16.Location = new System.Drawing.Point(191, 451);
            this.Panel16.Name = "Panel16";
            this.Panel16.Size = new System.Drawing.Size(60, 1);
            this.Panel16.TabIndex = 564;
            // 
            // Panel15
            // 
            this.Panel15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(204)))), ((int)(((byte)(1)))));
            this.Panel15.Location = new System.Drawing.Point(36, 644);
            this.Panel15.Name = "Panel15";
            this.Panel15.Size = new System.Drawing.Size(386, 1);
            this.Panel15.TabIndex = 564;
            // 
            // Panel14
            // 
            this.Panel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(204)))), ((int)(((byte)(1)))));
            this.Panel14.Location = new System.Drawing.Point(36, 614);
            this.Panel14.Name = "Panel14";
            this.Panel14.Size = new System.Drawing.Size(386, 1);
            this.Panel14.TabIndex = 564;
            // 
            // Panel13
            // 
            this.Panel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(204)))), ((int)(((byte)(1)))));
            this.Panel13.Location = new System.Drawing.Point(36, 593);
            this.Panel13.Name = "Panel13";
            this.Panel13.Size = new System.Drawing.Size(386, 1);
            this.Panel13.TabIndex = 564;
            // 
            // lblcliente
            // 
            this.lblcliente.AutoSize = true;
            this.lblcliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcliente.Location = new System.Drawing.Point(136, 297);
            this.lblcliente.Name = "lblcliente";
            this.lblcliente.Size = new System.Drawing.Size(152, 13);
            this.lblcliente.TabIndex = 2;
            this.lblcliente.Text = ": NOMBRE DEL CLIENTE";
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label9.Location = new System.Drawing.Point(30, 297);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(50, 13);
            this.Label9.TabIndex = 2;
            this.Label9.Text = "Cliente:";
            // 
            // Panel4
            // 
            this.Panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(204)))), ((int)(((byte)(1)))));
            this.Panel4.Location = new System.Drawing.Point(30, 158);
            this.Panel4.Name = "Panel4";
            this.Panel4.Size = new System.Drawing.Size(386, 1);
            this.Panel4.TabIndex = 564;
            // 
            // Panel3
            // 
            this.Panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(204)))), ((int)(((byte)(1)))));
            this.Panel3.Location = new System.Drawing.Point(30, 137);
            this.Panel3.Name = "Panel3";
            this.Panel3.Size = new System.Drawing.Size(386, 1);
            this.Panel3.TabIndex = 564;
            // 
            // Label19
            // 
            this.Label19.AutoSize = true;
            this.Label19.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.Label19.Location = new System.Drawing.Point(375, 502);
            this.Label19.Name = "Label19";
            this.Label19.Size = new System.Drawing.Size(47, 13);
            this.Label19.TabIndex = 2;
            this.Label19.Text = "Efectivo";
            // 
            // Label37
            // 
            this.Label37.AutoSize = true;
            this.Label37.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.Label37.Location = new System.Drawing.Point(383, 477);
            this.Label37.Name = "Label37";
            this.Label37.Size = new System.Drawing.Size(35, 13);
            this.Label37.TabIndex = 2;
            this.Label37.Text = "S/. 14";
            // 
            // Label31
            // 
            this.Label31.AutoSize = true;
            this.Label31.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.Label31.Location = new System.Drawing.Point(383, 454);
            this.Label31.Name = "Label31";
            this.Label31.Size = new System.Drawing.Size(35, 13);
            this.Label31.TabIndex = 2;
            this.Label31.Text = "S/. 50";
            // 
            // Label16
            // 
            this.Label16.AutoSize = true;
            this.Label16.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.Label16.Location = new System.Drawing.Point(297, 502);
            this.Label16.Name = "Label16";
            this.Label16.Size = new System.Drawing.Size(79, 13);
            this.Label16.TabIndex = 2;
            this.Label16.Text = "Tipo de Pago:";
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.Label10.Location = new System.Drawing.Point(326, 477);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(50, 13);
            this.Label10.TabIndex = 2;
            this.Label10.Text = "VUELTO:";
            // 
            // Label32
            // 
            this.Label32.AutoSize = true;
            this.Label32.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.Label32.Location = new System.Drawing.Point(317, 454);
            this.Label32.Name = "Label32";
            this.Label32.Size = new System.Drawing.Size(59, 13);
            this.Label32.TabIndex = 2;
            this.Label32.Text = "EFECTIVO:";
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(204)))), ((int)(((byte)(1)))));
            this.Panel1.Location = new System.Drawing.Point(30, 116);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(386, 1);
            this.Panel1.TabIndex = 564;
            // 
            // Panel5
            // 
            this.Panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(204)))), ((int)(((byte)(1)))));
            this.Panel5.Location = new System.Drawing.Point(32, 95);
            this.Panel5.Name = "Panel5";
            this.Panel5.Size = new System.Drawing.Size(380, 1);
            this.Panel5.TabIndex = 564;
            // 
            // txtMoneda_String
            // 
            this.txtMoneda_String.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtMoneda_String.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMoneda_String.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMoneda_String.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtMoneda_String.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.txtMoneda_String.ForeColor = System.Drawing.Color.Black;
            this.txtMoneda_String.Location = new System.Drawing.Point(191, 436);
            this.txtMoneda_String.Name = "txtMoneda_String";
            this.txtMoneda_String.Size = new System.Drawing.Size(218, 15);
            this.txtMoneda_String.TabIndex = 563;
            this.txtMoneda_String.Text = "SOLES";
            // 
            // txtpagina_o_facebook
            // 
            this.txtpagina_o_facebook.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtpagina_o_facebook.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtpagina_o_facebook.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
            this.txtpagina_o_facebook.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtpagina_o_facebook.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.txtpagina_o_facebook.ForeColor = System.Drawing.Color.Black;
            this.txtpagina_o_facebook.Location = new System.Drawing.Point(30, 600);
            this.txtpagina_o_facebook.Name = "txtpagina_o_facebook";
            this.txtpagina_o_facebook.Size = new System.Drawing.Size(382, 15);
            this.txtpagina_o_facebook.TabIndex = 563;
            this.txtpagina_o_facebook.Text = "pagina web o pagina de facebook";
            this.txtpagina_o_facebook.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TextBox1
            // 
            this.TextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(243)))), ((int)(((byte)(244)))));
            this.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TextBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TextBox1.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.TextBox1.ForeColor = System.Drawing.Color.Black;
            this.TextBox1.Location = new System.Drawing.Point(58, 891);
            this.TextBox1.Multiline = true;
            this.TextBox1.Name = "TextBox1";
            this.TextBox1.Size = new System.Drawing.Size(302, 12);
            this.TextBox1.TabIndex = 563;
            this.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtAutorizacion_fiscal
            // 
            this.txtAutorizacion_fiscal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtAutorizacion_fiscal.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAutorizacion_fiscal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtAutorizacion_fiscal.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.txtAutorizacion_fiscal.ForeColor = System.Drawing.Color.Black;
            this.txtAutorizacion_fiscal.Location = new System.Drawing.Point(30, 728);
            this.txtAutorizacion_fiscal.Multiline = true;
            this.txtAutorizacion_fiscal.Name = "txtAutorizacion_fiscal";
            this.txtAutorizacion_fiscal.Size = new System.Drawing.Size(384, 129);
            this.txtAutorizacion_fiscal.TabIndex = 563;
            this.txtAutorizacion_fiscal.Text = "DATOS DE RESOLUCION DE AUTORIZACION\r\nEmitidas por la Entidad controladora de Impu" +
    "estos";
            this.txtAutorizacion_fiscal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TXTANUNCIO
            // 
            this.TXTANUNCIO.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.TXTANUNCIO.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TXTANUNCIO.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.TXTANUNCIO.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TXTANUNCIO.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.TXTANUNCIO.ForeColor = System.Drawing.Color.Black;
            this.TXTANUNCIO.Location = new System.Drawing.Point(30, 623);
            this.TXTANUNCIO.Name = "TXTANUNCIO";
            this.TXTANUNCIO.Size = new System.Drawing.Size(382, 15);
            this.TXTANUNCIO.TabIndex = 563;
            this.TXTANUNCIO.Text = "NO SE ACEPTAN DEVOLUCIONES PASADAS LAS 24 HORAS";
            this.TXTANUNCIO.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtAgradecimiento
            // 
            this.txtAgradecimiento.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtAgradecimiento.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAgradecimiento.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtAgradecimiento.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtAgradecimiento.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.txtAgradecimiento.ForeColor = System.Drawing.Color.Black;
            this.txtAgradecimiento.Location = new System.Drawing.Point(30, 579);
            this.txtAgradecimiento.Name = "txtAgradecimiento";
            this.txtAgradecimiento.Size = new System.Drawing.Size(382, 15);
            this.txtAgradecimiento.TabIndex = 563;
            this.txtAgradecimiento.Text = "!GRACIAS POR TU COMPRA VUELVE PRONTO!";
            this.txtAgradecimiento.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtProvincia_departamento
            // 
            this.txtProvincia_departamento.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtProvincia_departamento.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtProvincia_departamento.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtProvincia_departamento.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtProvincia_departamento.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.txtProvincia_departamento.ForeColor = System.Drawing.Color.Black;
            this.txtProvincia_departamento.Location = new System.Drawing.Point(30, 144);
            this.txtProvincia_departamento.Name = "txtProvincia_departamento";
            this.txtProvincia_departamento.Size = new System.Drawing.Size(390, 15);
            this.txtProvincia_departamento.TabIndex = 563;
            this.txtProvincia_departamento.Text = "PROVINCIA - DEPARTAMENTO";
            this.txtProvincia_departamento.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtDireccion
            // 
            this.txtDireccion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtDireccion.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDireccion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtDireccion.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtDireccion.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.txtDireccion.ForeColor = System.Drawing.Color.Black;
            this.txtDireccion.Location = new System.Drawing.Point(30, 123);
            this.txtDireccion.Name = "txtDireccion";
            this.txtDireccion.Size = new System.Drawing.Size(390, 15);
            this.txtDireccion.TabIndex = 563;
            this.txtDireccion.Text = "DIRECCION (AVENIDA O CALLE)";
            this.txtDireccion.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtEmpresa_RUC
            // 
            this.txtEmpresa_RUC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtEmpresa_RUC.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtEmpresa_RUC.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtEmpresa_RUC.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtEmpresa_RUC.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.txtEmpresa_RUC.ForeColor = System.Drawing.Color.Black;
            this.txtEmpresa_RUC.Location = new System.Drawing.Point(30, 102);
            this.txtEmpresa_RUC.Name = "txtEmpresa_RUC";
            this.txtEmpresa_RUC.Size = new System.Drawing.Size(390, 15);
            this.txtEmpresa_RUC.TabIndex = 563;
            this.txtEmpresa_RUC.Text = "EMPRESA S.A.C. - RUC: 20123123";
            this.txtEmpresa_RUC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtempresaTICKET
            // 
            this.txtempresaTICKET.BackColor = System.Drawing.Color.White;
            this.txtempresaTICKET.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtempresaTICKET.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtempresaTICKET.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtempresaTICKET.Enabled = false;
            this.txtempresaTICKET.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.txtempresaTICKET.ForeColor = System.Drawing.Color.Black;
            this.txtempresaTICKET.Location = new System.Drawing.Point(30, 74);
            this.txtempresaTICKET.Name = "txtempresaTICKET";
            this.txtempresaTICKET.Size = new System.Drawing.Size(390, 18);
            this.txtempresaTICKET.TabIndex = 563;
            this.txtempresaTICKET.Text = "NOMBRE DE TU EMPRESA";
            this.txtempresaTICKET.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label5.Location = new System.Drawing.Point(29, 162);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(99, 13);
            this.Label5.TabIndex = 2;
            this.Label5.Text = "TICKET : T0001";
            // 
            // Label13
            // 
            this.Label13.AutoSize = true;
            this.Label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label13.Location = new System.Drawing.Point(30, 253);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(47, 13);
            this.Label13.TabIndex = 2;
            this.Label13.Text = "Cajero:";
            // 
            // Label17
            // 
            this.Label17.AutoSize = true;
            this.Label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label17.Location = new System.Drawing.Point(136, 275);
            this.Label17.Name = "Label17";
            this.Label17.Size = new System.Drawing.Size(83, 13);
            this.Label17.TabIndex = 2;
            this.Label17.Text = ": 19/02/2018";
            // 
            // lblcajero
            // 
            this.lblcajero.AutoSize = true;
            this.lblcajero.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcajero.Location = new System.Drawing.Point(136, 253);
            this.lblcajero.Name = "lblcajero";
            this.lblcajero.Size = new System.Drawing.Size(119, 13);
            this.lblcajero.TabIndex = 2;
            this.lblcajero.Text = ": Nombre del Cajero";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.Label1.Location = new System.Drawing.Point(29, 436);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(157, 13);
            this.Label1.TabIndex = 2;
            this.Label1.Text = "SON: VEINTISEIS CON 90/100 ";
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.Label8.Location = new System.Drawing.Point(367, 327);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(47, 13);
            this.Label8.TabIndex = 2;
            this.Label8.Text = "Importe";
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.Label6.Location = new System.Drawing.Point(89, 327);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(67, 13);
            this.Label6.TabIndex = 2;
            this.Label6.Text = "Descripcion";
            // 
            // Label36
            // 
            this.Label36.AutoSize = true;
            this.Label36.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.Label36.Location = new System.Drawing.Point(29, 563);
            this.Label36.Name = "Label36";
            this.Label36.Size = new System.Drawing.Size(391, 13);
            this.Label36.TabIndex = 2;
            this.Label36.Text = "---------------------------------------------------------------------------------" +
    "---------------";
            // 
            // Label33
            // 
            this.Label33.AutoSize = true;
            this.Label33.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.Label33.Location = new System.Drawing.Point(27, 537);
            this.Label33.Name = "Label33";
            this.Label33.Size = new System.Drawing.Size(391, 13);
            this.Label33.TabIndex = 2;
            this.Label33.Text = "---------------------------------------------------------------------------------" +
    "---------------";
            // 
            // Label24
            // 
            this.Label24.AutoSize = true;
            this.Label24.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.Label24.Location = new System.Drawing.Point(27, 366);
            this.Label24.Name = "Label24";
            this.Label24.Size = new System.Drawing.Size(391, 13);
            this.Label24.TabIndex = 2;
            this.Label24.Text = "---------------------------------------------------------------------------------" +
    "---------------";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.Label4.Location = new System.Drawing.Point(27, 240);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(391, 13);
            this.Label4.TabIndex = 2;
            this.Label4.Text = "---------------------------------------------------------------------------------" +
    "---------------";
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.Label11.Location = new System.Drawing.Point(29, 314);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(391, 13);
            this.Label11.TabIndex = 2;
            this.Label11.Text = "---------------------------------------------------------------------------------" +
    "---------------";
            // 
            // Label14
            // 
            this.Label14.AutoSize = true;
            this.Label14.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.Label14.Location = new System.Drawing.Point(29, 340);
            this.Label14.Name = "Label14";
            this.Label14.Size = new System.Drawing.Size(391, 13);
            this.Label14.TabIndex = 2;
            this.Label14.Text = "---------------------------------------------------------------------------------" +
    "---------------";
            // 
            // Label30
            // 
            this.Label30.AutoSize = true;
            this.Label30.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.Label30.Location = new System.Drawing.Point(317, 417);
            this.Label30.Name = "Label30";
            this.Label30.Size = new System.Drawing.Size(43, 13);
            this.Label30.TabIndex = 2;
            this.Label30.Text = "TOTAL:";
            // 
            // Label28
            // 
            this.Label28.AutoSize = true;
            this.Label28.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.Label28.Location = new System.Drawing.Point(292, 399);
            this.Label28.Name = "Label28";
            this.Label28.Size = new System.Drawing.Size(65, 13);
            this.Label28.TabIndex = 2;
            this.Label28.Text = "Descuento:";
            // 
            // Label25
            // 
            this.Label25.AutoSize = true;
            this.Label25.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.Label25.Location = new System.Drawing.Point(299, 380);
            this.Label25.Name = "Label25";
            this.Label25.Size = new System.Drawing.Size(58, 13);
            this.Label25.TabIndex = 2;
            this.Label25.Text = "Sub Total:";
            // 
            // Label29
            // 
            this.Label29.AutoSize = true;
            this.Label29.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.Label29.Location = new System.Drawing.Point(383, 417);
            this.Label29.Name = "Label29";
            this.Label29.Size = new System.Drawing.Size(35, 13);
            this.Label29.TabIndex = 2;
            this.Label29.Text = "S/. 26";
            // 
            // Label27
            // 
            this.Label27.AutoSize = true;
            this.Label27.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.Label27.Location = new System.Drawing.Point(383, 399);
            this.Label27.Name = "Label27";
            this.Label27.Size = new System.Drawing.Size(44, 13);
            this.Label27.TabIndex = 2;
            this.Label27.Text = "S/. 0.00";
            // 
            // Label35
            // 
            this.Label35.AutoSize = true;
            this.Label35.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.Label35.Location = new System.Drawing.Point(396, 550);
            this.Label35.Name = "Label35";
            this.Label35.Size = new System.Drawing.Size(13, 13);
            this.Label35.TabIndex = 2;
            this.Label35.Text = "1";
            // 
            // Label34
            // 
            this.Label34.AutoSize = true;
            this.Label34.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.Label34.Location = new System.Drawing.Point(29, 550);
            this.Label34.Name = "Label34";
            this.Label34.Size = new System.Drawing.Size(119, 13);
            this.Label34.TabIndex = 2;
            this.Label34.Text = "Numero de Productos";
            // 
            // Label18
            // 
            this.Label18.AutoSize = true;
            this.Label18.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.Label18.Location = new System.Drawing.Point(89, 353);
            this.Label18.Name = "Label18";
            this.Label18.Size = new System.Drawing.Size(133, 13);
            this.Label18.TabIndex = 2;
            this.Label18.Text = "Gaseosa Coca Cola x 1 Lt";
            // 
            // Label26
            // 
            this.Label26.AutoSize = true;
            this.Label26.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.Label26.Location = new System.Drawing.Point(383, 380);
            this.Label26.Name = "Label26";
            this.Label26.Size = new System.Drawing.Size(35, 13);
            this.Label26.TabIndex = 2;
            this.Label26.Text = "S/. 26";
            // 
            // Label21
            // 
            this.Label21.AutoSize = true;
            this.Label21.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.Label21.Location = new System.Drawing.Point(385, 353);
            this.Label21.Name = "Label21";
            this.Label21.Size = new System.Drawing.Size(35, 13);
            this.Label21.TabIndex = 2;
            this.Label21.Text = "S/. 26";
            // 
            // Label15
            // 
            this.Label15.AutoSize = true;
            this.Label15.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.Label15.Location = new System.Drawing.Point(31, 353);
            this.Label15.Name = "Label15";
            this.Label15.Size = new System.Drawing.Size(13, 13);
            this.Label15.TabIndex = 2;
            this.Label15.Text = "1";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.Label3.Location = new System.Drawing.Point(29, 327);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(34, 13);
            this.Label3.TabIndex = 2;
            this.Label3.Text = "Cant.";
            // 
            // lblfecha
            // 
            this.lblfecha.AutoSize = true;
            this.lblfecha.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblfecha.Location = new System.Drawing.Point(30, 275);
            this.lblfecha.Name = "lblfecha";
            this.lblfecha.Size = new System.Drawing.Size(129, 13);
            this.lblfecha.TabIndex = 2;
            this.lblfecha.Text = "Fecha Emision          ";
            // 
            // Label7
            // 
            this.Label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Label7.Location = new System.Drawing.Point(31, 644);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(388, 10);
            this.Label7.TabIndex = 2;
            this.Label7.Text = "*****************************************************************************";
            this.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PictureBox1
            // 
            this.PictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.PictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PictureBox1.BackgroundImage")));
            this.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PictureBox1.Location = new System.Drawing.Point(203, 16);
            this.PictureBox1.Name = "PictureBox1";
            this.PictureBox1.Size = new System.Drawing.Size(62, 52);
            this.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PictureBox1.TabIndex = 608;
            this.PictureBox1.TabStop = false;
            // 
            // PictureBox2
            // 
            this.PictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox2.Image")));
            this.PictureBox2.Location = new System.Drawing.Point(31, 651);
            this.PictureBox2.Name = "PictureBox2";
            this.PictureBox2.Size = new System.Drawing.Size(380, 75);
            this.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PictureBox2.TabIndex = 609;
            this.PictureBox2.TabStop = false;
            // 
            // Panel6
            // 
            this.Panel6.Controls.Add(this.Label12);
            this.Panel6.Controls.Add(this.btnguardar);
            this.Panel6.Controls.Add(this.btnFacturaBoleta);
            this.Panel6.Controls.Add(this.btnTicket);
            this.Panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Panel6.Location = new System.Drawing.Point(460, 0);
            this.Panel6.Name = "Panel6";
            this.Panel6.Size = new System.Drawing.Size(688, 715);
            this.Panel6.TabIndex = 612;
            // 
            // Label12
            // 
            this.Label12.AutoSize = true;
            this.Label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.Label12.Location = new System.Drawing.Point(6, 162);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(284, 40);
            this.Label12.TabIndex = 2;
            this.Label12.Text = "Elige un Formato de Comprobante\r\ncon el que Trabajaras";
            // 
            // btnguardar
            // 
            this.btnguardar.BackColor = System.Drawing.Color.White;
            this.btnguardar.FlatAppearance.BorderSize = 2;
            this.btnguardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnguardar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnguardar.Location = new System.Drawing.Point(5, 276);
            this.btnguardar.Name = "btnguardar";
            this.btnguardar.Size = new System.Drawing.Size(183, 37);
            this.btnguardar.TabIndex = 601;
            this.btnguardar.Text = "Guardar";
            this.btnguardar.UseVisualStyleBackColor = false;
            this.btnguardar.Click += new System.EventHandler(this.btnguardar_Click);
            // 
            // btnFacturaBoleta
            // 
            this.btnFacturaBoleta.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnFacturaBoleta.FlatAppearance.BorderSize = 0;
            this.btnFacturaBoleta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFacturaBoleta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFacturaBoleta.Location = new System.Drawing.Point(194, 214);
            this.btnFacturaBoleta.Name = "btnFacturaBoleta";
            this.btnFacturaBoleta.Size = new System.Drawing.Size(183, 37);
            this.btnFacturaBoleta.TabIndex = 601;
            this.btnFacturaBoleta.Text = "Factura - Boleta";
            this.btnFacturaBoleta.UseVisualStyleBackColor = false;
            this.btnFacturaBoleta.Click += new System.EventHandler(this.btnFacturaBoleta_Click);
            // 
            // btnTicket
            // 
            this.btnTicket.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnTicket.FlatAppearance.BorderSize = 0;
            this.btnTicket.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTicket.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTicket.Location = new System.Drawing.Point(4, 214);
            this.btnTicket.Name = "btnTicket";
            this.btnTicket.Size = new System.Drawing.Size(183, 37);
            this.btnTicket.TabIndex = 601;
            this.btnTicket.Text = "Ticket No Fiscal";
            this.btnTicket.UseVisualStyleBackColor = false;
            this.btnTicket.Click += new System.EventHandler(this.btnTicket_Click);
            // 
            // Diseño
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1148, 715);
            this.Controls.Add(this.Panel6);
            this.Controls.Add(this.PanelTICKET);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Diseño";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Diseño";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Diseño_Load);
            this.PanelTICKET.ResumeLayout(false);
            this.PanelTICKET.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox2)).EndInit();
            this.Panel6.ResumeLayout(false);
            this.Panel6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Panel PanelTICKET;
        internal System.Windows.Forms.PictureBox PictureBox3;
        internal System.Windows.Forms.Panel Panel16;
        internal System.Windows.Forms.Panel Panel15;
        internal System.Windows.Forms.Panel Panel14;
        internal System.Windows.Forms.Panel Panel13;
        internal System.Windows.Forms.Label lblcliente;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.Panel Panel4;
        internal System.Windows.Forms.Panel Panel3;
        internal System.Windows.Forms.Label Label19;
        internal System.Windows.Forms.Label Label37;
        internal System.Windows.Forms.Label Label31;
        internal System.Windows.Forms.Label Label16;
        internal System.Windows.Forms.Label Label10;
        internal System.Windows.Forms.Label Label32;
        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.Panel Panel5;
        internal System.Windows.Forms.TextBox txtMoneda_String;
        internal System.Windows.Forms.TextBox txtpagina_o_facebook;
        internal System.Windows.Forms.TextBox TextBox1;
        internal System.Windows.Forms.TextBox txtAutorizacion_fiscal;
        internal System.Windows.Forms.TextBox TXTANUNCIO;
        internal System.Windows.Forms.TextBox txtAgradecimiento;
        internal System.Windows.Forms.TextBox txtProvincia_departamento;
        internal System.Windows.Forms.TextBox txtDireccion;
        internal System.Windows.Forms.TextBox txtEmpresa_RUC;
        internal System.Windows.Forms.TextBox txtempresaTICKET;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Label Label13;
        internal System.Windows.Forms.Label Label17;
        internal System.Windows.Forms.Label lblcajero;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.Label Label36;
        internal System.Windows.Forms.Label Label33;
        internal System.Windows.Forms.Label Label24;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label11;
        internal System.Windows.Forms.Label Label14;
        internal System.Windows.Forms.Label Label30;
        internal System.Windows.Forms.Label Label28;
        internal System.Windows.Forms.Label Label25;
        internal System.Windows.Forms.Label Label29;
        internal System.Windows.Forms.Label Label27;
        internal System.Windows.Forms.Label Label35;
        internal System.Windows.Forms.Label Label34;
        internal System.Windows.Forms.Label Label18;
        internal System.Windows.Forms.Label Label26;
        internal System.Windows.Forms.Label Label21;
        internal System.Windows.Forms.Label Label15;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label lblfecha;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.PictureBox PictureBox1;
        internal System.Windows.Forms.PictureBox PictureBox2;
        internal System.Windows.Forms.Panel Panel6;
        internal System.Windows.Forms.Label Label12;
        internal System.Windows.Forms.Button btnguardar;
        internal System.Windows.Forms.Button btnFacturaBoleta;
        internal System.Windows.Forms.Button btnTicket;
    }
}