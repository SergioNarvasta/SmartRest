﻿
namespace RestCsharp.Presentacion.Serializacion
{
    partial class SerialziacionComp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SerialziacionComp));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.TXTCANTIDADDECEROS = new System.Windows.Forms.TextBox();
            this.PictureBox4 = new System.Windows.Forms.PictureBox();
            this.Label17 = new System.Windows.Forms.Label();
            this.TabPage6 = new System.Windows.Forms.TabPage();
            this.Label4 = new System.Windows.Forms.Label();
            this.TabPage5 = new System.Windows.Forms.TabPage();
            this.checkDefecto = new System.Windows.Forms.CheckBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.TXTCOMPRO = new System.Windows.Forms.TextBox();
            this.btnvolver = new System.Windows.Forms.Button();
            this.TabControl3 = new System.Windows.Forms.TabControl();
            this.VOLVEROK = new System.Windows.Forms.ToolStripMenuItem();
            this.txtnumerofin = new System.Windows.Forms.TextBox();
            this.txtSerie = new System.Windows.Forms.TextBox();
            this.MenuStrip5 = new System.Windows.Forms.MenuStrip();
            this.GUARDARCAMBIOS = new System.Windows.Forms.ToolStripMenuItem();
            this.txtmsbox = new System.Windows.Forms.Label();
            this.PictureBox3 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.checkenvioinmediato = new System.Windows.Forms.CheckBox();
            this.datalistado = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox4)).BeginInit();
            this.TabPage6.SuspendLayout();
            this.TabPage5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.TabControl3.SuspendLayout();
            this.MenuStrip5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox3)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datalistado)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // TXTCANTIDADDECEROS
            // 
            this.TXTCANTIDADDECEROS.BackColor = System.Drawing.Color.White;
            this.TXTCANTIDADDECEROS.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TXTCANTIDADDECEROS.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.TXTCANTIDADDECEROS.ForeColor = System.Drawing.Color.Black;
            this.TXTCANTIDADDECEROS.Location = new System.Drawing.Point(549, 83);
            this.TXTCANTIDADDECEROS.Name = "TXTCANTIDADDECEROS";
            this.TXTCANTIDADDECEROS.Size = new System.Drawing.Size(170, 35);
            this.TXTCANTIDADDECEROS.TabIndex = 618;
            this.TXTCANTIDADDECEROS.Text = "0";
            this.TXTCANTIDADDECEROS.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // PictureBox4
            // 
            this.PictureBox4.BackColor = System.Drawing.Color.White;
            this.PictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.PictureBox4.Location = new System.Drawing.Point(92, 6);
            this.PictureBox4.Name = "PictureBox4";
            this.PictureBox4.Size = new System.Drawing.Size(79, 57);
            this.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox4.TabIndex = 346;
            this.PictureBox4.TabStop = false;
            // 
            // Label17
            // 
            this.Label17.AutoSize = true;
            this.Label17.ForeColor = System.Drawing.Color.Black;
            this.Label17.Location = new System.Drawing.Point(7, 25);
            this.Label17.Name = "Label17";
            this.Label17.Size = new System.Drawing.Size(74, 13);
            this.Label17.TabIndex = 340;
            this.Label17.Text = "Ficha tecnica:";
            // 
            // TabPage6
            // 
            this.TabPage6.Controls.Add(this.PictureBox4);
            this.TabPage6.Controls.Add(this.Label17);
            this.TabPage6.Location = new System.Drawing.Point(4, 22);
            this.TabPage6.Name = "TabPage6";
            this.TabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage6.Size = new System.Drawing.Size(388, 69);
            this.TabPage6.TabIndex = 1;
            this.TabPage6.Text = "Ficha tecnica";
            this.TabPage6.UseVisualStyleBackColor = true;
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.ForeColor = System.Drawing.Color.Black;
            this.Label4.Location = new System.Drawing.Point(12, 31);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(144, 13);
            this.Label4.TabIndex = 341;
            this.Label4.Text = "Registro sanitario de Ingreso:";
            // 
            // TabPage5
            // 
            this.TabPage5.Controls.Add(this.Label4);
            this.TabPage5.Location = new System.Drawing.Point(4, 22);
            this.TabPage5.Name = "TabPage5";
            this.TabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage5.Size = new System.Drawing.Size(388, 69);
            this.TabPage5.TabIndex = 0;
            this.TabPage5.Text = "Registro sanitario de Ingreso";
            this.TabPage5.UseVisualStyleBackColor = true;
            // 
            // checkDefecto
            // 
            this.checkDefecto.AutoSize = true;
            this.checkDefecto.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkDefecto.Location = new System.Drawing.Point(537, 276);
            this.checkDefecto.Name = "checkDefecto";
            this.checkDefecto.Size = new System.Drawing.Size(219, 28);
            this.checkDefecto.TabIndex = 621;
            this.checkDefecto.Text = "Elejir Por DEFECTO";
            this.checkDefecto.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel4.Controls.Add(this.TXTCOMPRO);
            this.panel4.Location = new System.Drawing.Point(259, 112);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(209, 36);
            this.panel4.TabIndex = 620;
            // 
            // TXTCOMPRO
            // 
            this.TXTCOMPRO.BackColor = System.Drawing.SystemColors.HotTrack;
            this.TXTCOMPRO.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TXTCOMPRO.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.TXTCOMPRO.ForeColor = System.Drawing.Color.White;
            this.TXTCOMPRO.Location = new System.Drawing.Point(-1, 10);
            this.TXTCOMPRO.Name = "TXTCOMPRO";
            this.TXTCOMPRO.Size = new System.Drawing.Size(210, 16);
            this.TXTCOMPRO.TabIndex = 615;
            this.TXTCOMPRO.Text = "FACTURA";
            this.TXTCOMPRO.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnvolver
            // 
            this.btnvolver.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnvolver.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnvolver.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnvolver.ForeColor = System.Drawing.Color.White;
            this.btnvolver.Location = new System.Drawing.Point(52, 602);
            this.btnvolver.Name = "btnvolver";
            this.btnvolver.Size = new System.Drawing.Size(309, 39);
            this.btnvolver.TabIndex = 562;
            this.btnvolver.Text = "Volver {}";
            this.btnvolver.UseVisualStyleBackColor = false;
            // 
            // TabControl3
            // 
            this.TabControl3.Controls.Add(this.TabPage5);
            this.TabControl3.Controls.Add(this.TabPage6);
            this.TabControl3.Location = new System.Drawing.Point(132, 773);
            this.TabControl3.Name = "TabControl3";
            this.TabControl3.SelectedIndex = 0;
            this.TabControl3.Size = new System.Drawing.Size(396, 95);
            this.TabControl3.TabIndex = 350;
            // 
            // VOLVEROK
            // 
            this.VOLVEROK.BackColor = System.Drawing.Color.Gray;
            this.VOLVEROK.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.VOLVEROK.ForeColor = System.Drawing.Color.White;
            this.VOLVEROK.Name = "VOLVEROK";
            this.VOLVEROK.Size = new System.Drawing.Size(82, 47);
            this.VOLVEROK.Text = "VOLVER";
            this.VOLVEROK.Click += new System.EventHandler(this.VOLVEROK_Click);
            // 
            // txtnumerofin
            // 
            this.txtnumerofin.BackColor = System.Drawing.Color.White;
            this.txtnumerofin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtnumerofin.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.txtnumerofin.ForeColor = System.Drawing.Color.Black;
            this.txtnumerofin.Location = new System.Drawing.Point(537, 149);
            this.txtnumerofin.Name = "txtnumerofin";
            this.txtnumerofin.Size = new System.Drawing.Size(182, 35);
            this.txtnumerofin.TabIndex = 616;
            this.txtnumerofin.Text = "0";
            this.txtnumerofin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtSerie
            // 
            this.txtSerie.BackColor = System.Drawing.Color.White;
            this.txtSerie.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSerie.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtSerie.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.txtSerie.ForeColor = System.Drawing.Color.Black;
            this.txtSerie.Location = new System.Drawing.Point(537, 220);
            this.txtSerie.Name = "txtSerie";
            this.txtSerie.Size = new System.Drawing.Size(182, 35);
            this.txtSerie.TabIndex = 618;
            this.txtSerie.Text = "0";
            this.txtSerie.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // MenuStrip5
            // 
            this.MenuStrip5.AutoSize = false;
            this.MenuStrip5.BackColor = System.Drawing.Color.Transparent;
            this.MenuStrip5.Dock = System.Windows.Forms.DockStyle.None;
            this.MenuStrip5.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.GUARDARCAMBIOS,
            this.VOLVEROK});
            this.MenuStrip5.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.MenuStrip5.Location = new System.Drawing.Point(537, 367);
            this.MenuStrip5.Name = "MenuStrip5";
            this.MenuStrip5.ShowItemToolTips = true;
            this.MenuStrip5.Size = new System.Drawing.Size(411, 51);
            this.MenuStrip5.TabIndex = 532;
            this.MenuStrip5.Text = "MenuStrip5";
            // 
            // GUARDARCAMBIOS
            // 
            this.GUARDARCAMBIOS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(204)))), ((int)(((byte)(0)))));
            this.GUARDARCAMBIOS.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.GUARDARCAMBIOS.ForeColor = System.Drawing.Color.Black;
            this.GUARDARCAMBIOS.Name = "GUARDARCAMBIOS";
            this.GUARDARCAMBIOS.Size = new System.Drawing.Size(153, 47);
            this.GUARDARCAMBIOS.Text = "&Guardar Cambios";
            this.GUARDARCAMBIOS.Click += new System.EventHandler(this.GUARDARCAMBIOS_Click);
            // 
            // txtmsbox
            // 
            this.txtmsbox.BackColor = System.Drawing.Color.Transparent;
            this.txtmsbox.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmsbox.ForeColor = System.Drawing.Color.White;
            this.txtmsbox.Location = new System.Drawing.Point(51, 522);
            this.txtmsbox.Name = "txtmsbox";
            this.txtmsbox.Size = new System.Drawing.Size(332, 24);
            this.txtmsbox.TabIndex = 381;
            this.txtmsbox.Text = "Listo";
            this.txtmsbox.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // PictureBox3
            // 
            this.PictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox3.Image")));
            this.PictureBox3.Location = new System.Drawing.Point(-228, -37);
            this.PictureBox3.Name = "PictureBox3";
            this.PictureBox3.Size = new System.Drawing.Size(1361, 721);
            this.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox3.TabIndex = 619;
            this.PictureBox3.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.checkenvioinmediato);
            this.panel3.Controls.Add(this.checkDefecto);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.txtnumerofin);
            this.panel3.Controls.Add(this.txtSerie);
            this.panel3.Controls.Add(this.TXTCANTIDADDECEROS);
            this.panel3.Controls.Add(this.MenuStrip5);
            this.panel3.Controls.Add(this.btnvolver);
            this.panel3.Controls.Add(this.TabControl3);
            this.panel3.Controls.Add(this.txtmsbox);
            this.panel3.Controls.Add(this.PictureBox3);
            this.panel3.Location = new System.Drawing.Point(5, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(970, 712);
            this.panel3.TabIndex = 372;
            this.panel3.Visible = false;
            // 
            // checkenvioinmediato
            // 
            this.checkenvioinmediato.AutoSize = true;
            this.checkenvioinmediato.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkenvioinmediato.Location = new System.Drawing.Point(537, 319);
            this.checkenvioinmediato.Name = "checkenvioinmediato";
            this.checkenvioinmediato.Size = new System.Drawing.Size(215, 28);
            this.checkenvioinmediato.TabIndex = 623;
            this.checkenvioinmediato.Text = "Enviar de inmediato";
            this.checkenvioinmediato.UseVisualStyleBackColor = true;
            // 
            // datalistado
            // 
            this.datalistado.AllowUserToAddRows = false;
            this.datalistado.AllowUserToDeleteRows = false;
            this.datalistado.AllowUserToOrderColumns = true;
            this.datalistado.AllowUserToResizeRows = false;
            this.datalistado.BackgroundColor = System.Drawing.Color.White;
            this.datalistado.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.datalistado.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.datalistado.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datalistado.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.datalistado.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datalistado.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1});
            this.datalistado.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.datalistado.DefaultCellStyle = dataGridViewCellStyle2;
            this.datalistado.Dock = System.Windows.Forms.DockStyle.Fill;
            this.datalistado.EnableHeadersVisualStyles = false;
            this.datalistado.GridColor = System.Drawing.Color.LightGray;
            this.datalistado.Location = new System.Drawing.Point(0, 62);
            this.datalistado.Name = "datalistado";
            this.datalistado.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datalistado.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.datalistado.RowHeadersVisible = false;
            this.datalistado.RowHeadersWidth = 5;
            this.datalistado.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datalistado.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.datalistado.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.LightGray;
            this.datalistado.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.datalistado.RowTemplate.Height = 60;
            this.datalistado.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datalistado.Size = new System.Drawing.Size(795, 462);
            this.datalistado.TabIndex = 371;
            this.datalistado.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datalistado_CellClick);
            this.datalistado.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datalistado_CellDoubleClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Column1";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Visible = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(795, 62);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(126, 462);
            this.panel2.TabIndex = 370;
            // 
            // Label3
            // 
            this.Label3.BackColor = System.Drawing.Color.White;
            this.Label3.Dock = System.Windows.Forms.DockStyle.Top;
            this.Label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold);
            this.Label3.ForeColor = System.Drawing.Color.Black;
            this.Label3.Location = new System.Drawing.Point(0, 0);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(921, 59);
            this.Label3.TabIndex = 547;
            this.Label3.Text = "SERIALIZACION DE COMPROBANTES";
            this.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Label3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(921, 62);
            this.panel1.TabIndex = 369;
            // 
            // SerialziacionComp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(921, 524);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.datalistado);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SerialziacionComp";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Serialziacion Comprobantes";
            this.Load += new System.EventHandler(this.SerialziacionComp_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox4)).EndInit();
            this.TabPage6.ResumeLayout(false);
            this.TabPage6.PerformLayout();
            this.TabPage5.ResumeLayout(false);
            this.TabPage5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.TabControl3.ResumeLayout(false);
            this.MenuStrip5.ResumeLayout(false);
            this.MenuStrip5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox3)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datalistado)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.TextBox TXTCANTIDADDECEROS;
        internal System.Windows.Forms.PictureBox PictureBox4;
        internal System.Windows.Forms.Label Label17;
        internal System.Windows.Forms.TabPage TabPage6;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.TabPage TabPage5;
        internal System.Windows.Forms.CheckBox checkDefecto;
        internal System.Windows.Forms.Panel panel4;
        internal System.Windows.Forms.TextBox TXTCOMPRO;
        internal System.Windows.Forms.Button btnvolver;
        internal System.Windows.Forms.TabControl TabControl3;
        internal System.Windows.Forms.ToolStripMenuItem VOLVEROK;
        internal System.Windows.Forms.TextBox txtnumerofin;
        internal System.Windows.Forms.TextBox txtSerie;
        internal System.Windows.Forms.MenuStrip MenuStrip5;
        internal System.Windows.Forms.ToolStripMenuItem GUARDARCAMBIOS;
        internal System.Windows.Forms.Label txtmsbox;
        internal System.Windows.Forms.PictureBox PictureBox3;
        internal System.Windows.Forms.Panel panel3;
        internal System.Windows.Forms.DataGridView datalistado;
        private System.Windows.Forms.Panel panel2;
        internal System.Windows.Forms.Label Label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        internal System.Windows.Forms.CheckBox checkenvioinmediato;
    }
}