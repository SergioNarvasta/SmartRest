﻿namespace RestCsharp.Presentacion.AsistenteInstalacion
{
    partial class UsuarioPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UsuarioPrincipal));
            this.Panel2 = new System.Windows.Forms.Panel();
            this.btnSiguiente = new System.Windows.Forms.Button();
            this.LBLcontador_de_contraseña2 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.LBLcontador_de_contraseña = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.Icono = new System.Windows.Forms.PictureBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.txtconfirmarcontraseña = new System.Windows.Forms.TextBox();
            this.TXTCONTRASEÑA = new System.Windows.Forms.TextBox();
            this.TXTUSUARIO = new System.Windows.Forms.TextBox();
            this.txtnombre = new System.Windows.Forms.TextBox();
            this.Label6 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.datalistado_empresas_nuevas = new System.Windows.Forms.DataGridView();
            this.DataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.DATALISTADOUSUARIOSSNUEVOS = new System.Windows.Forms.DataGridView();
            this.DataGridViewCheckBoxColumn3 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Icono)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.datalistado_empresas_nuevas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DATALISTADOUSUARIOSSNUEVOS)).BeginInit();
            this.SuspendLayout();
            // 
            // Panel2
            // 
            this.Panel2.BackColor = System.Drawing.Color.White;
            this.Panel2.Controls.Add(this.btnSiguiente);
            this.Panel2.Controls.Add(this.LBLcontador_de_contraseña2);
            this.Panel2.Controls.Add(this.Label7);
            this.Panel2.Controls.Add(this.LBLcontador_de_contraseña);
            this.Panel2.Controls.Add(this.Label5);
            this.Panel2.Controls.Add(this.Label4);
            this.Panel2.Controls.Add(this.Icono);
            this.Panel2.Controls.Add(this.Label3);
            this.Panel2.Controls.Add(this.Label2);
            this.Panel2.Controls.Add(this.txtconfirmarcontraseña);
            this.Panel2.Controls.Add(this.TXTCONTRASEÑA);
            this.Panel2.Controls.Add(this.TXTUSUARIO);
            this.Panel2.Controls.Add(this.txtnombre);
            this.Panel2.Controls.Add(this.Label6);
            this.Panel2.Controls.Add(this.Label1);
            this.Panel2.Controls.Add(this.datalistado_empresas_nuevas);
            this.Panel2.Controls.Add(this.DATALISTADOUSUARIOSSNUEVOS);
            this.Panel2.Location = new System.Drawing.Point(79, 14);
            this.Panel2.Name = "Panel2";
            this.Panel2.Size = new System.Drawing.Size(666, 454);
            this.Panel2.TabIndex = 609;
            // 
            // btnSiguiente
            // 
            this.btnSiguiente.BackgroundImage = global::RestCsharp.Properties.Resources.naranja;
            this.btnSiguiente.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSiguiente.FlatAppearance.BorderSize = 0;
            this.btnSiguiente.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnSiguiente.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnSiguiente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSiguiente.Font = new System.Drawing.Font("Calibri", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSiguiente.ForeColor = System.Drawing.Color.White;
            this.btnSiguiente.Location = new System.Drawing.Point(546, 404);
            this.btnSiguiente.Name = "btnSiguiente";
            this.btnSiguiente.Size = new System.Drawing.Size(106, 38);
            this.btnSiguiente.TabIndex = 597;
            this.btnSiguiente.Text = "Siguiente";
            this.btnSiguiente.UseVisualStyleBackColor = true;
            this.btnSiguiente.Click += new System.EventHandler(this.btnSiguiente_Click);
            // 
            // LBLcontador_de_contraseña2
            // 
            this.LBLcontador_de_contraseña2.AutoSize = true;
            this.LBLcontador_de_contraseña2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.LBLcontador_de_contraseña2.ForeColor = System.Drawing.Color.DimGray;
            this.LBLcontador_de_contraseña2.Location = new System.Drawing.Point(370, 150);
            this.LBLcontador_de_contraseña2.Name = "LBLcontador_de_contraseña2";
            this.LBLcontador_de_contraseña2.Size = new System.Drawing.Size(13, 13);
            this.LBLcontador_de_contraseña2.TabIndex = 596;
            this.LBLcontador_de_contraseña2.Text = "6";
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.BackColor = System.Drawing.Color.White;
            this.Label7.ForeColor = System.Drawing.Color.DimGray;
            this.Label7.Location = new System.Drawing.Point(389, 119);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(123, 13);
            this.Label7.TabIndex = 596;
            this.Label7.Text = "Ingresa hasta 6 numeros";
            // 
            // LBLcontador_de_contraseña
            // 
            this.LBLcontador_de_contraseña.AutoSize = true;
            this.LBLcontador_de_contraseña.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.LBLcontador_de_contraseña.ForeColor = System.Drawing.Color.DimGray;
            this.LBLcontador_de_contraseña.Location = new System.Drawing.Point(370, 121);
            this.LBLcontador_de_contraseña.Name = "LBLcontador_de_contraseña";
            this.LBLcontador_de_contraseña.Size = new System.Drawing.Size(13, 13);
            this.LBLcontador_de_contraseña.TabIndex = 596;
            this.LBLcontador_de_contraseña.Text = "6";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.BackColor = System.Drawing.Color.White;
            this.Label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.Label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Label5.Location = new System.Drawing.Point(11, 143);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(187, 20);
            this.Label5.TabIndex = 2;
            this.Label5.Text = "Confirmar contraseña:";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.BackColor = System.Drawing.Color.White;
            this.Label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.Label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Label4.Location = new System.Drawing.Point(91, 114);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(107, 20);
            this.Label4.TabIndex = 2;
            this.Label4.Text = "Contraseña:";
            // 
            // Icono
            // 
            this.Icono.BackColor = System.Drawing.Color.White;
            this.Icono.Image = global::RestCsharp.Properties.Resources.Buman;
            this.Icono.Location = new System.Drawing.Point(165, 214);
            this.Icono.Name = "Icono";
            this.Icono.Size = new System.Drawing.Size(340, 194);
            this.Icono.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Icono.TabIndex = 589;
            this.Icono.TabStop = false;
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.BackColor = System.Drawing.Color.White;
            this.Label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.Label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Label3.Location = new System.Drawing.Point(121, 88);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(76, 20);
            this.Label3.TabIndex = 2;
            this.Label3.Text = "Usuario:";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.BackColor = System.Drawing.Color.White;
            this.Label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.Label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Label2.Location = new System.Drawing.Point(26, 53);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(172, 20);
            this.Label2.TabIndex = 2;
            this.Label2.Text = "Nombre del Usuario:";
            // 
            // txtconfirmarcontraseña
            // 
            this.txtconfirmarcontraseña.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtconfirmarcontraseña.Location = new System.Drawing.Point(203, 143);
            this.txtconfirmarcontraseña.MaxLength = 6;
            this.txtconfirmarcontraseña.Name = "txtconfirmarcontraseña";
            this.txtconfirmarcontraseña.PasswordChar = '*';
            this.txtconfirmarcontraseña.Size = new System.Drawing.Size(160, 23);
            this.txtconfirmarcontraseña.TabIndex = 3;
            // 
            // TXTCONTRASEÑA
            // 
            this.TXTCONTRASEÑA.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.TXTCONTRASEÑA.Location = new System.Drawing.Point(203, 114);
            this.TXTCONTRASEÑA.MaxLength = 6;
            this.TXTCONTRASEÑA.Name = "TXTCONTRASEÑA";
            this.TXTCONTRASEÑA.PasswordChar = '*';
            this.TXTCONTRASEÑA.Size = new System.Drawing.Size(160, 23);
            this.TXTCONTRASEÑA.TabIndex = 3;
            // 
            // TXTUSUARIO
            // 
            this.TXTUSUARIO.Enabled = false;
            this.TXTUSUARIO.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.TXTUSUARIO.Location = new System.Drawing.Point(203, 85);
            this.TXTUSUARIO.Name = "TXTUSUARIO";
            this.TXTUSUARIO.Size = new System.Drawing.Size(206, 23);
            this.TXTUSUARIO.TabIndex = 3;
            this.TXTUSUARIO.Text = "admin";
            // 
            // txtnombre
            // 
            this.txtnombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtnombre.Location = new System.Drawing.Point(203, 53);
            this.txtnombre.Name = "txtnombre";
            this.txtnombre.Size = new System.Drawing.Size(231, 23);
            this.txtnombre.TabIndex = 3;
            // 
            // Label6
            // 
            this.Label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.Label6.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.Label6.Location = new System.Drawing.Point(42, 182);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(590, 29);
            this.Label6.TabIndex = 2;
            this.Label6.Text = "El Administrador siempre tendra Acceso a todas las Funciones del Programa";
            this.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.Label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Label1.Location = new System.Drawing.Point(5, 7);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(349, 20);
            this.Label1.TabIndex = 2;
            this.Label1.Text = "¿Que usuario principal usara el Programa?";
            // 
            // datalistado_empresas_nuevas
            // 
            this.datalistado_empresas_nuevas.AllowUserToAddRows = false;
            this.datalistado_empresas_nuevas.AllowUserToDeleteRows = false;
            this.datalistado_empresas_nuevas.BackgroundColor = System.Drawing.Color.White;
            this.datalistado_empresas_nuevas.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.datalistado_empresas_nuevas.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datalistado_empresas_nuevas.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.datalistado_empresas_nuevas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datalistado_empresas_nuevas.ColumnHeadersVisible = false;
            this.datalistado_empresas_nuevas.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DataGridViewCheckBoxColumn1});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.datalistado_empresas_nuevas.DefaultCellStyle = dataGridViewCellStyle2;
            this.datalistado_empresas_nuevas.EnableHeadersVisualStyles = false;
            this.datalistado_empresas_nuevas.Location = new System.Drawing.Point(297, 230);
            this.datalistado_empresas_nuevas.Name = "datalistado_empresas_nuevas";
            this.datalistado_empresas_nuevas.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datalistado_empresas_nuevas.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.datalistado_empresas_nuevas.RowHeadersWidth = 5;
            this.datalistado_empresas_nuevas.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.datalistado_empresas_nuevas.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.datalistado_empresas_nuevas.RowTemplate.Height = 40;
            this.datalistado_empresas_nuevas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datalistado_empresas_nuevas.Size = new System.Drawing.Size(109, 79);
            this.datalistado_empresas_nuevas.TabIndex = 594;
            // 
            // DataGridViewCheckBoxColumn1
            // 
            this.DataGridViewCheckBoxColumn1.HeaderText = "Eliminar";
            this.DataGridViewCheckBoxColumn1.Name = "DataGridViewCheckBoxColumn1";
            this.DataGridViewCheckBoxColumn1.ReadOnly = true;
            this.DataGridViewCheckBoxColumn1.Visible = false;
            // 
            // DATALISTADOUSUARIOSSNUEVOS
            // 
            this.DATALISTADOUSUARIOSSNUEVOS.AllowUserToAddRows = false;
            this.DATALISTADOUSUARIOSSNUEVOS.AllowUserToDeleteRows = false;
            this.DATALISTADOUSUARIOSSNUEVOS.AllowUserToResizeRows = false;
            this.DATALISTADOUSUARIOSSNUEVOS.BackgroundColor = System.Drawing.Color.White;
            this.DATALISTADOUSUARIOSSNUEVOS.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DATALISTADOUSUARIOSSNUEVOS.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.DATALISTADOUSUARIOSSNUEVOS.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DATALISTADOUSUARIOSSNUEVOS.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DataGridViewCheckBoxColumn3});
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DATALISTADOUSUARIOSSNUEVOS.DefaultCellStyle = dataGridViewCellStyle5;
            this.DATALISTADOUSUARIOSSNUEVOS.Location = new System.Drawing.Point(275, 267);
            this.DATALISTADOUSUARIOSSNUEVOS.Name = "DATALISTADOUSUARIOSSNUEVOS";
            this.DATALISTADOUSUARIOSSNUEVOS.ReadOnly = true;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DATALISTADOUSUARIOSSNUEVOS.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.DATALISTADOUSUARIOSSNUEVOS.RowHeadersVisible = false;
            this.DATALISTADOUSUARIOSSNUEVOS.RowHeadersWidth = 5;
            this.DATALISTADOUSUARIOSSNUEVOS.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.ForestGreen;
            this.DATALISTADOUSUARIOSSNUEVOS.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DATALISTADOUSUARIOSSNUEVOS.Size = new System.Drawing.Size(88, 75);
            this.DATALISTADOUSUARIOSSNUEVOS.TabIndex = 595;
            // 
            // DataGridViewCheckBoxColumn3
            // 
            this.DataGridViewCheckBoxColumn3.DataPropertyName = "Activo";
            this.DataGridViewCheckBoxColumn3.HeaderText = "Activo";
            this.DataGridViewCheckBoxColumn3.Name = "DataGridViewCheckBoxColumn3";
            this.DataGridViewCheckBoxColumn3.ReadOnly = true;
            // 
            // UsuarioPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(839, 510);
            this.Controls.Add(this.Panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "UsuarioPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Usuario Principal";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.UsuarioPrincipal_Load);
            this.Panel2.ResumeLayout(false);
            this.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Icono)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.datalistado_empresas_nuevas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DATALISTADOUSUARIOSSNUEVOS)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Panel Panel2;
        private System.Windows.Forms.Button btnSiguiente;
        internal System.Windows.Forms.Label LBLcontador_de_contraseña2;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Label LBLcontador_de_contraseña;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.PictureBox Icono;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.TextBox txtconfirmarcontraseña;
        internal System.Windows.Forms.TextBox TXTCONTRASEÑA;
        internal System.Windows.Forms.TextBox TXTUSUARIO;
        internal System.Windows.Forms.TextBox txtnombre;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.DataGridView datalistado_empresas_nuevas;
        internal System.Windows.Forms.DataGridViewCheckBoxColumn DataGridViewCheckBoxColumn1;
        public System.Windows.Forms.DataGridView DATALISTADOUSUARIOSSNUEVOS;
        internal System.Windows.Forms.DataGridViewCheckBoxColumn DataGridViewCheckBoxColumn3;
    }
}