﻿
namespace RestCsharp.Presentacion.AsistenteInstalacion
{
    partial class Empresaregistro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Empresaregistro));
            this.PanelEmpresa = new System.Windows.Forms.Panel();
            this.btnsiguiente = new System.Windows.Forms.Button();
            this.Panel2 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chPorpedido = new System.Windows.Forms.RadioButton();
            this.chGeneral = new System.Windows.Forms.RadioButton();
            this.txtRuta = new System.Windows.Forms.TextBox();
            this.Label9 = new System.Windows.Forms.Label();
            this.ToolStrip1 = new System.Windows.Forms.ToolStrip();
            this.ToolStripButton22 = new System.Windows.Forms.ToolStripButton();
            this.Panel13 = new System.Windows.Forms.Panel();
            this.panelImpuestos = new System.Windows.Forms.Panel();
            this.Panel12 = new System.Windows.Forms.Panel();
            this.txtimpuesto = new System.Windows.Forms.ComboBox();
            this.Label14 = new System.Windows.Forms.Label();
            this.txtporcentaje = new System.Windows.Forms.ComboBox();
            this.Label16 = new System.Windows.Forms.Label();
            this.no = new System.Windows.Forms.RadioButton();
            this.si = new System.Windows.Forms.RadioButton();
            this.Panel6 = new System.Windows.Forms.Panel();
            this.txtmoneda = new System.Windows.Forms.ComboBox();
            this.txtpais = new System.Windows.Forms.ComboBox();
            this.lbleditarLogo = new System.Windows.Forms.Label();
            this.ImagenEmpresa = new System.Windows.Forms.PictureBox();
            this.Panel5 = new System.Windows.Forms.Panel();
            this.txtrazonsocial = new System.Windows.Forms.TextBox();
            this.lblempresa = new System.Windows.Forms.Label();
            this.Label8 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.TabControl3 = new System.Windows.Forms.TabControl();
            this.TabPage5 = new System.Windows.Forms.TabPage();
            this.Label4 = new System.Windows.Forms.Label();
            this.TabPage6 = new System.Windows.Forms.TabPage();
            this.PictureBox4 = new System.Windows.Forms.PictureBox();
            this.Label17 = new System.Windows.Forms.Label();
            this.dlg = new System.Windows.Forms.OpenFileDialog();
            this.Fbd = new System.Windows.Forms.FolderBrowserDialog();
            this.PanelEmpresa.SuspendLayout();
            this.Panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.ToolStrip1.SuspendLayout();
            this.Panel13.SuspendLayout();
            this.panelImpuestos.SuspendLayout();
            this.Panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ImagenEmpresa)).BeginInit();
            this.TabControl3.SuspendLayout();
            this.TabPage5.SuspendLayout();
            this.TabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // PanelEmpresa
            // 
            this.PanelEmpresa.BackColor = System.Drawing.Color.White;
            this.PanelEmpresa.Controls.Add(this.btnsiguiente);
            this.PanelEmpresa.Controls.Add(this.Panel2);
            this.PanelEmpresa.Location = new System.Drawing.Point(73, 28);
            this.PanelEmpresa.Name = "PanelEmpresa";
            this.PanelEmpresa.Size = new System.Drawing.Size(644, 584);
            this.PanelEmpresa.TabIndex = 611;
            // 
            // btnsiguiente
            // 
            this.btnsiguiente.BackColor = System.Drawing.Color.Transparent;
            this.btnsiguiente.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.btnsiguiente.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnsiguiente.FlatAppearance.BorderSize = 0;
            this.btnsiguiente.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnsiguiente.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnsiguiente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsiguiente.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsiguiente.ForeColor = System.Drawing.Color.White;
            this.btnsiguiente.Location = new System.Drawing.Point(506, 512);
            this.btnsiguiente.Name = "btnsiguiente";
            this.btnsiguiente.Size = new System.Drawing.Size(125, 58);
            this.btnsiguiente.TabIndex = 594;
            this.btnsiguiente.Text = "Siguiente";
            this.btnsiguiente.UseVisualStyleBackColor = false;
            this.btnsiguiente.Click += new System.EventHandler(this.btnsiguiente_Click);
            // 
            // Panel2
            // 
            this.Panel2.BackColor = System.Drawing.Color.White;
            this.Panel2.Controls.Add(this.groupBox1);
            this.Panel2.Controls.Add(this.txtRuta);
            this.Panel2.Controls.Add(this.Label9);
            this.Panel2.Controls.Add(this.ToolStrip1);
            this.Panel2.Controls.Add(this.Panel13);
            this.Panel2.Controls.Add(this.Panel6);
            this.Panel2.Controls.Add(this.TabControl3);
            this.Panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel2.Location = new System.Drawing.Point(0, 0);
            this.Panel2.Name = "Panel2";
            this.Panel2.Size = new System.Drawing.Size(644, 492);
            this.Panel2.TabIndex = 360;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chPorpedido);
            this.groupBox1.Controls.Add(this.chGeneral);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox1.Location = new System.Drawing.Point(37, 331);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(563, 94);
            this.groupBox1.TabIndex = 600;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Notas en pedidos";
            // 
            // chPorpedido
            // 
            this.chPorpedido.AutoSize = true;
            this.chPorpedido.Location = new System.Drawing.Point(194, 39);
            this.chPorpedido.Name = "chPorpedido";
            this.chPorpedido.Size = new System.Drawing.Size(179, 28);
            this.chPorpedido.TabIndex = 344;
            this.chPorpedido.TabStop = true;
            this.chPorpedido.Text = "Nota por pedido";
            this.chPorpedido.UseVisualStyleBackColor = true;
            this.chPorpedido.CheckedChanged += new System.EventHandler(this.chPorpedido_CheckedChanged);
            // 
            // chGeneral
            // 
            this.chGeneral.AutoSize = true;
            this.chGeneral.Checked = true;
            this.chGeneral.Location = new System.Drawing.Point(25, 39);
            this.chGeneral.Name = "chGeneral";
            this.chGeneral.Size = new System.Drawing.Size(148, 28);
            this.chGeneral.TabIndex = 344;
            this.chGeneral.TabStop = true;
            this.chGeneral.Text = "Nota general";
            this.chGeneral.UseVisualStyleBackColor = true;
            this.chGeneral.CheckedChanged += new System.EventHandler(this.chGeneral_CheckedChanged);
            // 
            // txtRuta
            // 
            this.txtRuta.BackColor = System.Drawing.Color.White;
            this.txtRuta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtRuta.Enabled = false;
            this.txtRuta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtRuta.Location = new System.Drawing.Point(71, 299);
            this.txtRuta.Name = "txtRuta";
            this.txtRuta.Size = new System.Drawing.Size(506, 26);
            this.txtRuta.TabIndex = 597;
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.BackColor = System.Drawing.Color.White;
            this.Label9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.Label9.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Label9.Location = new System.Drawing.Point(67, 278);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(533, 20);
            this.Label9.TabIndex = 596;
            this.Label9.Text = "Seleccione una Carpeta donde Guardar Las Copias de Seguridad\r\n";
            this.Label9.Click += new System.EventHandler(this.Label9_Click);
            // 
            // ToolStrip1
            // 
            this.ToolStrip1.AutoSize = false;
            this.ToolStrip1.BackColor = System.Drawing.Color.White;
            this.ToolStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.ToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripButton22});
            this.ToolStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.ToolStrip1.Location = new System.Drawing.Point(24, 265);
            this.ToolStrip1.Name = "ToolStrip1";
            this.ToolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.ToolStrip1.Size = new System.Drawing.Size(72, 49);
            this.ToolStrip1.TabIndex = 598;
            this.ToolStrip1.Text = "ToolStrip1";
            // 
            // ToolStripButton22
            // 
            this.ToolStripButton22.BackColor = System.Drawing.Color.White;
            this.ToolStripButton22.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ToolStripButton22.ForeColor = System.Drawing.Color.Black;
            this.ToolStripButton22.Image = ((System.Drawing.Image)(resources.GetObject("ToolStripButton22.Image")));
            this.ToolStripButton22.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ToolStripButton22.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ToolStripButton22.Name = "ToolStripButton22";
            this.ToolStripButton22.Size = new System.Drawing.Size(37, 46);
            this.ToolStripButton22.Text = "+";
            this.ToolStripButton22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ToolStripButton22.ToolTipText = "Buscar Ruta";
            this.ToolStripButton22.Click += new System.EventHandler(this.ToolStripButton22_Click);
            // 
            // Panel13
            // 
            this.Panel13.BackColor = System.Drawing.Color.White;
            this.Panel13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Panel13.Controls.Add(this.panelImpuestos);
            this.Panel13.Controls.Add(this.Label16);
            this.Panel13.Controls.Add(this.no);
            this.Panel13.Controls.Add(this.si);
            this.Panel13.Location = new System.Drawing.Point(37, 154);
            this.Panel13.Name = "Panel13";
            this.Panel13.Size = new System.Drawing.Size(563, 99);
            this.Panel13.TabIndex = 590;
            // 
            // panelImpuestos
            // 
            this.panelImpuestos.Controls.Add(this.Panel12);
            this.panelImpuestos.Controls.Add(this.txtimpuesto);
            this.panelImpuestos.Controls.Add(this.Label14);
            this.panelImpuestos.Controls.Add(this.txtporcentaje);
            this.panelImpuestos.Location = new System.Drawing.Point(41, 39);
            this.panelImpuestos.Name = "panelImpuestos";
            this.panelImpuestos.Size = new System.Drawing.Size(233, 41);
            this.panelImpuestos.TabIndex = 564;
            this.panelImpuestos.Visible = false;
            // 
            // Panel12
            // 
            this.Panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(204)))), ((int)(((byte)(1)))));
            this.Panel12.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.Panel12.Location = new System.Drawing.Point(0, 37);
            this.Panel12.Name = "Panel12";
            this.Panel12.Size = new System.Drawing.Size(233, 4);
            this.Panel12.TabIndex = 555;
            // 
            // txtimpuesto
            // 
            this.txtimpuesto.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.txtimpuesto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.txtimpuesto.FormattingEnabled = true;
            this.txtimpuesto.Items.AddRange(new object[] {
            "IGV ",
            "IVA"});
            this.txtimpuesto.Location = new System.Drawing.Point(3, 3);
            this.txtimpuesto.Name = "txtimpuesto";
            this.txtimpuesto.Size = new System.Drawing.Size(64, 28);
            this.txtimpuesto.TabIndex = 553;
            this.txtimpuesto.Text = "IGV";
            // 
            // Label14
            // 
            this.Label14.AutoSize = true;
            this.Label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Label14.ForeColor = System.Drawing.Color.Black;
            this.Label14.Location = new System.Drawing.Point(158, 6);
            this.Label14.Name = "Label14";
            this.Label14.Size = new System.Drawing.Size(23, 20);
            this.Label14.TabIndex = 342;
            this.Label14.Text = "%";
            // 
            // txtporcentaje
            // 
            this.txtporcentaje.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.txtporcentaje.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.txtporcentaje.FormattingEnabled = true;
            this.txtporcentaje.Items.AddRange(new object[] {
            "21",
            "18",
            "3",
            "5"});
            this.txtporcentaje.Location = new System.Drawing.Point(88, 3);
            this.txtporcentaje.Name = "txtporcentaje";
            this.txtporcentaje.Size = new System.Drawing.Size(64, 28);
            this.txtporcentaje.TabIndex = 553;
            this.txtporcentaje.Text = "18";
            // 
            // Label16
            // 
            this.Label16.AutoSize = true;
            this.Label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.Label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Label16.Location = new System.Drawing.Point(31, 10);
            this.Label16.Name = "Label16";
            this.Label16.Size = new System.Drawing.Size(210, 20);
            this.Label16.TabIndex = 342;
            this.Label16.Text = "¿Vender con Impuestos?";
            // 
            // no
            // 
            this.no.AutoSize = true;
            this.no.Checked = true;
            this.no.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold);
            this.no.Location = new System.Drawing.Point(320, 5);
            this.no.Name = "no";
            this.no.Size = new System.Drawing.Size(59, 28);
            this.no.TabIndex = 555;
            this.no.TabStop = true;
            this.no.Text = "NO";
            this.no.UseVisualStyleBackColor = true;
            this.no.CheckedChanged += new System.EventHandler(this.no_CheckedChanged);
            // 
            // si
            // 
            this.si.AutoSize = true;
            this.si.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold);
            this.si.Location = new System.Drawing.Point(268, 5);
            this.si.Name = "si";
            this.si.Size = new System.Drawing.Size(46, 28);
            this.si.TabIndex = 555;
            this.si.Text = "SI";
            this.si.UseVisualStyleBackColor = true;
            this.si.CheckedChanged += new System.EventHandler(this.si_CheckedChanged);
            // 
            // Panel6
            // 
            this.Panel6.BackColor = System.Drawing.Color.White;
            this.Panel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Panel6.Controls.Add(this.txtmoneda);
            this.Panel6.Controls.Add(this.txtpais);
            this.Panel6.Controls.Add(this.lbleditarLogo);
            this.Panel6.Controls.Add(this.ImagenEmpresa);
            this.Panel6.Controls.Add(this.Panel5);
            this.Panel6.Controls.Add(this.txtrazonsocial);
            this.Panel6.Controls.Add(this.lblempresa);
            this.Panel6.Controls.Add(this.Label8);
            this.Panel6.Controls.Add(this.Label7);
            this.Panel6.Location = new System.Drawing.Point(37, 9);
            this.Panel6.Name = "Panel6";
            this.Panel6.Size = new System.Drawing.Size(564, 137);
            this.Panel6.TabIndex = 589;
            // 
            // txtmoneda
            // 
            this.txtmoneda.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtmoneda.DropDownWidth = 230;
            this.txtmoneda.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.txtmoneda.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.txtmoneda.FormattingEnabled = true;
            this.txtmoneda.IntegralHeight = false;
            this.txtmoneda.Items.AddRange(new object[] {
            "$",
            "₡",
            "Q",
            "L",
            "C$",
            "B/.",
            "$",
            "$",
            "$",
            "$",
            "Bs.",
            "$",
            "$",
            "$",
            "₲",
            "S/.",
            "$",
            "Bs F",
            "€"});
            this.txtmoneda.Location = new System.Drawing.Point(444, 70);
            this.txtmoneda.Name = "txtmoneda";
            this.txtmoneda.Size = new System.Drawing.Size(83, 28);
            this.txtmoneda.TabIndex = 590;
            // 
            // txtpais
            // 
            this.txtpais.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtpais.DropDownWidth = 230;
            this.txtpais.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.txtpais.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.txtpais.FormattingEnabled = true;
            this.txtpais.IntegralHeight = false;
            this.txtpais.Items.AddRange(new object[] {
            "México",
            "Costa Rica",
            "Guatemala",
            "Honduras",
            "Nicaragua",
            "Panamá",
            "Cuba",
            "Puerto Rico",
            "República Dominicana",
            "Argentina",
            "Bolivia",
            "Chile",
            "Colombia",
            "Ecuador",
            "Paraguay",
            "Perú",
            "Uruguay",
            "Venezuela",
            "España"});
            this.txtpais.Location = new System.Drawing.Point(194, 70);
            this.txtpais.Name = "txtpais";
            this.txtpais.Size = new System.Drawing.Size(163, 28);
            this.txtpais.TabIndex = 589;
            this.txtpais.SelectedIndexChanged += new System.EventHandler(this.txtpais_SelectedIndexChanged);
            // 
            // lbleditarLogo
            // 
            this.lbleditarLogo.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbleditarLogo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbleditarLogo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.lbleditarLogo.ForeColor = System.Drawing.Color.White;
            this.lbleditarLogo.Location = new System.Drawing.Point(25, 106);
            this.lbleditarLogo.Name = "lbleditarLogo";
            this.lbleditarLogo.Size = new System.Drawing.Size(107, 22);
            this.lbleditarLogo.TabIndex = 588;
            this.lbleditarLogo.Text = "Cambiar";
            this.lbleditarLogo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbleditarLogo.Click += new System.EventHandler(this.lbleditarLogo_Click);
            // 
            // ImagenEmpresa
            // 
            this.ImagenEmpresa.Image = ((System.Drawing.Image)(resources.GetObject("ImagenEmpresa.Image")));
            this.ImagenEmpresa.Location = new System.Drawing.Point(25, 20);
            this.ImagenEmpresa.Name = "ImagenEmpresa";
            this.ImagenEmpresa.Size = new System.Drawing.Size(107, 108);
            this.ImagenEmpresa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ImagenEmpresa.TabIndex = 533;
            this.ImagenEmpresa.TabStop = false;
            // 
            // Panel5
            // 
            this.Panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(204)))), ((int)(((byte)(1)))));
            this.Panel5.Location = new System.Drawing.Point(140, 45);
            this.Panel5.Name = "Panel5";
            this.Panel5.Size = new System.Drawing.Size(400, 2);
            this.Panel5.TabIndex = 554;
            // 
            // txtrazonsocial
            // 
            this.txtrazonsocial.BackColor = System.Drawing.Color.White;
            this.txtrazonsocial.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtrazonsocial.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtrazonsocial.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtrazonsocial.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.txtrazonsocial.ForeColor = System.Drawing.Color.Black;
            this.txtrazonsocial.Location = new System.Drawing.Point(140, 22);
            this.txtrazonsocial.Name = "txtrazonsocial";
            this.txtrazonsocial.Size = new System.Drawing.Size(360, 22);
            this.txtrazonsocial.TabIndex = 532;
            this.txtrazonsocial.Text = "NOMBRE DE TU EMPRESA";
            // 
            // lblempresa
            // 
            this.lblempresa.AutoSize = true;
            this.lblempresa.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.lblempresa.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblempresa.Location = new System.Drawing.Point(137, 4);
            this.lblempresa.Name = "lblempresa";
            this.lblempresa.Size = new System.Drawing.Size(155, 15);
            this.lblempresa.TabIndex = 342;
            this.lblempresa.Text = "Nombre de tu Empresa";
            this.lblempresa.Visible = false;
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.Label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Label8.Location = new System.Drawing.Point(363, 73);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(78, 20);
            this.Label8.TabIndex = 342;
            this.Label8.Text = "moneda:";
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.Label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Label7.Location = new System.Drawing.Point(140, 73);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(48, 20);
            this.Label7.TabIndex = 342;
            this.Label7.Text = "Pais:";
            // 
            // TabControl3
            // 
            this.TabControl3.Controls.Add(this.TabPage5);
            this.TabControl3.Controls.Add(this.TabPage6);
            this.TabControl3.Location = new System.Drawing.Point(132, 773);
            this.TabControl3.Name = "TabControl3";
            this.TabControl3.SelectedIndex = 0;
            this.TabControl3.Size = new System.Drawing.Size(396, 95);
            this.TabControl3.TabIndex = 350;
            // 
            // TabPage5
            // 
            this.TabPage5.Controls.Add(this.Label4);
            this.TabPage5.Location = new System.Drawing.Point(4, 22);
            this.TabPage5.Name = "TabPage5";
            this.TabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage5.Size = new System.Drawing.Size(388, 69);
            this.TabPage5.TabIndex = 0;
            this.TabPage5.Text = "Registro sanitario de Ingreso";
            this.TabPage5.UseVisualStyleBackColor = true;
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.ForeColor = System.Drawing.Color.Black;
            this.Label4.Location = new System.Drawing.Point(12, 31);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(144, 13);
            this.Label4.TabIndex = 341;
            this.Label4.Text = "Registro sanitario de Ingreso:";
            // 
            // TabPage6
            // 
            this.TabPage6.Controls.Add(this.PictureBox4);
            this.TabPage6.Controls.Add(this.Label17);
            this.TabPage6.Location = new System.Drawing.Point(4, 22);
            this.TabPage6.Name = "TabPage6";
            this.TabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage6.Size = new System.Drawing.Size(388, 69);
            this.TabPage6.TabIndex = 1;
            this.TabPage6.Text = "Ficha tecnica";
            this.TabPage6.UseVisualStyleBackColor = true;
            // 
            // PictureBox4
            // 
            this.PictureBox4.BackColor = System.Drawing.Color.White;
            this.PictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.PictureBox4.Location = new System.Drawing.Point(92, 6);
            this.PictureBox4.Name = "PictureBox4";
            this.PictureBox4.Size = new System.Drawing.Size(79, 57);
            this.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox4.TabIndex = 346;
            this.PictureBox4.TabStop = false;
            // 
            // Label17
            // 
            this.Label17.AutoSize = true;
            this.Label17.ForeColor = System.Drawing.Color.Black;
            this.Label17.Location = new System.Drawing.Point(7, 25);
            this.Label17.Name = "Label17";
            this.Label17.Size = new System.Drawing.Size(74, 13);
            this.Label17.TabIndex = 340;
            this.Label17.Text = "Ficha tecnica:";
            // 
            // dlg
            // 
            this.dlg.FileName = "openFileDialog1";
            // 
            // Empresaregistro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(791, 638);
            this.Controls.Add(this.PanelEmpresa);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Empresaregistro";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Empresa registro";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Empresaregistro_Load);
            this.PanelEmpresa.ResumeLayout(false);
            this.Panel2.ResumeLayout(false);
            this.Panel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ToolStrip1.ResumeLayout(false);
            this.ToolStrip1.PerformLayout();
            this.Panel13.ResumeLayout(false);
            this.Panel13.PerformLayout();
            this.panelImpuestos.ResumeLayout(false);
            this.panelImpuestos.PerformLayout();
            this.Panel6.ResumeLayout(false);
            this.Panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ImagenEmpresa)).EndInit();
            this.TabControl3.ResumeLayout(false);
            this.TabPage5.ResumeLayout(false);
            this.TabPage5.PerformLayout();
            this.TabPage6.ResumeLayout(false);
            this.TabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Panel PanelEmpresa;
        private System.Windows.Forms.Button btnsiguiente;
        internal System.Windows.Forms.Panel Panel2;
        internal System.Windows.Forms.TextBox txtRuta;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.ToolStrip ToolStrip1;
        internal System.Windows.Forms.ToolStripButton ToolStripButton22;
        internal System.Windows.Forms.Panel Panel13;
        internal System.Windows.Forms.Panel panelImpuestos;
        internal System.Windows.Forms.Panel Panel12;
        internal System.Windows.Forms.ComboBox txtimpuesto;
        internal System.Windows.Forms.Label Label14;
        internal System.Windows.Forms.ComboBox txtporcentaje;
        internal System.Windows.Forms.Label Label16;
        internal System.Windows.Forms.RadioButton no;
        internal System.Windows.Forms.RadioButton si;
        internal System.Windows.Forms.Panel Panel6;
        internal System.Windows.Forms.ComboBox txtmoneda;
        internal System.Windows.Forms.ComboBox txtpais;
        internal System.Windows.Forms.Label lbleditarLogo;
        internal System.Windows.Forms.PictureBox ImagenEmpresa;
        internal System.Windows.Forms.Panel Panel5;
        internal System.Windows.Forms.TextBox txtrazonsocial;
        internal System.Windows.Forms.Label lblempresa;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.TabControl TabControl3;
        internal System.Windows.Forms.TabPage TabPage5;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.TabPage TabPage6;
        internal System.Windows.Forms.PictureBox PictureBox4;
        internal System.Windows.Forms.Label Label17;
        private System.Windows.Forms.OpenFileDialog dlg;
        private System.Windows.Forms.FolderBrowserDialog Fbd;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton chPorpedido;
        private System.Windows.Forms.RadioButton chGeneral;
    }
}