﻿
namespace RestCsharp.Presentacion.AsistenteInstalacion
{
    partial class InstalarServidor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InstalarServidor));
            this.Panel8 = new System.Windows.Forms.Panel();
            this.PictureBox7 = new System.Windows.Forms.PictureBox();
            this.lblwindows = new System.Windows.Forms.Label();
            this.PanelDios = new System.Windows.Forms.Panel();
            this.GroupBox6 = new System.Windows.Forms.GroupBox();
            this.seg3 = new System.Windows.Forms.Label();
            this.mil3 = new System.Windows.Forms.Label();
            this.txtCrearUsuarioDb = new System.Windows.Forms.TextBox();
            this.GroupBox5 = new System.Windows.Forms.GroupBox();
            this.btnInstalarServi = new System.Windows.Forms.Button();
            this.btnTransmision = new System.Windows.Forms.Button();
            this.btnvolver = new System.Windows.Forms.Button();
            this.GroupBox4 = new System.Windows.Forms.GroupBox();
            this.txtusuario = new System.Windows.Forms.TextBox();
            this.Label15 = new System.Windows.Forms.Label();
            this.Label14 = new System.Windows.Forms.Label();
            this.Label13 = new System.Windows.Forms.Label();
            this.Label12 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtsoftware = new System.Windows.Forms.TextBox();
            this.Label8 = new System.Windows.Forms.Label();
            this.Label6 = new System.Windows.Forms.Label();
            this.lblBasededatos = new System.Windows.Forms.Label();
            this.Label9 = new System.Windows.Forms.Label();
            this.txtnombre_scrypt = new System.Windows.Forms.TextBox();
            this.Label11 = new System.Windows.Forms.Label();
            this.TXTbasededatos = new System.Windows.Forms.TextBox();
            this.lblnombredeservicio = new System.Windows.Forms.TextBox();
            this.lblcontraseña = new System.Windows.Forms.TextBox();
            this.GroupBox3 = new System.Windows.Forms.GroupBox();
            this.txtArgumentosini = new System.Windows.Forms.RichTextBox();
            this.Panel10 = new System.Windows.Forms.Panel();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.txtEliminarBase = new System.Windows.Forms.RichTextBox();
            this.lblRutaInstancia = new System.Windows.Forms.Label();
            this.min2 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.seg2 = new System.Windows.Forms.Label();
            this.milise = new System.Windows.Forms.Label();
            this.mils2 = new System.Windows.Forms.Label();
            this.txtservidor = new System.Windows.Forms.Label();
            this.GroupBox2 = new System.Windows.Forms.GroupBox();
            this.txtCrear_procedimientos = new System.Windows.Forms.RichTextBox();
            this.datalistado = new System.Windows.Forms.DataGridView();
            this.Eliminar = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Panel2 = new System.Windows.Forms.Panel();
            this.Panel4 = new System.Windows.Forms.Panel();
            this.PictureBox2 = new System.Windows.Forms.PictureBox();
            this.Panel6 = new System.Windows.Forms.Panel();
            this.Panel7 = new System.Windows.Forms.Panel();
            this.Label5 = new System.Windows.Forms.Label();
            this.min = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.seg = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.PictureBox1 = new System.Windows.Forms.PictureBox();
            this.Panel5 = new System.Windows.Forms.Panel();
            this.Panel9 = new System.Windows.Forms.Panel();
            this.lblbuscador_de_servidores = new System.Windows.Forms.Label();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.btnInstalarServidor = new System.Windows.Forms.Button();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.timer4 = new System.Windows.Forms.Timer(this.components);
            this.TimerCRARINI = new System.Windows.Forms.Timer(this.components);
            this.btnModoProgramador = new System.Windows.Forms.Button();
            this.Panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox7)).BeginInit();
            this.PanelDios.SuspendLayout();
            this.GroupBox6.SuspendLayout();
            this.GroupBox5.SuspendLayout();
            this.GroupBox4.SuspendLayout();
            this.GroupBox3.SuspendLayout();
            this.Panel10.SuspendLayout();
            this.GroupBox1.SuspendLayout();
            this.GroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datalistado)).BeginInit();
            this.Panel2.SuspendLayout();
            this.Panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox2)).BeginInit();
            this.Panel6.SuspendLayout();
            this.Panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).BeginInit();
            this.Panel9.SuspendLayout();
            this.SuspendLayout();
            // 
            // Panel8
            // 
            this.Panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
            this.Panel8.Controls.Add(this.PictureBox7);
            this.Panel8.Controls.Add(this.lblwindows);
            this.Panel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel8.Location = new System.Drawing.Point(0, 0);
            this.Panel8.Name = "Panel8";
            this.Panel8.Size = new System.Drawing.Size(1623, 86);
            this.Panel8.TabIndex = 592;
            // 
            // PictureBox7
            // 
            this.PictureBox7.Image = global::RestCsharp.Properties.Resources.Buman;
            this.PictureBox7.Location = new System.Drawing.Point(12, 12);
            this.PictureBox7.Name = "PictureBox7";
            this.PictureBox7.Size = new System.Drawing.Size(110, 63);
            this.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PictureBox7.TabIndex = 604;
            this.PictureBox7.TabStop = false;
            // 
            // lblwindows
            // 
            this.lblwindows.BackColor = System.Drawing.Color.Transparent;
            this.lblwindows.Dock = System.Windows.Forms.DockStyle.Right;
            this.lblwindows.ForeColor = System.Drawing.Color.White;
            this.lblwindows.Location = new System.Drawing.Point(1104, 0);
            this.lblwindows.Name = "lblwindows";
            this.lblwindows.Size = new System.Drawing.Size(519, 86);
            this.lblwindows.TabIndex = 607;
            this.lblwindows.Text = "...";
            this.lblwindows.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // PanelDios
            // 
            this.PanelDios.AutoScroll = true;
            this.PanelDios.Controls.Add(this.GroupBox6);
            this.PanelDios.Controls.Add(this.GroupBox5);
            this.PanelDios.Controls.Add(this.btnTransmision);
            this.PanelDios.Controls.Add(this.btnvolver);
            this.PanelDios.Controls.Add(this.GroupBox4);
            this.PanelDios.Controls.Add(this.GroupBox3);
            this.PanelDios.Controls.Add(this.Panel10);
            this.PanelDios.Controls.Add(this.GroupBox2);
            this.PanelDios.Controls.Add(this.datalistado);
            this.PanelDios.Location = new System.Drawing.Point(583, 166);
            this.PanelDios.Name = "PanelDios";
            this.PanelDios.Size = new System.Drawing.Size(1050, 698);
            this.PanelDios.TabIndex = 621;
            // 
            // GroupBox6
            // 
            this.GroupBox6.Controls.Add(this.seg3);
            this.GroupBox6.Controls.Add(this.mil3);
            this.GroupBox6.Controls.Add(this.txtCrearUsuarioDb);
            this.GroupBox6.ForeColor = System.Drawing.Color.White;
            this.GroupBox6.Location = new System.Drawing.Point(856, 229);
            this.GroupBox6.Name = "GroupBox6";
            this.GroupBox6.Size = new System.Drawing.Size(165, 285);
            this.GroupBox6.TabIndex = 630;
            this.GroupBox6.TabStop = false;
            this.GroupBox6.Text = "Servira para Crear un Usuario para el Servidor - NO TOCAR";
            // 
            // seg3
            // 
            this.seg3.AutoSize = true;
            this.seg3.ForeColor = System.Drawing.Color.White;
            this.seg3.Location = new System.Drawing.Point(127, 256);
            this.seg3.Name = "seg3";
            this.seg3.Size = new System.Drawing.Size(13, 13);
            this.seg3.TabIndex = 631;
            this.seg3.Text = "0";
            // 
            // mil3
            // 
            this.mil3.AutoSize = true;
            this.mil3.ForeColor = System.Drawing.Color.White;
            this.mil3.Location = new System.Drawing.Point(146, 256);
            this.mil3.Name = "mil3";
            this.mil3.Size = new System.Drawing.Size(13, 13);
            this.mil3.TabIndex = 630;
            this.mil3.Text = "0";
            // 
            // txtCrearUsuarioDb
            // 
            this.txtCrearUsuarioDb.Location = new System.Drawing.Point(6, 37);
            this.txtCrearUsuarioDb.Multiline = true;
            this.txtCrearUsuarioDb.Name = "txtCrearUsuarioDb";
            this.txtCrearUsuarioDb.Size = new System.Drawing.Size(162, 192);
            this.txtCrearUsuarioDb.TabIndex = 629;
            this.txtCrearUsuarioDb.Text = resources.GetString("txtCrearUsuarioDb.Text");
            // 
            // GroupBox5
            // 
            this.GroupBox5.Controls.Add(this.btnInstalarServi);
            this.GroupBox5.ForeColor = System.Drawing.Color.Yellow;
            this.GroupBox5.Location = new System.Drawing.Point(289, 218);
            this.GroupBox5.Name = "GroupBox5";
            this.GroupBox5.Size = new System.Drawing.Size(561, 91);
            this.GroupBox5.TabIndex = 628;
            this.GroupBox5.TabStop = false;
            this.GroupBox5.Text = "NO TENGO SQL SERVER INSTALADO";
            // 
            // btnInstalarServi
            // 
            this.btnInstalarServi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
            this.btnInstalarServi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInstalarServi.FlatAppearance.BorderSize = 0;
            this.btnInstalarServi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInstalarServi.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold);
            this.btnInstalarServi.ForeColor = System.Drawing.Color.White;
            this.btnInstalarServi.Location = new System.Drawing.Point(7, 19);
            this.btnInstalarServi.Name = "btnInstalarServi";
            this.btnInstalarServi.Size = new System.Drawing.Size(548, 66);
            this.btnInstalarServi.TabIndex = 611;
            this.btnInstalarServi.Text = "Instalar Servidor";
            this.btnInstalarServi.UseVisualStyleBackColor = false;
            this.btnInstalarServi.Click += new System.EventHandler(this.btnInstalarServi_Click);
            // 
            // btnTransmision
            // 
            this.btnTransmision.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
            this.btnTransmision.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTransmision.FlatAppearance.BorderSize = 0;
            this.btnTransmision.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTransmision.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.btnTransmision.ForeColor = System.Drawing.Color.White;
            this.btnTransmision.Location = new System.Drawing.Point(8, 12);
            this.btnTransmision.Name = "btnTransmision";
            this.btnTransmision.Size = new System.Drawing.Size(276, 56);
            this.btnTransmision.TabIndex = 627;
            this.btnTransmision.Text = "Iniciar Transmision";
            this.btnTransmision.UseVisualStyleBackColor = false;
            this.btnTransmision.Click += new System.EventHandler(this.btnTransmision_Click);
            // 
            // btnvolver
            // 
            this.btnvolver.BackColor = System.Drawing.Color.Transparent;
            this.btnvolver.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnvolver.FlatAppearance.BorderSize = 0;
            this.btnvolver.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnvolver.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.btnvolver.ForeColor = System.Drawing.Color.White;
            this.btnvolver.Location = new System.Drawing.Point(8, 74);
            this.btnvolver.Name = "btnvolver";
            this.btnvolver.Size = new System.Drawing.Size(276, 56);
            this.btnvolver.TabIndex = 626;
            this.btnvolver.Text = "Volver a modo Normal";
            this.btnvolver.UseVisualStyleBackColor = false;
            this.btnvolver.Click += new System.EventHandler(this.btnvolver_Click);
            // 
            // GroupBox4
            // 
            this.GroupBox4.Controls.Add(this.txtusuario);
            this.GroupBox4.Controls.Add(this.Label15);
            this.GroupBox4.Controls.Add(this.Label14);
            this.GroupBox4.Controls.Add(this.Label13);
            this.GroupBox4.Controls.Add(this.Label12);
            this.GroupBox4.Controls.Add(this.label3);
            this.GroupBox4.Controls.Add(this.txtsoftware);
            this.GroupBox4.Controls.Add(this.Label8);
            this.GroupBox4.Controls.Add(this.Label6);
            this.GroupBox4.Controls.Add(this.lblBasededatos);
            this.GroupBox4.Controls.Add(this.Label9);
            this.GroupBox4.Controls.Add(this.txtnombre_scrypt);
            this.GroupBox4.Controls.Add(this.Label11);
            this.GroupBox4.Controls.Add(this.TXTbasededatos);
            this.GroupBox4.Controls.Add(this.lblnombredeservicio);
            this.GroupBox4.Controls.Add(this.lblcontraseña);
            this.GroupBox4.ForeColor = System.Drawing.Color.Aqua;
            this.GroupBox4.Location = new System.Drawing.Point(290, 22);
            this.GroupBox4.Name = "GroupBox4";
            this.GroupBox4.Size = new System.Drawing.Size(729, 188);
            this.GroupBox4.TabIndex = 625;
            this.GroupBox4.TabStop = false;
            this.GroupBox4.Text = "YA TENGO SQL SERVER INSTALADO";
            // 
            // txtusuario
            // 
            this.txtusuario.Location = new System.Drawing.Point(184, 83);
            this.txtusuario.MaxLength = 15;
            this.txtusuario.Name = "txtusuario";
            this.txtusuario.Size = new System.Drawing.Size(122, 20);
            this.txtusuario.TabIndex = 626;
            this.txtusuario.Text = "buman";
            // 
            // Label15
            // 
            this.Label15.AutoSize = true;
            this.Label15.ForeColor = System.Drawing.Color.White;
            this.Label15.Location = new System.Drawing.Point(132, 86);
            this.Label15.Name = "Label15";
            this.Label15.Size = new System.Drawing.Size(46, 13);
            this.Label15.TabIndex = 625;
            this.Label15.Text = "Usuario:";
            // 
            // Label14
            // 
            this.Label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label14.Location = new System.Drawing.Point(321, 135);
            this.Label14.Name = "Label14";
            this.Label14.Size = new System.Drawing.Size(233, 19);
            this.Label14.TabIndex = 623;
            this.Label14.Text = "Se creara una base de datos con este Nombre";
            this.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label13
            // 
            this.Label13.ForeColor = System.Drawing.Color.Aqua;
            this.Label13.Location = new System.Drawing.Point(324, 52);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(233, 33);
            this.Label13.TabIndex = 623;
            this.Label13.Text = "Si ya tienes SQLServer Instalado y NO es Express entonces deja en Blanco este Tex" +
    "box";
            // 
            // Label12
            // 
            this.Label12.AutoSize = true;
            this.Label12.ForeColor = System.Drawing.Color.Yellow;
            this.Label12.Location = new System.Drawing.Point(7, 16);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(412, 13);
            this.Label12.TabIndex = 623;
            this.Label12.Text = "Usa _ en lugar de espacios y no uses Caracteres especiales solo usa letras y nume" +
    "ros";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(31, 41);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(154, 13);
            this.label3.TabIndex = 623;
            this.label3.Text = "NOMBRE DE TU SOFTWARE";
            // 
            // txtsoftware
            // 
            this.txtsoftware.Location = new System.Drawing.Point(185, 32);
            this.txtsoftware.MaxLength = 15;
            this.txtsoftware.Name = "txtsoftware";
            this.txtsoftware.Size = new System.Drawing.Size(134, 20);
            this.txtsoftware.TabIndex = 624;
            this.txtsoftware.Text = "buman";
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.ForeColor = System.Drawing.Color.White;
            this.Label8.Location = new System.Drawing.Point(64, 61);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(108, 13);
            this.Label8.TabIndex = 618;
            this.Label8.Text = "Nombre de Instancia:";
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.ForeColor = System.Drawing.Color.White;
            this.Label6.Location = new System.Drawing.Point(83, 112);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(88, 13);
            this.Label6.TabIndex = 618;
            this.Label6.Text = "Contraseña SQL:";
            // 
            // lblBasededatos
            // 
            this.lblBasededatos.AutoSize = true;
            this.lblBasededatos.ForeColor = System.Drawing.Color.White;
            this.lblBasededatos.Location = new System.Drawing.Point(92, 141);
            this.lblBasededatos.Name = "lblBasededatos";
            this.lblBasededatos.Size = new System.Drawing.Size(78, 13);
            this.lblBasededatos.TabIndex = 618;
            this.lblBasededatos.Text = "Base de datos:";
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.ForeColor = System.Drawing.Color.White;
            this.Label9.Location = new System.Drawing.Point(77, 168);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(95, 13);
            this.Label9.TabIndex = 618;
            this.Label9.Text = "Nombre de Scrypt:";
            // 
            // txtnombre_scrypt
            // 
            this.txtnombre_scrypt.Location = new System.Drawing.Point(185, 161);
            this.txtnombre_scrypt.Name = "txtnombre_scrypt";
            this.txtnombre_scrypt.Size = new System.Drawing.Size(79, 20);
            this.txtnombre_scrypt.TabIndex = 621;
            this.txtnombre_scrypt.Text = "Scriptbuman";
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.ForeColor = System.Drawing.Color.White;
            this.Label11.Location = new System.Drawing.Point(270, 164);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(27, 13);
            this.Label11.TabIndex = 618;
            this.Label11.Text = ".text";
            // 
            // TXTbasededatos
            // 
            this.TXTbasededatos.Location = new System.Drawing.Point(184, 135);
            this.TXTbasededatos.Name = "TXTbasededatos";
            this.TXTbasededatos.Size = new System.Drawing.Size(134, 20);
            this.TXTbasededatos.TabIndex = 621;
            this.TXTbasededatos.Text = "BASEBRIRESTCSHARP";
            // 
            // lblnombredeservicio
            // 
            this.lblnombredeservicio.Location = new System.Drawing.Point(184, 57);
            this.lblnombredeservicio.MaxLength = 15;
            this.lblnombredeservicio.Name = "lblnombredeservicio";
            this.lblnombredeservicio.Size = new System.Drawing.Size(134, 20);
            this.lblnombredeservicio.TabIndex = 621;
            this.lblnombredeservicio.Text = "SQLEXPRESS";
            // 
            // lblcontraseña
            // 
            this.lblcontraseña.Location = new System.Drawing.Point(185, 109);
            this.lblcontraseña.Name = "lblcontraseña";
            this.lblcontraseña.Size = new System.Drawing.Size(134, 20);
            this.lblcontraseña.TabIndex = 621;
            this.lblcontraseña.Text = "softwarereal";
            // 
            // GroupBox3
            // 
            this.GroupBox3.Controls.Add(this.txtArgumentosini);
            this.GroupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox3.ForeColor = System.Drawing.Color.White;
            this.GroupBox3.Location = new System.Drawing.Point(289, 507);
            this.GroupBox3.Name = "GroupBox3";
            this.GroupBox3.Size = new System.Drawing.Size(561, 183);
            this.GroupBox3.TabIndex = 623;
            this.GroupBox3.TabStop = false;
            this.GroupBox3.Text = "Datos para Instalar SQLServer Express NO TOCAR";
            // 
            // txtArgumentosini
            // 
            this.txtArgumentosini.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtArgumentosini.Location = new System.Drawing.Point(6, 19);
            this.txtArgumentosini.Name = "txtArgumentosini";
            this.txtArgumentosini.Size = new System.Drawing.Size(549, 216);
            this.txtArgumentosini.TabIndex = 589;
            this.txtArgumentosini.Text = resources.GetString("txtArgumentosini.Text");
            // 
            // Panel10
            // 
            this.Panel10.Controls.Add(this.GroupBox1);
            this.Panel10.Controls.Add(this.min2);
            this.Panel10.Controls.Add(this.Label7);
            this.Panel10.Controls.Add(this.seg2);
            this.Panel10.Controls.Add(this.milise);
            this.Panel10.Controls.Add(this.mils2);
            this.Panel10.Controls.Add(this.txtservidor);
            this.Panel10.Location = new System.Drawing.Point(289, 701);
            this.Panel10.Name = "Panel10";
            this.Panel10.Size = new System.Drawing.Size(531, 135);
            this.Panel10.TabIndex = 608;
            // 
            // GroupBox1
            // 
            this.GroupBox1.Controls.Add(this.txtEliminarBase);
            this.GroupBox1.Controls.Add(this.lblRutaInstancia);
            this.GroupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox1.ForeColor = System.Drawing.Color.White;
            this.GroupBox1.Location = new System.Drawing.Point(5, 20);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(515, 109);
            this.GroupBox1.TabIndex = 608;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "Script para Eliminar la base de datos NO TOCAR";
            // 
            // txtEliminarBase
            // 
            this.txtEliminarBase.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEliminarBase.Location = new System.Drawing.Point(8, 25);
            this.txtEliminarBase.Name = "txtEliminarBase";
            this.txtEliminarBase.Size = new System.Drawing.Size(487, 77);
            this.txtEliminarBase.TabIndex = 589;
            this.txtEliminarBase.Text = "alter database BASEADA set single_user with rollback immediate \nDROP DATABASE BAS" +
    "EADA";
            // 
            // lblRutaInstancia
            // 
            this.lblRutaInstancia.AutoSize = true;
            this.lblRutaInstancia.BackColor = System.Drawing.Color.White;
            this.lblRutaInstancia.Location = new System.Drawing.Point(32, 44);
            this.lblRutaInstancia.Name = "lblRutaInstancia";
            this.lblRutaInstancia.Size = new System.Drawing.Size(99, 13);
            this.lblRutaInstancia.TabIndex = 605;
            this.lblRutaInstancia.Text = "lblRutaInstancia";
            // 
            // min2
            // 
            this.min2.AutoSize = true;
            this.min2.ForeColor = System.Drawing.Color.White;
            this.min2.Location = new System.Drawing.Point(102, 110);
            this.min2.Name = "min2";
            this.min2.Size = new System.Drawing.Size(19, 13);
            this.min2.TabIndex = 618;
            this.min2.Text = "00";
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.ForeColor = System.Drawing.Color.White;
            this.Label7.Location = new System.Drawing.Point(112, 72);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(49, 13);
            this.Label7.TabIndex = 618;
            this.Label7.Text = "Servidor:";
            // 
            // seg2
            // 
            this.seg2.AutoSize = true;
            this.seg2.ForeColor = System.Drawing.Color.White;
            this.seg2.Location = new System.Drawing.Point(127, 110);
            this.seg2.Name = "seg2";
            this.seg2.Size = new System.Drawing.Size(19, 13);
            this.seg2.TabIndex = 618;
            this.seg2.Text = "00";
            // 
            // milise
            // 
            this.milise.AutoSize = true;
            this.milise.ForeColor = System.Drawing.Color.White;
            this.milise.Location = new System.Drawing.Point(130, 85);
            this.milise.Name = "milise";
            this.milise.Size = new System.Drawing.Size(19, 13);
            this.milise.TabIndex = 618;
            this.milise.Text = "00";
            // 
            // mils2
            // 
            this.mils2.AutoSize = true;
            this.mils2.ForeColor = System.Drawing.Color.White;
            this.mils2.Location = new System.Drawing.Point(208, 110);
            this.mils2.Name = "mils2";
            this.mils2.Size = new System.Drawing.Size(19, 13);
            this.mils2.TabIndex = 618;
            this.mils2.Text = "00";
            // 
            // txtservidor
            // 
            this.txtservidor.AutoSize = true;
            this.txtservidor.ForeColor = System.Drawing.Color.White;
            this.txtservidor.Location = new System.Drawing.Point(167, 72);
            this.txtservidor.Name = "txtservidor";
            this.txtservidor.Size = new System.Drawing.Size(16, 13);
            this.txtservidor.TabIndex = 611;
            this.txtservidor.Text = "---";
            // 
            // GroupBox2
            // 
            this.GroupBox2.Controls.Add(this.txtCrear_procedimientos);
            this.GroupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox2.ForeColor = System.Drawing.Color.White;
            this.GroupBox2.Location = new System.Drawing.Point(290, 315);
            this.GroupBox2.Name = "GroupBox2";
            this.GroupBox2.Size = new System.Drawing.Size(560, 183);
            this.GroupBox2.TabIndex = 622;
            this.GroupBox2.TabStop = false;
            this.GroupBox2.Text = "PEGA TU Script para Crear las Tablas y Procedimientos";
            // 
            // txtCrear_procedimientos
            // 
            this.txtCrear_procedimientos.Location = new System.Drawing.Point(12, 25);
            this.txtCrear_procedimientos.Name = "txtCrear_procedimientos";
            this.txtCrear_procedimientos.Size = new System.Drawing.Size(458, 152);
            this.txtCrear_procedimientos.TabIndex = 0;
            this.txtCrear_procedimientos.Text = resources.GetString("txtCrear_procedimientos.Text");
            // 
            // datalistado
            // 
            this.datalistado.AllowUserToAddRows = false;
            this.datalistado.AllowUserToDeleteRows = false;
            this.datalistado.AllowUserToOrderColumns = true;
            this.datalistado.BackgroundColor = System.Drawing.Color.White;
            this.datalistado.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.datalistado.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.datalistado.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.datalistado.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datalistado.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Eliminar});
            this.datalistado.Cursor = System.Windows.Forms.Cursors.Hand;
            this.datalistado.EnableHeadersVisualStyles = false;
            this.datalistado.GridColor = System.Drawing.Color.LightGray;
            this.datalistado.Location = new System.Drawing.Point(743, 341);
            this.datalistado.Name = "datalistado";
            this.datalistado.ReadOnly = true;
            this.datalistado.RowHeadersVisible = false;
            this.datalistado.RowHeadersWidth = 5;
            this.datalistado.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.datalistado.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.LightGray;
            this.datalistado.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.datalistado.RowTemplate.Height = 60;
            this.datalistado.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datalistado.Size = new System.Drawing.Size(47, 49);
            this.datalistado.TabIndex = 625;
            // 
            // Eliminar
            // 
            this.Eliminar.HeaderText = "Eliminar";
            this.Eliminar.Name = "Eliminar";
            this.Eliminar.ReadOnly = true;
            this.Eliminar.Visible = false;
            // 
            // Panel2
            // 
            this.Panel2.Controls.Add(this.Panel4);
            this.Panel2.Controls.Add(this.Panel9);
            this.Panel2.Controls.Add(this.btnInstalarServidor);
            this.Panel2.Location = new System.Drawing.Point(92, 166);
            this.Panel2.Name = "Panel2";
            this.Panel2.Size = new System.Drawing.Size(485, 539);
            this.Panel2.TabIndex = 620;
            // 
            // Panel4
            // 
            this.Panel4.BackColor = System.Drawing.Color.White;
            this.Panel4.Controls.Add(this.PictureBox2);
            this.Panel4.Controls.Add(this.Panel6);
            this.Panel4.Controls.Add(this.Label1);
            this.Panel4.Controls.Add(this.PictureBox1);
            this.Panel4.Controls.Add(this.Panel5);
            this.Panel4.Location = new System.Drawing.Point(0, 97);
            this.Panel4.Name = "Panel4";
            this.Panel4.Size = new System.Drawing.Size(482, 556);
            this.Panel4.TabIndex = 618;
            this.Panel4.Visible = false;
            // 
            // PictureBox2
            // 
            this.PictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.PictureBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox2.Image")));
            this.PictureBox2.Location = new System.Drawing.Point(0, 307);
            this.PictureBox2.Name = "PictureBox2";
            this.PictureBox2.Size = new System.Drawing.Size(482, 249);
            this.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PictureBox2.TabIndex = 617;
            this.PictureBox2.TabStop = false;
            // 
            // Panel6
            // 
            this.Panel6.Controls.Add(this.Panel7);
            this.Panel6.Controls.Add(this.Label2);
            this.Panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel6.Location = new System.Drawing.Point(0, 243);
            this.Panel6.Name = "Panel6";
            this.Panel6.Size = new System.Drawing.Size(482, 64);
            this.Panel6.TabIndex = 620;
            // 
            // Panel7
            // 
            this.Panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.Panel7.Controls.Add(this.Label5);
            this.Panel7.Controls.Add(this.min);
            this.Panel7.Controls.Add(this.Label4);
            this.Panel7.Controls.Add(this.seg);
            this.Panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Panel7.Location = new System.Drawing.Point(280, 0);
            this.Panel7.Name = "Panel7";
            this.Panel7.Size = new System.Drawing.Size(202, 64);
            this.Panel7.TabIndex = 619;
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.ForeColor = System.Drawing.Color.White;
            this.Label5.Location = new System.Drawing.Point(63, 10);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(23, 13);
            this.Label5.TabIndex = 618;
            this.Label5.Text = "min";
            // 
            // min
            // 
            this.min.AutoSize = true;
            this.min.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.min.ForeColor = System.Drawing.Color.White;
            this.min.Location = new System.Drawing.Point(59, 33);
            this.min.Name = "min";
            this.min.Size = new System.Drawing.Size(27, 20);
            this.min.TabIndex = 618;
            this.min.Text = "00";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.ForeColor = System.Drawing.Color.White;
            this.Label4.Location = new System.Drawing.Point(125, 10);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(24, 13);
            this.Label4.TabIndex = 618;
            this.Label4.Text = "seg";
            // 
            // seg
            // 
            this.seg.AutoSize = true;
            this.seg.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.seg.ForeColor = System.Drawing.Color.White;
            this.seg.Location = new System.Drawing.Point(125, 33);
            this.seg.Name = "seg";
            this.seg.Size = new System.Drawing.Size(27, 20);
            this.seg.TabIndex = 618;
            this.seg.Text = "00";
            // 
            // Label2
            // 
            this.Label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.Label2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Label2.Dock = System.Windows.Forms.DockStyle.Left;
            this.Label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold);
            this.Label2.ForeColor = System.Drawing.Color.DarkGray;
            this.Label2.Location = new System.Drawing.Point(0, 0);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(280, 64);
            this.Label2.TabIndex = 619;
            this.Label2.Text = "Tiempo estimado: 6 minutos";
            this.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label1
            // 
            this.Label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.Label1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.Label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold);
            this.Label1.ForeColor = System.Drawing.Color.White;
            this.Label1.Location = new System.Drawing.Point(0, 70);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(482, 173);
            this.Label1.TabIndex = 616;
            this.Label1.Text = "Instalando Servidor...\r\n\r\nNo Cierre esta Ventana, se cerrara Automaticamente cuan" +
    "do este todo Listo";
            this.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PictureBox1
            // 
            this.PictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.PictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.PictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox1.Image")));
            this.PictureBox1.Location = new System.Drawing.Point(0, 13);
            this.PictureBox1.Name = "PictureBox1";
            this.PictureBox1.Size = new System.Drawing.Size(482, 57);
            this.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PictureBox1.TabIndex = 604;
            this.PictureBox1.TabStop = false;
            // 
            // Panel5
            // 
            this.Panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.Panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel5.Location = new System.Drawing.Point(0, 0);
            this.Panel5.Name = "Panel5";
            this.Panel5.Size = new System.Drawing.Size(482, 13);
            this.Panel5.TabIndex = 618;
            // 
            // Panel9
            // 
            this.Panel9.Controls.Add(this.lblbuscador_de_servidores);
            this.Panel9.Controls.Add(this.Panel1);
            this.Panel9.Location = new System.Drawing.Point(16, 107);
            this.Panel9.Name = "Panel9";
            this.Panel9.Size = new System.Drawing.Size(452, 153);
            this.Panel9.TabIndex = 619;
            // 
            // lblbuscador_de_servidores
            // 
            this.lblbuscador_de_servidores.BackColor = System.Drawing.Color.Transparent;
            this.lblbuscador_de_servidores.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblbuscador_de_servidores.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.lblbuscador_de_servidores.ForeColor = System.Drawing.Color.White;
            this.lblbuscador_de_servidores.Location = new System.Drawing.Point(3, 0);
            this.lblbuscador_de_servidores.Name = "lblbuscador_de_servidores";
            this.lblbuscador_de_servidores.Size = new System.Drawing.Size(449, 153);
            this.lblbuscador_de_servidores.TabIndex = 614;
            this.lblbuscador_de_servidores.Text = "Buscando servidores instalados...";
            this.lblbuscador_de_servidores.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Panel1
            // 
            this.Panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Panel1.BackgroundImage")));
            this.Panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.Panel1.Location = new System.Drawing.Point(0, 0);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(3, 153);
            this.Panel1.TabIndex = 615;
            // 
            // btnInstalarServidor
            // 
            this.btnInstalarServidor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
            this.btnInstalarServidor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInstalarServidor.FlatAppearance.BorderSize = 0;
            this.btnInstalarServidor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInstalarServidor.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold);
            this.btnInstalarServidor.ForeColor = System.Drawing.Color.White;
            this.btnInstalarServidor.Location = new System.Drawing.Point(29, 19);
            this.btnInstalarServidor.Name = "btnInstalarServidor";
            this.btnInstalarServidor.Size = new System.Drawing.Size(413, 84);
            this.btnInstalarServidor.TabIndex = 610;
            this.btnInstalarServidor.Text = "Instalar Servidor";
            this.btnInstalarServidor.UseVisualStyleBackColor = false;
            this.btnInstalarServidor.Visible = false;
            this.btnInstalarServidor.Click += new System.EventHandler(this.btnInstalarServidor_Click);
            // 
            // timer2
            // 
            this.timer2.Interval = 10;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // timer3
            // 
            this.timer3.Interval = 10;
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // timer4
            // 
            this.timer4.Interval = 10;
            this.timer4.Tick += new System.EventHandler(this.timer4_Tick);
            // 
            // TimerCRARINI
            // 
            this.TimerCRARINI.Interval = 10;
            this.TimerCRARINI.Tick += new System.EventHandler(this.TimerCRARINI_Tick);
            // 
            // btnModoProgramador
            // 
            this.btnModoProgramador.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
            this.btnModoProgramador.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnModoProgramador.FlatAppearance.BorderSize = 0;
            this.btnModoProgramador.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnModoProgramador.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.btnModoProgramador.ForeColor = System.Drawing.Color.White;
            this.btnModoProgramador.Location = new System.Drawing.Point(12, 92);
            this.btnModoProgramador.Name = "btnModoProgramador";
            this.btnModoProgramador.Size = new System.Drawing.Size(284, 68);
            this.btnModoProgramador.TabIndex = 622;
            this.btnModoProgramador.Text = "MODO PROGRAMADOR";
            this.btnModoProgramador.UseVisualStyleBackColor = false;
            this.btnModoProgramador.Click += new System.EventHandler(this.btnModoProgramador_Click);
            // 
            // InstalarServidor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1623, 876);
            this.Controls.Add(this.btnModoProgramador);
            this.Controls.Add(this.PanelDios);
            this.Controls.Add(this.Panel2);
            this.Controls.Add(this.Panel8);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "InstalarServidor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Instalar Servidor";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.InstalarServidor_Load);
            this.Panel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox7)).EndInit();
            this.PanelDios.ResumeLayout(false);
            this.GroupBox6.ResumeLayout(false);
            this.GroupBox6.PerformLayout();
            this.GroupBox5.ResumeLayout(false);
            this.GroupBox4.ResumeLayout(false);
            this.GroupBox4.PerformLayout();
            this.GroupBox3.ResumeLayout(false);
            this.Panel10.ResumeLayout(false);
            this.Panel10.PerformLayout();
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            this.GroupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.datalistado)).EndInit();
            this.Panel2.ResumeLayout(false);
            this.Panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox2)).EndInit();
            this.Panel6.ResumeLayout(false);
            this.Panel7.ResumeLayout(false);
            this.Panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).EndInit();
            this.Panel9.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Panel Panel8;
        internal System.Windows.Forms.PictureBox PictureBox7;
        internal System.Windows.Forms.Label lblwindows;
        internal System.Windows.Forms.Panel PanelDios;
        internal System.Windows.Forms.GroupBox GroupBox6;
        internal System.Windows.Forms.Label seg3;
        internal System.Windows.Forms.Label mil3;
        internal System.Windows.Forms.TextBox txtCrearUsuarioDb;
        internal System.Windows.Forms.GroupBox GroupBox5;
        internal System.Windows.Forms.Button btnInstalarServi;
        internal System.Windows.Forms.Button btnTransmision;
        internal System.Windows.Forms.Button btnvolver;
        internal System.Windows.Forms.GroupBox GroupBox4;
        internal System.Windows.Forms.TextBox txtusuario;
        internal System.Windows.Forms.Label Label15;
        internal System.Windows.Forms.Label Label14;
        internal System.Windows.Forms.Label Label13;
        internal System.Windows.Forms.Label Label12;
        internal System.Windows.Forms.Label label3;
        internal System.Windows.Forms.TextBox txtsoftware;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.Label lblBasededatos;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.TextBox txtnombre_scrypt;
        internal System.Windows.Forms.Label Label11;
        internal System.Windows.Forms.TextBox TXTbasededatos;
        internal System.Windows.Forms.TextBox lblnombredeservicio;
        internal System.Windows.Forms.TextBox lblcontraseña;
        internal System.Windows.Forms.GroupBox GroupBox3;
        internal System.Windows.Forms.RichTextBox txtArgumentosini;
        internal System.Windows.Forms.Panel Panel10;
        internal System.Windows.Forms.GroupBox GroupBox1;
        internal System.Windows.Forms.RichTextBox txtEliminarBase;
        internal System.Windows.Forms.Label lblRutaInstancia;
        internal System.Windows.Forms.Label min2;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Label seg2;
        internal System.Windows.Forms.Label milise;
        internal System.Windows.Forms.Label mils2;
        internal System.Windows.Forms.Label txtservidor;
        internal System.Windows.Forms.GroupBox GroupBox2;
        private System.Windows.Forms.RichTextBox txtCrear_procedimientos;
        internal System.Windows.Forms.DataGridView datalistado;
        internal System.Windows.Forms.DataGridViewCheckBoxColumn Eliminar;
        internal System.Windows.Forms.Panel Panel2;
        internal System.Windows.Forms.Panel Panel4;
        internal System.Windows.Forms.PictureBox PictureBox2;
        internal System.Windows.Forms.Panel Panel6;
        internal System.Windows.Forms.Panel Panel7;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Label min;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label seg;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.PictureBox PictureBox1;
        internal System.Windows.Forms.Panel Panel5;
        internal System.Windows.Forms.Panel Panel9;
        internal System.Windows.Forms.Label lblbuscador_de_servidores;
        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.Button btnInstalarServidor;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Timer timer4;
        private System.Windows.Forms.Timer TimerCRARINI;
        internal System.Windows.Forms.Button btnModoProgramador;
    }
}