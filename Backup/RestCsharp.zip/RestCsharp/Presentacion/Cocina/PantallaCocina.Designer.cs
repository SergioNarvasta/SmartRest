﻿
namespace RestCsharp.Presentacion.Cocina
{
    partial class PantallaCocina
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PantallaCocina));
            this.Panel72 = new System.Windows.Forms.Panel();
            this.Panel74 = new System.Windows.Forms.Panel();
            this.Panel75 = new System.Windows.Forms.Panel();
            this.Panel73 = new System.Windows.Forms.Panel();
            this.PSinpedidos = new System.Windows.Forms.Panel();
            this.Label11 = new System.Windows.Forms.Label();
            this.FlowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.P1 = new System.Windows.Forms.Panel();
            this.datalistadoDetalledeventa1 = new System.Windows.Forms.DataGridView();
            this.Accion1 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Volver1 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.panelm1 = new System.Windows.Forms.Panel();
            this.btnVer1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Panel6 = new System.Windows.Forms.Panel();
            this.btnDespacharTodos1 = new System.Windows.Forms.Button();
            this.btnPrepararTodos1 = new System.Windows.Forms.Button();
            this.Panel2 = new System.Windows.Forms.Panel();
            this.Panel5 = new System.Windows.Forms.Panel();
            this.btnNPedido1 = new System.Windows.Forms.Button();
            this.Panel10 = new System.Windows.Forms.Panel();
            this.Panel9 = new System.Windows.Forms.Panel();
            this.Panel7 = new System.Windows.Forms.Panel();
            this.Panel8 = new System.Windows.Forms.Panel();
            this.lblminutos1 = new System.Windows.Forms.Label();
            this.lblfecha1 = new System.Windows.Forms.Label();
            this.Panel13 = new System.Windows.Forms.Panel();
            this.Panel4 = new System.Windows.Forms.Panel();
            this.lblMozo1 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.Panel3 = new System.Windows.Forms.Panel();
            this.lblmesa1 = new System.Windows.Forms.Label();
            this.etiquetamesa1 = new System.Windows.Forms.Label();
            this.Panel12 = new System.Windows.Forms.Panel();
            this.P2 = new System.Windows.Forms.Panel();
            this.datalistadoDetalledeventa2 = new System.Windows.Forms.DataGridView();
            this.Accion2 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Volver2 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.panelm2 = new System.Windows.Forms.Panel();
            this.btnver2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.Panel14 = new System.Windows.Forms.Panel();
            this.btnDespacharTodos2 = new System.Windows.Forms.Button();
            this.btnPrepararTodos2 = new System.Windows.Forms.Button();
            this.Panel15 = new System.Windows.Forms.Panel();
            this.Panel16 = new System.Windows.Forms.Panel();
            this.btnNPedido2 = new System.Windows.Forms.Button();
            this.Panel17 = new System.Windows.Forms.Panel();
            this.Panel18 = new System.Windows.Forms.Panel();
            this.Panel19 = new System.Windows.Forms.Panel();
            this.Panel20 = new System.Windows.Forms.Panel();
            this.lblminutos2 = new System.Windows.Forms.Label();
            this.lblfecha2 = new System.Windows.Forms.Label();
            this.Panel21 = new System.Windows.Forms.Panel();
            this.Panel22 = new System.Windows.Forms.Panel();
            this.lblMozo2 = new System.Windows.Forms.Label();
            this.Label8 = new System.Windows.Forms.Label();
            this.Panel23 = new System.Windows.Forms.Panel();
            this.lblmesa2 = new System.Windows.Forms.Label();
            this.etiquetamesa2 = new System.Windows.Forms.Label();
            this.Panel24 = new System.Windows.Forms.Panel();
            this.P3 = new System.Windows.Forms.Panel();
            this.datalistadoDetalledeventa3 = new System.Windows.Forms.DataGridView();
            this.Accion3 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Volver3 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.panelm3 = new System.Windows.Forms.Panel();
            this.btnver3 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.Panel25 = new System.Windows.Forms.Panel();
            this.Button1 = new System.Windows.Forms.Button();
            this.Button2 = new System.Windows.Forms.Button();
            this.Panel26 = new System.Windows.Forms.Panel();
            this.Panel27 = new System.Windows.Forms.Panel();
            this.btnNPedido3 = new System.Windows.Forms.Button();
            this.Panel28 = new System.Windows.Forms.Panel();
            this.Panel29 = new System.Windows.Forms.Panel();
            this.Panel30 = new System.Windows.Forms.Panel();
            this.Panel31 = new System.Windows.Forms.Panel();
            this.lblminutos3 = new System.Windows.Forms.Label();
            this.lblfecha3 = new System.Windows.Forms.Label();
            this.Panel32 = new System.Windows.Forms.Panel();
            this.Panel33 = new System.Windows.Forms.Panel();
            this.lblMozo3 = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.Panel34 = new System.Windows.Forms.Panel();
            this.lblmesa3 = new System.Windows.Forms.Label();
            this.etiquetamesa3 = new System.Windows.Forms.Label();
            this.Panel35 = new System.Windows.Forms.Panel();
            this.P4 = new System.Windows.Forms.Panel();
            this.datalistadoDetalledeventa4 = new System.Windows.Forms.DataGridView();
            this.Accion4 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Volver4 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.panelm4 = new System.Windows.Forms.Panel();
            this.btnver4 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.Panel37 = new System.Windows.Forms.Panel();
            this.Button4 = new System.Windows.Forms.Button();
            this.Button5 = new System.Windows.Forms.Button();
            this.Panel38 = new System.Windows.Forms.Panel();
            this.Panel39 = new System.Windows.Forms.Panel();
            this.btnNPedido4 = new System.Windows.Forms.Button();
            this.Panel40 = new System.Windows.Forms.Panel();
            this.Panel41 = new System.Windows.Forms.Panel();
            this.Panel42 = new System.Windows.Forms.Panel();
            this.Panel43 = new System.Windows.Forms.Panel();
            this.lblminutos4 = new System.Windows.Forms.Label();
            this.lblfecha4 = new System.Windows.Forms.Label();
            this.Panel44 = new System.Windows.Forms.Panel();
            this.Panel45 = new System.Windows.Forms.Panel();
            this.lblMozo4 = new System.Windows.Forms.Label();
            this.Label13 = new System.Windows.Forms.Label();
            this.Panel46 = new System.Windows.Forms.Panel();
            this.lblmesa4 = new System.Windows.Forms.Label();
            this.etiquetamesa4 = new System.Windows.Forms.Label();
            this.Panel47 = new System.Windows.Forms.Panel();
            this.P5 = new System.Windows.Forms.Panel();
            this.datalistadoDetalledeventa5 = new System.Windows.Forms.DataGridView();
            this.Accion5 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Volver5 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.panelm5 = new System.Windows.Forms.Panel();
            this.btnver5 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.Panel49 = new System.Windows.Forms.Panel();
            this.Button7 = new System.Windows.Forms.Button();
            this.Button8 = new System.Windows.Forms.Button();
            this.Panel50 = new System.Windows.Forms.Panel();
            this.Panel51 = new System.Windows.Forms.Panel();
            this.btnNPedido5 = new System.Windows.Forms.Button();
            this.Panel52 = new System.Windows.Forms.Panel();
            this.Panel53 = new System.Windows.Forms.Panel();
            this.Panel54 = new System.Windows.Forms.Panel();
            this.Panel55 = new System.Windows.Forms.Panel();
            this.lblminutos5 = new System.Windows.Forms.Label();
            this.lblfecha5 = new System.Windows.Forms.Label();
            this.Panel56 = new System.Windows.Forms.Panel();
            this.Panel57 = new System.Windows.Forms.Panel();
            this.lblMozo5 = new System.Windows.Forms.Label();
            this.Label19 = new System.Windows.Forms.Label();
            this.Panel58 = new System.Windows.Forms.Panel();
            this.lblmesa5 = new System.Windows.Forms.Label();
            this.etiquetamesa5 = new System.Windows.Forms.Label();
            this.Panel59 = new System.Windows.Forms.Panel();
            this.P6 = new System.Windows.Forms.Panel();
            this.datalistadoDetalledeventa6 = new System.Windows.Forms.DataGridView();
            this.Accion6 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Volver6 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.panelm6 = new System.Windows.Forms.Panel();
            this.btnver6 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.Panel61 = new System.Windows.Forms.Panel();
            this.Button10 = new System.Windows.Forms.Button();
            this.Button11 = new System.Windows.Forms.Button();
            this.Panel62 = new System.Windows.Forms.Panel();
            this.Panel63 = new System.Windows.Forms.Panel();
            this.btnNPedido6 = new System.Windows.Forms.Button();
            this.Panel64 = new System.Windows.Forms.Panel();
            this.Panel65 = new System.Windows.Forms.Panel();
            this.Panel66 = new System.Windows.Forms.Panel();
            this.Panel67 = new System.Windows.Forms.Panel();
            this.lblminutos6 = new System.Windows.Forms.Label();
            this.lblfecha6 = new System.Windows.Forms.Label();
            this.Panel68 = new System.Windows.Forms.Panel();
            this.Panel69 = new System.Windows.Forms.Panel();
            this.lblMozo6 = new System.Windows.Forms.Label();
            this.Label25 = new System.Windows.Forms.Label();
            this.Panel70 = new System.Windows.Forms.Panel();
            this.lblmesa6 = new System.Windows.Forms.Label();
            this.etiquetamesa6 = new System.Windows.Forms.Label();
            this.Panel71 = new System.Windows.Forms.Panel();
            this.TimerP1 = new System.Windows.Forms.Timer(this.components);
            this.TimerP2 = new System.Windows.Forms.Timer(this.components);
            this.TimerP3 = new System.Windows.Forms.Timer(this.components);
            this.TimerP4 = new System.Windows.Forms.Timer(this.components);
            this.TimerP5 = new System.Windows.Forms.Timer(this.components);
            this.TimerP6 = new System.Windows.Forms.Timer(this.components);
            this.TimerActualizador = new System.Windows.Forms.Timer(this.components);
            this.TimerNUEVOSPEDIDOS = new System.Windows.Forms.Timer(this.components);
            this.PSinpedidos.SuspendLayout();
            this.FlowLayoutPanel1.SuspendLayout();
            this.P1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datalistadoDetalledeventa1)).BeginInit();
            this.panelm1.SuspendLayout();
            this.Panel6.SuspendLayout();
            this.Panel2.SuspendLayout();
            this.Panel5.SuspendLayout();
            this.Panel7.SuspendLayout();
            this.Panel8.SuspendLayout();
            this.Panel4.SuspendLayout();
            this.Panel3.SuspendLayout();
            this.P2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datalistadoDetalledeventa2)).BeginInit();
            this.panelm2.SuspendLayout();
            this.Panel14.SuspendLayout();
            this.Panel15.SuspendLayout();
            this.Panel16.SuspendLayout();
            this.Panel19.SuspendLayout();
            this.Panel20.SuspendLayout();
            this.Panel22.SuspendLayout();
            this.Panel23.SuspendLayout();
            this.P3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datalistadoDetalledeventa3)).BeginInit();
            this.panelm3.SuspendLayout();
            this.Panel25.SuspendLayout();
            this.Panel26.SuspendLayout();
            this.Panel27.SuspendLayout();
            this.Panel30.SuspendLayout();
            this.Panel31.SuspendLayout();
            this.Panel33.SuspendLayout();
            this.Panel34.SuspendLayout();
            this.P4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datalistadoDetalledeventa4)).BeginInit();
            this.panelm4.SuspendLayout();
            this.Panel37.SuspendLayout();
            this.Panel38.SuspendLayout();
            this.Panel39.SuspendLayout();
            this.Panel42.SuspendLayout();
            this.Panel43.SuspendLayout();
            this.Panel45.SuspendLayout();
            this.Panel46.SuspendLayout();
            this.P5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datalistadoDetalledeventa5)).BeginInit();
            this.panelm5.SuspendLayout();
            this.Panel49.SuspendLayout();
            this.Panel50.SuspendLayout();
            this.Panel51.SuspendLayout();
            this.Panel54.SuspendLayout();
            this.Panel55.SuspendLayout();
            this.Panel57.SuspendLayout();
            this.Panel58.SuspendLayout();
            this.P6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datalistadoDetalledeventa6)).BeginInit();
            this.panelm6.SuspendLayout();
            this.Panel61.SuspendLayout();
            this.Panel62.SuspendLayout();
            this.Panel63.SuspendLayout();
            this.Panel66.SuspendLayout();
            this.Panel67.SuspendLayout();
            this.Panel69.SuspendLayout();
            this.Panel70.SuspendLayout();
            this.SuspendLayout();
            // 
            // Panel72
            // 
            this.Panel72.Dock = System.Windows.Forms.DockStyle.Left;
            this.Panel72.Location = new System.Drawing.Point(0, 0);
            this.Panel72.Name = "Panel72";
            this.Panel72.Size = new System.Drawing.Size(88, 816);
            this.Panel72.TabIndex = 570;
            // 
            // Panel74
            // 
            this.Panel74.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel74.Location = new System.Drawing.Point(88, 0);
            this.Panel74.Name = "Panel74";
            this.Panel74.Size = new System.Drawing.Size(1315, 16);
            this.Panel74.TabIndex = 572;
            // 
            // Panel75
            // 
            this.Panel75.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.Panel75.Location = new System.Drawing.Point(88, 800);
            this.Panel75.Name = "Panel75";
            this.Panel75.Size = new System.Drawing.Size(1315, 16);
            this.Panel75.TabIndex = 573;
            // 
            // Panel73
            // 
            this.Panel73.Dock = System.Windows.Forms.DockStyle.Right;
            this.Panel73.Location = new System.Drawing.Point(1294, 16);
            this.Panel73.Name = "Panel73";
            this.Panel73.Size = new System.Drawing.Size(109, 784);
            this.Panel73.TabIndex = 574;
            // 
            // PSinpedidos
            // 
            this.PSinpedidos.Controls.Add(this.Label11);
            this.PSinpedidos.Location = new System.Drawing.Point(181, 22);
            this.PSinpedidos.Name = "PSinpedidos";
            this.PSinpedidos.Size = new System.Drawing.Size(574, 66);
            this.PSinpedidos.TabIndex = 575;
            // 
            // Label11
            // 
            this.Label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label11.ForeColor = System.Drawing.Color.White;
            this.Label11.Location = new System.Drawing.Point(0, 0);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(574, 66);
            this.Label11.TabIndex = 0;
            this.Label11.Text = "SIN PEDIDOS";
            this.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FlowLayoutPanel1
            // 
            this.FlowLayoutPanel1.Controls.Add(this.P1);
            this.FlowLayoutPanel1.Controls.Add(this.P2);
            this.FlowLayoutPanel1.Controls.Add(this.P3);
            this.FlowLayoutPanel1.Controls.Add(this.P4);
            this.FlowLayoutPanel1.Controls.Add(this.P5);
            this.FlowLayoutPanel1.Controls.Add(this.P6);
            this.FlowLayoutPanel1.Location = new System.Drawing.Point(106, 78);
            this.FlowLayoutPanel1.Name = "FlowLayoutPanel1";
            this.FlowLayoutPanel1.Size = new System.Drawing.Size(1153, 717);
            this.FlowLayoutPanel1.TabIndex = 576;
            // 
            // P1
            // 
            this.P1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.P1.Controls.Add(this.datalistadoDetalledeventa1);
            this.P1.Controls.Add(this.panelm1);
            this.P1.Controls.Add(this.Panel6);
            this.P1.Controls.Add(this.Panel2);
            this.P1.Location = new System.Drawing.Point(3, 3);
            this.P1.Name = "P1";
            this.P1.Size = new System.Drawing.Size(377, 335);
            this.P1.TabIndex = 0;
            // 
            // datalistadoDetalledeventa1
            // 
            this.datalistadoDetalledeventa1.AllowUserToAddRows = false;
            this.datalistadoDetalledeventa1.AllowUserToDeleteRows = false;
            this.datalistadoDetalledeventa1.AllowUserToResizeRows = false;
            this.datalistadoDetalledeventa1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.datalistadoDetalledeventa1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.datalistadoDetalledeventa1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.datalistadoDetalledeventa1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.datalistadoDetalledeventa1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.datalistadoDetalledeventa1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datalistadoDetalledeventa1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.datalistadoDetalledeventa1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datalistadoDetalledeventa1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Accion1,
            this.Volver1});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.datalistadoDetalledeventa1.DefaultCellStyle = dataGridViewCellStyle2;
            this.datalistadoDetalledeventa1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.datalistadoDetalledeventa1.Location = new System.Drawing.Point(0, 154);
            this.datalistadoDetalledeventa1.Name = "datalistadoDetalledeventa1";
            this.datalistadoDetalledeventa1.ReadOnly = true;
            this.datalistadoDetalledeventa1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datalistadoDetalledeventa1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.datalistadoDetalledeventa1.RowHeadersVisible = false;
            this.datalistadoDetalledeventa1.RowHeadersWidth = 5;
            this.datalistadoDetalledeventa1.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.datalistadoDetalledeventa1.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datalistadoDetalledeventa1.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.datalistadoDetalledeventa1.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Transparent;
            this.datalistadoDetalledeventa1.RowTemplate.Height = 80;
            this.datalistadoDetalledeventa1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datalistadoDetalledeventa1.Size = new System.Drawing.Size(377, 142);
            this.datalistadoDetalledeventa1.TabIndex = 559;
            this.datalistadoDetalledeventa1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datalistadoDetalledeventa1_CellClick);
            // 
            // Accion1
            // 
            this.Accion1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Accion1.HeaderText = "";
            this.Accion1.Name = "Accion1";
            this.Accion1.ReadOnly = true;
            this.Accion1.Text = "Preparar";
            this.Accion1.Width = 5;
            // 
            // Volver1
            // 
            this.Volver1.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Volver1.HeaderText = "";
            this.Volver1.LinkColor = System.Drawing.Color.White;
            this.Volver1.Name = "Volver1";
            this.Volver1.ReadOnly = true;
            this.Volver1.Width = 5;
            // 
            // panelm1
            // 
            this.panelm1.AutoScroll = true;
            this.panelm1.Controls.Add(this.btnVer1);
            this.panelm1.Controls.Add(this.label1);
            this.panelm1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelm1.Location = new System.Drawing.Point(0, 296);
            this.panelm1.Name = "panelm1";
            this.panelm1.Size = new System.Drawing.Size(377, 39);
            this.panelm1.TabIndex = 560;
            // 
            // btnVer1
            // 
            this.btnVer1.BackColor = System.Drawing.Color.Transparent;
            this.btnVer1.BackgroundImage = global::RestCsharp.Properties.Resources.Rojo;
            this.btnVer1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnVer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnVer1.FlatAppearance.BorderSize = 0;
            this.btnVer1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnVer1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnVer1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVer1.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVer1.ForeColor = System.Drawing.Color.White;
            this.btnVer1.Location = new System.Drawing.Point(298, 0);
            this.btnVer1.Name = "btnVer1";
            this.btnVer1.Size = new System.Drawing.Size(79, 39);
            this.btnVer1.TabIndex = 637;
            this.btnVer1.Text = "Ver";
            this.btnVer1.UseVisualStyleBackColor = false;
            this.btnVer1.Click += new System.EventHandler(this.btnVer1_Click);
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Left;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(298, 39);
            this.label1.TabIndex = 1;
            this.label1.Text = "!Hay nota!";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Panel6
            // 
            this.Panel6.Controls.Add(this.btnDespacharTodos1);
            this.Panel6.Controls.Add(this.btnPrepararTodos1);
            this.Panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel6.Location = new System.Drawing.Point(0, 118);
            this.Panel6.Name = "Panel6";
            this.Panel6.Size = new System.Drawing.Size(377, 36);
            this.Panel6.TabIndex = 1;
            // 
            // btnDespacharTodos1
            // 
            this.btnDespacharTodos1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.btnDespacharTodos1.FlatAppearance.BorderSize = 0;
            this.btnDespacharTodos1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDespacharTodos1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDespacharTodos1.ForeColor = System.Drawing.Color.White;
            this.btnDespacharTodos1.Location = new System.Drawing.Point(147, 6);
            this.btnDespacharTodos1.Name = "btnDespacharTodos1";
            this.btnDespacharTodos1.Size = new System.Drawing.Size(151, 25);
            this.btnDespacharTodos1.TabIndex = 0;
            this.btnDespacharTodos1.Text = "Despachar Todos";
            this.btnDespacharTodos1.UseVisualStyleBackColor = false;
            this.btnDespacharTodos1.Click += new System.EventHandler(this.btnDespacharTodos1_Click);
            // 
            // btnPrepararTodos1
            // 
            this.btnPrepararTodos1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.btnPrepararTodos1.FlatAppearance.BorderSize = 0;
            this.btnPrepararTodos1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrepararTodos1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrepararTodos1.ForeColor = System.Drawing.Color.White;
            this.btnPrepararTodos1.Location = new System.Drawing.Point(4, 6);
            this.btnPrepararTodos1.Name = "btnPrepararTodos1";
            this.btnPrepararTodos1.Size = new System.Drawing.Size(137, 25);
            this.btnPrepararTodos1.TabIndex = 0;
            this.btnPrepararTodos1.Text = "Preparar Todos";
            this.btnPrepararTodos1.UseVisualStyleBackColor = false;
            this.btnPrepararTodos1.Click += new System.EventHandler(this.btnPrepararTodos1_Click);
            // 
            // Panel2
            // 
            this.Panel2.Controls.Add(this.Panel5);
            this.Panel2.Controls.Add(this.Panel7);
            this.Panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel2.Location = new System.Drawing.Point(0, 0);
            this.Panel2.Name = "Panel2";
            this.Panel2.Size = new System.Drawing.Size(377, 118);
            this.Panel2.TabIndex = 0;
            // 
            // Panel5
            // 
            this.Panel5.Controls.Add(this.btnNPedido1);
            this.Panel5.Controls.Add(this.Panel10);
            this.Panel5.Controls.Add(this.Panel9);
            this.Panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Panel5.Location = new System.Drawing.Point(245, 0);
            this.Panel5.Name = "Panel5";
            this.Panel5.Size = new System.Drawing.Size(132, 118);
            this.Panel5.TabIndex = 3;
            // 
            // btnNPedido1
            // 
            this.btnNPedido1.BackColor = System.Drawing.Color.Transparent;
            this.btnNPedido1.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.btnNPedido1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnNPedido1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnNPedido1.FlatAppearance.BorderSize = 0;
            this.btnNPedido1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnNPedido1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnNPedido1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNPedido1.Font = new System.Drawing.Font("Segoe UI", 57F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNPedido1.ForeColor = System.Drawing.Color.White;
            this.btnNPedido1.Location = new System.Drawing.Point(0, 10);
            this.btnNPedido1.Name = "btnNPedido1";
            this.btnNPedido1.Size = new System.Drawing.Size(122, 108);
            this.btnNPedido1.TabIndex = 636;
            this.btnNPedido1.Text = "1";
            this.btnNPedido1.UseVisualStyleBackColor = false;
            // 
            // Panel10
            // 
            this.Panel10.Dock = System.Windows.Forms.DockStyle.Right;
            this.Panel10.Location = new System.Drawing.Point(122, 10);
            this.Panel10.Name = "Panel10";
            this.Panel10.Size = new System.Drawing.Size(10, 108);
            this.Panel10.TabIndex = 1;
            // 
            // Panel9
            // 
            this.Panel9.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel9.Location = new System.Drawing.Point(0, 0);
            this.Panel9.Name = "Panel9";
            this.Panel9.Size = new System.Drawing.Size(132, 10);
            this.Panel9.TabIndex = 0;
            // 
            // Panel7
            // 
            this.Panel7.Controls.Add(this.Panel8);
            this.Panel7.Controls.Add(this.Panel4);
            this.Panel7.Controls.Add(this.Panel3);
            this.Panel7.Dock = System.Windows.Forms.DockStyle.Left;
            this.Panel7.Location = new System.Drawing.Point(0, 0);
            this.Panel7.Name = "Panel7";
            this.Panel7.Size = new System.Drawing.Size(245, 118);
            this.Panel7.TabIndex = 560;
            // 
            // Panel8
            // 
            this.Panel8.Controls.Add(this.lblminutos1);
            this.Panel8.Controls.Add(this.lblfecha1);
            this.Panel8.Controls.Add(this.Panel13);
            this.Panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Panel8.Location = new System.Drawing.Point(0, 78);
            this.Panel8.Name = "Panel8";
            this.Panel8.Size = new System.Drawing.Size(245, 40);
            this.Panel8.TabIndex = 3;
            // 
            // lblminutos1
            // 
            this.lblminutos1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblminutos1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblminutos1.ForeColor = System.Drawing.Color.White;
            this.lblminutos1.Location = new System.Drawing.Point(89, 1);
            this.lblminutos1.Name = "lblminutos1";
            this.lblminutos1.Size = new System.Drawing.Size(156, 39);
            this.lblminutos1.TabIndex = 3;
            this.lblminutos1.Text = "15 minutos";
            this.lblminutos1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblfecha1
            // 
            this.lblfecha1.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblfecha1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfecha1.ForeColor = System.Drawing.Color.White;
            this.lblfecha1.Location = new System.Drawing.Point(0, 1);
            this.lblfecha1.Name = "lblfecha1";
            this.lblfecha1.Size = new System.Drawing.Size(89, 39);
            this.lblfecha1.TabIndex = 2;
            this.lblfecha1.Text = "(8:19 pm)";
            this.lblfecha1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Panel13
            // 
            this.Panel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.Panel13.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel13.Location = new System.Drawing.Point(0, 0);
            this.Panel13.Name = "Panel13";
            this.Panel13.Size = new System.Drawing.Size(245, 1);
            this.Panel13.TabIndex = 4;
            // 
            // Panel4
            // 
            this.Panel4.Controls.Add(this.lblMozo1);
            this.Panel4.Controls.Add(this.Label3);
            this.Panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel4.Location = new System.Drawing.Point(0, 35);
            this.Panel4.Name = "Panel4";
            this.Panel4.Size = new System.Drawing.Size(245, 43);
            this.Panel4.TabIndex = 2;
            // 
            // lblMozo1
            // 
            this.lblMozo1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMozo1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMozo1.ForeColor = System.Drawing.Color.White;
            this.lblMozo1.Location = new System.Drawing.Point(69, 0);
            this.lblMozo1.Name = "lblMozo1";
            this.lblMozo1.Size = new System.Drawing.Size(176, 43);
            this.lblMozo1.TabIndex = 3;
            this.lblMozo1.Text = "lblMozo";
            this.lblMozo1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label3
            // 
            this.Label3.Dock = System.Windows.Forms.DockStyle.Left;
            this.Label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.ForeColor = System.Drawing.Color.White;
            this.Label3.Location = new System.Drawing.Point(0, 0);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(69, 43);
            this.Label3.TabIndex = 2;
            this.Label3.Text = "Mozo:";
            this.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Panel3
            // 
            this.Panel3.Controls.Add(this.lblmesa1);
            this.Panel3.Controls.Add(this.etiquetamesa1);
            this.Panel3.Controls.Add(this.Panel12);
            this.Panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel3.Location = new System.Drawing.Point(0, 0);
            this.Panel3.Name = "Panel3";
            this.Panel3.Size = new System.Drawing.Size(245, 35);
            this.Panel3.TabIndex = 1;
            // 
            // lblmesa1
            // 
            this.lblmesa1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblmesa1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmesa1.ForeColor = System.Drawing.Color.White;
            this.lblmesa1.Location = new System.Drawing.Point(69, 0);
            this.lblmesa1.Name = "lblmesa1";
            this.lblmesa1.Size = new System.Drawing.Size(176, 34);
            this.lblmesa1.TabIndex = 1;
            this.lblmesa1.Text = "lblmesa1";
            this.lblmesa1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // etiquetamesa1
            // 
            this.etiquetamesa1.Dock = System.Windows.Forms.DockStyle.Left;
            this.etiquetamesa1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.etiquetamesa1.ForeColor = System.Drawing.Color.White;
            this.etiquetamesa1.Location = new System.Drawing.Point(0, 0);
            this.etiquetamesa1.Name = "etiquetamesa1";
            this.etiquetamesa1.Size = new System.Drawing.Size(69, 34);
            this.etiquetamesa1.TabIndex = 0;
            this.etiquetamesa1.Text = "MESA:";
            this.etiquetamesa1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Panel12
            // 
            this.Panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.Panel12.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.Panel12.Location = new System.Drawing.Point(0, 34);
            this.Panel12.Name = "Panel12";
            this.Panel12.Size = new System.Drawing.Size(245, 1);
            this.Panel12.TabIndex = 2;
            // 
            // P2
            // 
            this.P2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.P2.Controls.Add(this.datalistadoDetalledeventa2);
            this.P2.Controls.Add(this.panelm2);
            this.P2.Controls.Add(this.Panel14);
            this.P2.Controls.Add(this.Panel15);
            this.P2.Location = new System.Drawing.Point(386, 3);
            this.P2.Name = "P2";
            this.P2.Size = new System.Drawing.Size(377, 335);
            this.P2.TabIndex = 1;
            // 
            // datalistadoDetalledeventa2
            // 
            this.datalistadoDetalledeventa2.AllowUserToAddRows = false;
            this.datalistadoDetalledeventa2.AllowUserToDeleteRows = false;
            this.datalistadoDetalledeventa2.AllowUserToResizeRows = false;
            this.datalistadoDetalledeventa2.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.datalistadoDetalledeventa2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.datalistadoDetalledeventa2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.datalistadoDetalledeventa2.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.datalistadoDetalledeventa2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datalistadoDetalledeventa2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.datalistadoDetalledeventa2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datalistadoDetalledeventa2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Accion2,
            this.Volver2});
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.datalistadoDetalledeventa2.DefaultCellStyle = dataGridViewCellStyle5;
            this.datalistadoDetalledeventa2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.datalistadoDetalledeventa2.Location = new System.Drawing.Point(0, 154);
            this.datalistadoDetalledeventa2.Name = "datalistadoDetalledeventa2";
            this.datalistadoDetalledeventa2.ReadOnly = true;
            this.datalistadoDetalledeventa2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datalistadoDetalledeventa2.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.datalistadoDetalledeventa2.RowHeadersVisible = false;
            this.datalistadoDetalledeventa2.RowHeadersWidth = 5;
            this.datalistadoDetalledeventa2.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.datalistadoDetalledeventa2.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datalistadoDetalledeventa2.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.datalistadoDetalledeventa2.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Transparent;
            this.datalistadoDetalledeventa2.RowTemplate.Height = 30;
            this.datalistadoDetalledeventa2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datalistadoDetalledeventa2.Size = new System.Drawing.Size(377, 142);
            this.datalistadoDetalledeventa2.TabIndex = 559;
            this.datalistadoDetalledeventa2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datalistadoDetalledeventa2_CellClick);
            // 
            // Accion2
            // 
            this.Accion2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Accion2.HeaderText = "";
            this.Accion2.Name = "Accion2";
            this.Accion2.ReadOnly = true;
            this.Accion2.Text = "Preparar";
            // 
            // Volver2
            // 
            this.Volver2.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Volver2.HeaderText = "";
            this.Volver2.LinkColor = System.Drawing.Color.White;
            this.Volver2.Name = "Volver2";
            this.Volver2.ReadOnly = true;
            // 
            // panelm2
            // 
            this.panelm2.AutoScroll = true;
            this.panelm2.Controls.Add(this.btnver2);
            this.panelm2.Controls.Add(this.label2);
            this.panelm2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelm2.Location = new System.Drawing.Point(0, 296);
            this.panelm2.Name = "panelm2";
            this.panelm2.Size = new System.Drawing.Size(377, 39);
            this.panelm2.TabIndex = 561;
            // 
            // btnver2
            // 
            this.btnver2.BackColor = System.Drawing.Color.Transparent;
            this.btnver2.BackgroundImage = global::RestCsharp.Properties.Resources.Rojo;
            this.btnver2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnver2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnver2.FlatAppearance.BorderSize = 0;
            this.btnver2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnver2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnver2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnver2.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnver2.ForeColor = System.Drawing.Color.White;
            this.btnver2.Location = new System.Drawing.Point(298, 0);
            this.btnver2.Name = "btnver2";
            this.btnver2.Size = new System.Drawing.Size(79, 39);
            this.btnver2.TabIndex = 637;
            this.btnver2.Text = "Ver";
            this.btnver2.UseVisualStyleBackColor = false;
            this.btnver2.Click += new System.EventHandler(this.btnver2_Click);
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Left;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(298, 39);
            this.label2.TabIndex = 1;
            this.label2.Text = "!Hay nota!";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Panel14
            // 
            this.Panel14.Controls.Add(this.btnDespacharTodos2);
            this.Panel14.Controls.Add(this.btnPrepararTodos2);
            this.Panel14.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel14.Location = new System.Drawing.Point(0, 118);
            this.Panel14.Name = "Panel14";
            this.Panel14.Size = new System.Drawing.Size(377, 36);
            this.Panel14.TabIndex = 1;
            // 
            // btnDespacharTodos2
            // 
            this.btnDespacharTodos2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.btnDespacharTodos2.FlatAppearance.BorderSize = 0;
            this.btnDespacharTodos2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDespacharTodos2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDespacharTodos2.ForeColor = System.Drawing.Color.White;
            this.btnDespacharTodos2.Location = new System.Drawing.Point(147, 6);
            this.btnDespacharTodos2.Name = "btnDespacharTodos2";
            this.btnDespacharTodos2.Size = new System.Drawing.Size(151, 25);
            this.btnDespacharTodos2.TabIndex = 0;
            this.btnDespacharTodos2.Text = "Despachar Todos";
            this.btnDespacharTodos2.UseVisualStyleBackColor = false;
            this.btnDespacharTodos2.Click += new System.EventHandler(this.btnDespacharTodos2_Click);
            // 
            // btnPrepararTodos2
            // 
            this.btnPrepararTodos2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.btnPrepararTodos2.FlatAppearance.BorderSize = 0;
            this.btnPrepararTodos2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrepararTodos2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrepararTodos2.ForeColor = System.Drawing.Color.White;
            this.btnPrepararTodos2.Location = new System.Drawing.Point(4, 6);
            this.btnPrepararTodos2.Name = "btnPrepararTodos2";
            this.btnPrepararTodos2.Size = new System.Drawing.Size(137, 25);
            this.btnPrepararTodos2.TabIndex = 0;
            this.btnPrepararTodos2.Text = "Preparar Todos";
            this.btnPrepararTodos2.UseVisualStyleBackColor = false;
            this.btnPrepararTodos2.Click += new System.EventHandler(this.btnPrepararTodos2_Click);
            // 
            // Panel15
            // 
            this.Panel15.Controls.Add(this.Panel16);
            this.Panel15.Controls.Add(this.Panel19);
            this.Panel15.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel15.Location = new System.Drawing.Point(0, 0);
            this.Panel15.Name = "Panel15";
            this.Panel15.Size = new System.Drawing.Size(377, 118);
            this.Panel15.TabIndex = 0;
            // 
            // Panel16
            // 
            this.Panel16.Controls.Add(this.btnNPedido2);
            this.Panel16.Controls.Add(this.Panel17);
            this.Panel16.Controls.Add(this.Panel18);
            this.Panel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Panel16.Location = new System.Drawing.Point(245, 0);
            this.Panel16.Name = "Panel16";
            this.Panel16.Size = new System.Drawing.Size(132, 118);
            this.Panel16.TabIndex = 3;
            // 
            // btnNPedido2
            // 
            this.btnNPedido2.BackColor = System.Drawing.Color.Transparent;
            this.btnNPedido2.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.btnNPedido2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnNPedido2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnNPedido2.FlatAppearance.BorderSize = 0;
            this.btnNPedido2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnNPedido2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnNPedido2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNPedido2.Font = new System.Drawing.Font("Segoe UI", 57F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNPedido2.ForeColor = System.Drawing.Color.White;
            this.btnNPedido2.Location = new System.Drawing.Point(0, 10);
            this.btnNPedido2.Name = "btnNPedido2";
            this.btnNPedido2.Size = new System.Drawing.Size(122, 108);
            this.btnNPedido2.TabIndex = 637;
            this.btnNPedido2.Text = "2";
            this.btnNPedido2.UseVisualStyleBackColor = false;
            // 
            // Panel17
            // 
            this.Panel17.Dock = System.Windows.Forms.DockStyle.Right;
            this.Panel17.Location = new System.Drawing.Point(122, 10);
            this.Panel17.Name = "Panel17";
            this.Panel17.Size = new System.Drawing.Size(10, 108);
            this.Panel17.TabIndex = 1;
            // 
            // Panel18
            // 
            this.Panel18.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel18.Location = new System.Drawing.Point(0, 0);
            this.Panel18.Name = "Panel18";
            this.Panel18.Size = new System.Drawing.Size(132, 10);
            this.Panel18.TabIndex = 0;
            // 
            // Panel19
            // 
            this.Panel19.Controls.Add(this.Panel20);
            this.Panel19.Controls.Add(this.Panel22);
            this.Panel19.Controls.Add(this.Panel23);
            this.Panel19.Dock = System.Windows.Forms.DockStyle.Left;
            this.Panel19.Location = new System.Drawing.Point(0, 0);
            this.Panel19.Name = "Panel19";
            this.Panel19.Size = new System.Drawing.Size(245, 118);
            this.Panel19.TabIndex = 560;
            // 
            // Panel20
            // 
            this.Panel20.Controls.Add(this.lblminutos2);
            this.Panel20.Controls.Add(this.lblfecha2);
            this.Panel20.Controls.Add(this.Panel21);
            this.Panel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Panel20.Location = new System.Drawing.Point(0, 78);
            this.Panel20.Name = "Panel20";
            this.Panel20.Size = new System.Drawing.Size(245, 40);
            this.Panel20.TabIndex = 3;
            // 
            // lblminutos2
            // 
            this.lblminutos2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblminutos2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblminutos2.ForeColor = System.Drawing.Color.White;
            this.lblminutos2.Location = new System.Drawing.Point(89, 1);
            this.lblminutos2.Name = "lblminutos2";
            this.lblminutos2.Size = new System.Drawing.Size(156, 39);
            this.lblminutos2.TabIndex = 3;
            this.lblminutos2.Text = "15 minutos";
            this.lblminutos2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblfecha2
            // 
            this.lblfecha2.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblfecha2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfecha2.ForeColor = System.Drawing.Color.White;
            this.lblfecha2.Location = new System.Drawing.Point(0, 1);
            this.lblfecha2.Name = "lblfecha2";
            this.lblfecha2.Size = new System.Drawing.Size(89, 39);
            this.lblfecha2.TabIndex = 2;
            this.lblfecha2.Text = "(8:19 pm)";
            this.lblfecha2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Panel21
            // 
            this.Panel21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.Panel21.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel21.Location = new System.Drawing.Point(0, 0);
            this.Panel21.Name = "Panel21";
            this.Panel21.Size = new System.Drawing.Size(245, 1);
            this.Panel21.TabIndex = 4;
            // 
            // Panel22
            // 
            this.Panel22.Controls.Add(this.lblMozo2);
            this.Panel22.Controls.Add(this.Label8);
            this.Panel22.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel22.Location = new System.Drawing.Point(0, 35);
            this.Panel22.Name = "Panel22";
            this.Panel22.Size = new System.Drawing.Size(245, 43);
            this.Panel22.TabIndex = 2;
            // 
            // lblMozo2
            // 
            this.lblMozo2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMozo2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMozo2.ForeColor = System.Drawing.Color.White;
            this.lblMozo2.Location = new System.Drawing.Point(69, 0);
            this.lblMozo2.Name = "lblMozo2";
            this.lblMozo2.Size = new System.Drawing.Size(176, 43);
            this.lblMozo2.TabIndex = 3;
            this.lblMozo2.Text = "lblMozo2";
            this.lblMozo2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label8
            // 
            this.Label8.Dock = System.Windows.Forms.DockStyle.Left;
            this.Label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label8.ForeColor = System.Drawing.Color.White;
            this.Label8.Location = new System.Drawing.Point(0, 0);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(69, 43);
            this.Label8.TabIndex = 2;
            this.Label8.Text = "Mozo:";
            this.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Panel23
            // 
            this.Panel23.Controls.Add(this.lblmesa2);
            this.Panel23.Controls.Add(this.etiquetamesa2);
            this.Panel23.Controls.Add(this.Panel24);
            this.Panel23.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel23.Location = new System.Drawing.Point(0, 0);
            this.Panel23.Name = "Panel23";
            this.Panel23.Size = new System.Drawing.Size(245, 35);
            this.Panel23.TabIndex = 1;
            // 
            // lblmesa2
            // 
            this.lblmesa2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblmesa2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmesa2.ForeColor = System.Drawing.Color.White;
            this.lblmesa2.Location = new System.Drawing.Point(69, 0);
            this.lblmesa2.Name = "lblmesa2";
            this.lblmesa2.Size = new System.Drawing.Size(176, 34);
            this.lblmesa2.TabIndex = 1;
            this.lblmesa2.Text = "lblmesa2";
            this.lblmesa2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // etiquetamesa2
            // 
            this.etiquetamesa2.Dock = System.Windows.Forms.DockStyle.Left;
            this.etiquetamesa2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.etiquetamesa2.ForeColor = System.Drawing.Color.White;
            this.etiquetamesa2.Location = new System.Drawing.Point(0, 0);
            this.etiquetamesa2.Name = "etiquetamesa2";
            this.etiquetamesa2.Size = new System.Drawing.Size(69, 34);
            this.etiquetamesa2.TabIndex = 0;
            this.etiquetamesa2.Text = "MESA:";
            this.etiquetamesa2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Panel24
            // 
            this.Panel24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.Panel24.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.Panel24.Location = new System.Drawing.Point(0, 34);
            this.Panel24.Name = "Panel24";
            this.Panel24.Size = new System.Drawing.Size(245, 1);
            this.Panel24.TabIndex = 2;
            // 
            // P3
            // 
            this.P3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.P3.Controls.Add(this.datalistadoDetalledeventa3);
            this.P3.Controls.Add(this.panelm3);
            this.P3.Controls.Add(this.Panel25);
            this.P3.Controls.Add(this.Panel26);
            this.P3.Location = new System.Drawing.Point(769, 3);
            this.P3.Name = "P3";
            this.P3.Size = new System.Drawing.Size(377, 335);
            this.P3.TabIndex = 2;
            // 
            // datalistadoDetalledeventa3
            // 
            this.datalistadoDetalledeventa3.AllowUserToAddRows = false;
            this.datalistadoDetalledeventa3.AllowUserToDeleteRows = false;
            this.datalistadoDetalledeventa3.AllowUserToResizeRows = false;
            this.datalistadoDetalledeventa3.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.datalistadoDetalledeventa3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.datalistadoDetalledeventa3.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.datalistadoDetalledeventa3.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datalistadoDetalledeventa3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.datalistadoDetalledeventa3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datalistadoDetalledeventa3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Accion3,
            this.Volver3});
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.datalistadoDetalledeventa3.DefaultCellStyle = dataGridViewCellStyle8;
            this.datalistadoDetalledeventa3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.datalistadoDetalledeventa3.Location = new System.Drawing.Point(0, 154);
            this.datalistadoDetalledeventa3.Name = "datalistadoDetalledeventa3";
            this.datalistadoDetalledeventa3.ReadOnly = true;
            this.datalistadoDetalledeventa3.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datalistadoDetalledeventa3.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.datalistadoDetalledeventa3.RowHeadersVisible = false;
            this.datalistadoDetalledeventa3.RowHeadersWidth = 5;
            this.datalistadoDetalledeventa3.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.datalistadoDetalledeventa3.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datalistadoDetalledeventa3.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.datalistadoDetalledeventa3.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Transparent;
            this.datalistadoDetalledeventa3.RowTemplate.Height = 30;
            this.datalistadoDetalledeventa3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datalistadoDetalledeventa3.Size = new System.Drawing.Size(377, 142);
            this.datalistadoDetalledeventa3.TabIndex = 559;
            this.datalistadoDetalledeventa3.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datalistadoDetalledeventa3_CellClick);
            // 
            // Accion3
            // 
            this.Accion3.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Accion3.HeaderText = "";
            this.Accion3.Name = "Accion3";
            this.Accion3.ReadOnly = true;
            this.Accion3.Text = "Preparar";
            // 
            // Volver3
            // 
            this.Volver3.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Volver3.HeaderText = "";
            this.Volver3.LinkColor = System.Drawing.Color.White;
            this.Volver3.Name = "Volver3";
            this.Volver3.ReadOnly = true;
            // 
            // panelm3
            // 
            this.panelm3.AutoScroll = true;
            this.panelm3.Controls.Add(this.btnver3);
            this.panelm3.Controls.Add(this.label4);
            this.panelm3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelm3.Location = new System.Drawing.Point(0, 296);
            this.panelm3.Name = "panelm3";
            this.panelm3.Size = new System.Drawing.Size(377, 39);
            this.panelm3.TabIndex = 561;
            // 
            // btnver3
            // 
            this.btnver3.BackColor = System.Drawing.Color.Transparent;
            this.btnver3.BackgroundImage = global::RestCsharp.Properties.Resources.Rojo;
            this.btnver3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnver3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnver3.FlatAppearance.BorderSize = 0;
            this.btnver3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnver3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnver3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnver3.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnver3.ForeColor = System.Drawing.Color.White;
            this.btnver3.Location = new System.Drawing.Point(298, 0);
            this.btnver3.Name = "btnver3";
            this.btnver3.Size = new System.Drawing.Size(79, 39);
            this.btnver3.TabIndex = 637;
            this.btnver3.Text = "Ver";
            this.btnver3.UseVisualStyleBackColor = false;
            this.btnver3.Click += new System.EventHandler(this.btnver3_Click);
            // 
            // label4
            // 
            this.label4.Dock = System.Windows.Forms.DockStyle.Left;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.label4.Location = new System.Drawing.Point(0, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(298, 39);
            this.label4.TabIndex = 1;
            this.label4.Text = "!Hay nota!";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Panel25
            // 
            this.Panel25.Controls.Add(this.Button1);
            this.Panel25.Controls.Add(this.Button2);
            this.Panel25.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel25.Location = new System.Drawing.Point(0, 118);
            this.Panel25.Name = "Panel25";
            this.Panel25.Size = new System.Drawing.Size(377, 36);
            this.Panel25.TabIndex = 1;
            // 
            // Button1
            // 
            this.Button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.Button1.FlatAppearance.BorderSize = 0;
            this.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button1.ForeColor = System.Drawing.Color.White;
            this.Button1.Location = new System.Drawing.Point(147, 6);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(151, 25);
            this.Button1.TabIndex = 0;
            this.Button1.Text = "Despachar Todos";
            this.Button1.UseVisualStyleBackColor = false;
            this.Button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // Button2
            // 
            this.Button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.Button2.FlatAppearance.BorderSize = 0;
            this.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button2.ForeColor = System.Drawing.Color.White;
            this.Button2.Location = new System.Drawing.Point(4, 6);
            this.Button2.Name = "Button2";
            this.Button2.Size = new System.Drawing.Size(137, 25);
            this.Button2.TabIndex = 0;
            this.Button2.Text = "Preparar Todos";
            this.Button2.UseVisualStyleBackColor = false;
            this.Button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // Panel26
            // 
            this.Panel26.Controls.Add(this.Panel27);
            this.Panel26.Controls.Add(this.Panel30);
            this.Panel26.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel26.Location = new System.Drawing.Point(0, 0);
            this.Panel26.Name = "Panel26";
            this.Panel26.Size = new System.Drawing.Size(377, 118);
            this.Panel26.TabIndex = 0;
            // 
            // Panel27
            // 
            this.Panel27.Controls.Add(this.btnNPedido3);
            this.Panel27.Controls.Add(this.Panel28);
            this.Panel27.Controls.Add(this.Panel29);
            this.Panel27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Panel27.Location = new System.Drawing.Point(245, 0);
            this.Panel27.Name = "Panel27";
            this.Panel27.Size = new System.Drawing.Size(132, 118);
            this.Panel27.TabIndex = 3;
            // 
            // btnNPedido3
            // 
            this.btnNPedido3.BackColor = System.Drawing.Color.Transparent;
            this.btnNPedido3.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.btnNPedido3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnNPedido3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnNPedido3.FlatAppearance.BorderSize = 0;
            this.btnNPedido3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnNPedido3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnNPedido3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNPedido3.Font = new System.Drawing.Font("Segoe UI", 57F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNPedido3.ForeColor = System.Drawing.Color.White;
            this.btnNPedido3.Location = new System.Drawing.Point(0, 10);
            this.btnNPedido3.Name = "btnNPedido3";
            this.btnNPedido3.Size = new System.Drawing.Size(122, 108);
            this.btnNPedido3.TabIndex = 636;
            this.btnNPedido3.Text = "3";
            this.btnNPedido3.UseVisualStyleBackColor = false;
            // 
            // Panel28
            // 
            this.Panel28.Dock = System.Windows.Forms.DockStyle.Right;
            this.Panel28.Location = new System.Drawing.Point(122, 10);
            this.Panel28.Name = "Panel28";
            this.Panel28.Size = new System.Drawing.Size(10, 108);
            this.Panel28.TabIndex = 1;
            // 
            // Panel29
            // 
            this.Panel29.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel29.Location = new System.Drawing.Point(0, 0);
            this.Panel29.Name = "Panel29";
            this.Panel29.Size = new System.Drawing.Size(132, 10);
            this.Panel29.TabIndex = 0;
            // 
            // Panel30
            // 
            this.Panel30.Controls.Add(this.Panel31);
            this.Panel30.Controls.Add(this.Panel33);
            this.Panel30.Controls.Add(this.Panel34);
            this.Panel30.Dock = System.Windows.Forms.DockStyle.Left;
            this.Panel30.Location = new System.Drawing.Point(0, 0);
            this.Panel30.Name = "Panel30";
            this.Panel30.Size = new System.Drawing.Size(245, 118);
            this.Panel30.TabIndex = 560;
            // 
            // Panel31
            // 
            this.Panel31.Controls.Add(this.lblminutos3);
            this.Panel31.Controls.Add(this.lblfecha3);
            this.Panel31.Controls.Add(this.Panel32);
            this.Panel31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Panel31.Location = new System.Drawing.Point(0, 78);
            this.Panel31.Name = "Panel31";
            this.Panel31.Size = new System.Drawing.Size(245, 40);
            this.Panel31.TabIndex = 3;
            // 
            // lblminutos3
            // 
            this.lblminutos3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblminutos3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblminutos3.ForeColor = System.Drawing.Color.White;
            this.lblminutos3.Location = new System.Drawing.Point(89, 1);
            this.lblminutos3.Name = "lblminutos3";
            this.lblminutos3.Size = new System.Drawing.Size(156, 39);
            this.lblminutos3.TabIndex = 3;
            this.lblminutos3.Text = "15 minutos";
            this.lblminutos3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblfecha3
            // 
            this.lblfecha3.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblfecha3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfecha3.ForeColor = System.Drawing.Color.White;
            this.lblfecha3.Location = new System.Drawing.Point(0, 1);
            this.lblfecha3.Name = "lblfecha3";
            this.lblfecha3.Size = new System.Drawing.Size(89, 39);
            this.lblfecha3.TabIndex = 2;
            this.lblfecha3.Text = "(8:19 pm)";
            this.lblfecha3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Panel32
            // 
            this.Panel32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.Panel32.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel32.Location = new System.Drawing.Point(0, 0);
            this.Panel32.Name = "Panel32";
            this.Panel32.Size = new System.Drawing.Size(245, 1);
            this.Panel32.TabIndex = 4;
            // 
            // Panel33
            // 
            this.Panel33.Controls.Add(this.lblMozo3);
            this.Panel33.Controls.Add(this.Label5);
            this.Panel33.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel33.Location = new System.Drawing.Point(0, 35);
            this.Panel33.Name = "Panel33";
            this.Panel33.Size = new System.Drawing.Size(245, 43);
            this.Panel33.TabIndex = 2;
            // 
            // lblMozo3
            // 
            this.lblMozo3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMozo3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMozo3.ForeColor = System.Drawing.Color.White;
            this.lblMozo3.Location = new System.Drawing.Point(69, 0);
            this.lblMozo3.Name = "lblMozo3";
            this.lblMozo3.Size = new System.Drawing.Size(176, 43);
            this.lblMozo3.TabIndex = 3;
            this.lblMozo3.Text = "lblMozo";
            this.lblMozo3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label5
            // 
            this.Label5.Dock = System.Windows.Forms.DockStyle.Left;
            this.Label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label5.ForeColor = System.Drawing.Color.White;
            this.Label5.Location = new System.Drawing.Point(0, 0);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(69, 43);
            this.Label5.TabIndex = 2;
            this.Label5.Text = "Mozo:";
            this.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Panel34
            // 
            this.Panel34.Controls.Add(this.lblmesa3);
            this.Panel34.Controls.Add(this.etiquetamesa3);
            this.Panel34.Controls.Add(this.Panel35);
            this.Panel34.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel34.Location = new System.Drawing.Point(0, 0);
            this.Panel34.Name = "Panel34";
            this.Panel34.Size = new System.Drawing.Size(245, 35);
            this.Panel34.TabIndex = 1;
            // 
            // lblmesa3
            // 
            this.lblmesa3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblmesa3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmesa3.ForeColor = System.Drawing.Color.White;
            this.lblmesa3.Location = new System.Drawing.Point(69, 0);
            this.lblmesa3.Name = "lblmesa3";
            this.lblmesa3.Size = new System.Drawing.Size(176, 34);
            this.lblmesa3.TabIndex = 1;
            this.lblmesa3.Text = "Label6";
            this.lblmesa3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // etiquetamesa3
            // 
            this.etiquetamesa3.Dock = System.Windows.Forms.DockStyle.Left;
            this.etiquetamesa3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.etiquetamesa3.ForeColor = System.Drawing.Color.White;
            this.etiquetamesa3.Location = new System.Drawing.Point(0, 0);
            this.etiquetamesa3.Name = "etiquetamesa3";
            this.etiquetamesa3.Size = new System.Drawing.Size(69, 34);
            this.etiquetamesa3.TabIndex = 0;
            this.etiquetamesa3.Text = "MESA:";
            this.etiquetamesa3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Panel35
            // 
            this.Panel35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.Panel35.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.Panel35.Location = new System.Drawing.Point(0, 34);
            this.Panel35.Name = "Panel35";
            this.Panel35.Size = new System.Drawing.Size(245, 1);
            this.Panel35.TabIndex = 2;
            // 
            // P4
            // 
            this.P4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.P4.Controls.Add(this.datalistadoDetalledeventa4);
            this.P4.Controls.Add(this.panelm4);
            this.P4.Controls.Add(this.Panel37);
            this.P4.Controls.Add(this.Panel38);
            this.P4.Location = new System.Drawing.Point(3, 344);
            this.P4.Name = "P4";
            this.P4.Size = new System.Drawing.Size(377, 335);
            this.P4.TabIndex = 3;
            // 
            // datalistadoDetalledeventa4
            // 
            this.datalistadoDetalledeventa4.AllowUserToAddRows = false;
            this.datalistadoDetalledeventa4.AllowUserToDeleteRows = false;
            this.datalistadoDetalledeventa4.AllowUserToResizeRows = false;
            this.datalistadoDetalledeventa4.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.datalistadoDetalledeventa4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.datalistadoDetalledeventa4.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.datalistadoDetalledeventa4.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datalistadoDetalledeventa4.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.datalistadoDetalledeventa4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datalistadoDetalledeventa4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Accion4,
            this.Volver4});
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.datalistadoDetalledeventa4.DefaultCellStyle = dataGridViewCellStyle11;
            this.datalistadoDetalledeventa4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.datalistadoDetalledeventa4.Location = new System.Drawing.Point(0, 154);
            this.datalistadoDetalledeventa4.Name = "datalistadoDetalledeventa4";
            this.datalistadoDetalledeventa4.ReadOnly = true;
            this.datalistadoDetalledeventa4.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datalistadoDetalledeventa4.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.datalistadoDetalledeventa4.RowHeadersVisible = false;
            this.datalistadoDetalledeventa4.RowHeadersWidth = 5;
            this.datalistadoDetalledeventa4.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.datalistadoDetalledeventa4.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datalistadoDetalledeventa4.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.datalistadoDetalledeventa4.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Transparent;
            this.datalistadoDetalledeventa4.RowTemplate.Height = 30;
            this.datalistadoDetalledeventa4.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datalistadoDetalledeventa4.Size = new System.Drawing.Size(377, 142);
            this.datalistadoDetalledeventa4.TabIndex = 559;
            this.datalistadoDetalledeventa4.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datalistadoDetalledeventa4_CellClick);
            // 
            // Accion4
            // 
            this.Accion4.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Accion4.HeaderText = "";
            this.Accion4.Name = "Accion4";
            this.Accion4.ReadOnly = true;
            this.Accion4.Text = "Preparar";
            // 
            // Volver4
            // 
            this.Volver4.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Volver4.HeaderText = "";
            this.Volver4.LinkColor = System.Drawing.Color.White;
            this.Volver4.Name = "Volver4";
            this.Volver4.ReadOnly = true;
            // 
            // panelm4
            // 
            this.panelm4.AutoScroll = true;
            this.panelm4.Controls.Add(this.btnver4);
            this.panelm4.Controls.Add(this.label9);
            this.panelm4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelm4.Location = new System.Drawing.Point(0, 296);
            this.panelm4.Name = "panelm4";
            this.panelm4.Size = new System.Drawing.Size(377, 39);
            this.panelm4.TabIndex = 561;
            // 
            // btnver4
            // 
            this.btnver4.BackColor = System.Drawing.Color.Transparent;
            this.btnver4.BackgroundImage = global::RestCsharp.Properties.Resources.Rojo;
            this.btnver4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnver4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnver4.FlatAppearance.BorderSize = 0;
            this.btnver4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnver4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnver4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnver4.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnver4.ForeColor = System.Drawing.Color.White;
            this.btnver4.Location = new System.Drawing.Point(298, 0);
            this.btnver4.Name = "btnver4";
            this.btnver4.Size = new System.Drawing.Size(79, 39);
            this.btnver4.TabIndex = 637;
            this.btnver4.Text = "Ver";
            this.btnver4.UseVisualStyleBackColor = false;
            this.btnver4.Click += new System.EventHandler(this.btnver4_Click);
            // 
            // label9
            // 
            this.label9.Dock = System.Windows.Forms.DockStyle.Left;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.label9.Location = new System.Drawing.Point(0, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(298, 39);
            this.label9.TabIndex = 1;
            this.label9.Text = "!Hay nota!";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Panel37
            // 
            this.Panel37.Controls.Add(this.Button4);
            this.Panel37.Controls.Add(this.Button5);
            this.Panel37.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel37.Location = new System.Drawing.Point(0, 118);
            this.Panel37.Name = "Panel37";
            this.Panel37.Size = new System.Drawing.Size(377, 36);
            this.Panel37.TabIndex = 1;
            // 
            // Button4
            // 
            this.Button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.Button4.FlatAppearance.BorderSize = 0;
            this.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button4.ForeColor = System.Drawing.Color.White;
            this.Button4.Location = new System.Drawing.Point(147, 6);
            this.Button4.Name = "Button4";
            this.Button4.Size = new System.Drawing.Size(151, 25);
            this.Button4.TabIndex = 0;
            this.Button4.Text = "Despachar Todos";
            this.Button4.UseVisualStyleBackColor = false;
            this.Button4.Click += new System.EventHandler(this.Button4_Click);
            // 
            // Button5
            // 
            this.Button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.Button5.FlatAppearance.BorderSize = 0;
            this.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button5.ForeColor = System.Drawing.Color.White;
            this.Button5.Location = new System.Drawing.Point(4, 6);
            this.Button5.Name = "Button5";
            this.Button5.Size = new System.Drawing.Size(137, 25);
            this.Button5.TabIndex = 0;
            this.Button5.Text = "Preparar Todos";
            this.Button5.UseVisualStyleBackColor = false;
            this.Button5.Click += new System.EventHandler(this.Button5_Click);
            // 
            // Panel38
            // 
            this.Panel38.Controls.Add(this.Panel39);
            this.Panel38.Controls.Add(this.Panel42);
            this.Panel38.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel38.Location = new System.Drawing.Point(0, 0);
            this.Panel38.Name = "Panel38";
            this.Panel38.Size = new System.Drawing.Size(377, 118);
            this.Panel38.TabIndex = 0;
            // 
            // Panel39
            // 
            this.Panel39.Controls.Add(this.btnNPedido4);
            this.Panel39.Controls.Add(this.Panel40);
            this.Panel39.Controls.Add(this.Panel41);
            this.Panel39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Panel39.Location = new System.Drawing.Point(245, 0);
            this.Panel39.Name = "Panel39";
            this.Panel39.Size = new System.Drawing.Size(132, 118);
            this.Panel39.TabIndex = 3;
            // 
            // btnNPedido4
            // 
            this.btnNPedido4.BackColor = System.Drawing.Color.Transparent;
            this.btnNPedido4.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.btnNPedido4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnNPedido4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnNPedido4.FlatAppearance.BorderSize = 0;
            this.btnNPedido4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnNPedido4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnNPedido4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNPedido4.Font = new System.Drawing.Font("Segoe UI", 57F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNPedido4.ForeColor = System.Drawing.Color.White;
            this.btnNPedido4.Location = new System.Drawing.Point(0, 10);
            this.btnNPedido4.Name = "btnNPedido4";
            this.btnNPedido4.Size = new System.Drawing.Size(122, 108);
            this.btnNPedido4.TabIndex = 637;
            this.btnNPedido4.Text = "4";
            this.btnNPedido4.UseVisualStyleBackColor = false;
            // 
            // Panel40
            // 
            this.Panel40.Dock = System.Windows.Forms.DockStyle.Right;
            this.Panel40.Location = new System.Drawing.Point(122, 10);
            this.Panel40.Name = "Panel40";
            this.Panel40.Size = new System.Drawing.Size(10, 108);
            this.Panel40.TabIndex = 1;
            // 
            // Panel41
            // 
            this.Panel41.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel41.Location = new System.Drawing.Point(0, 0);
            this.Panel41.Name = "Panel41";
            this.Panel41.Size = new System.Drawing.Size(132, 10);
            this.Panel41.TabIndex = 0;
            // 
            // Panel42
            // 
            this.Panel42.Controls.Add(this.Panel43);
            this.Panel42.Controls.Add(this.Panel45);
            this.Panel42.Controls.Add(this.Panel46);
            this.Panel42.Dock = System.Windows.Forms.DockStyle.Left;
            this.Panel42.Location = new System.Drawing.Point(0, 0);
            this.Panel42.Name = "Panel42";
            this.Panel42.Size = new System.Drawing.Size(245, 118);
            this.Panel42.TabIndex = 560;
            // 
            // Panel43
            // 
            this.Panel43.Controls.Add(this.lblminutos4);
            this.Panel43.Controls.Add(this.lblfecha4);
            this.Panel43.Controls.Add(this.Panel44);
            this.Panel43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Panel43.Location = new System.Drawing.Point(0, 78);
            this.Panel43.Name = "Panel43";
            this.Panel43.Size = new System.Drawing.Size(245, 40);
            this.Panel43.TabIndex = 3;
            // 
            // lblminutos4
            // 
            this.lblminutos4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblminutos4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblminutos4.ForeColor = System.Drawing.Color.White;
            this.lblminutos4.Location = new System.Drawing.Point(89, 1);
            this.lblminutos4.Name = "lblminutos4";
            this.lblminutos4.Size = new System.Drawing.Size(156, 39);
            this.lblminutos4.TabIndex = 3;
            this.lblminutos4.Text = "15 minutos";
            this.lblminutos4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblfecha4
            // 
            this.lblfecha4.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblfecha4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfecha4.ForeColor = System.Drawing.Color.White;
            this.lblfecha4.Location = new System.Drawing.Point(0, 1);
            this.lblfecha4.Name = "lblfecha4";
            this.lblfecha4.Size = new System.Drawing.Size(89, 39);
            this.lblfecha4.TabIndex = 2;
            this.lblfecha4.Text = "(8:19 pm)";
            this.lblfecha4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Panel44
            // 
            this.Panel44.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.Panel44.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel44.Location = new System.Drawing.Point(0, 0);
            this.Panel44.Name = "Panel44";
            this.Panel44.Size = new System.Drawing.Size(245, 1);
            this.Panel44.TabIndex = 4;
            // 
            // Panel45
            // 
            this.Panel45.Controls.Add(this.lblMozo4);
            this.Panel45.Controls.Add(this.Label13);
            this.Panel45.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel45.Location = new System.Drawing.Point(0, 35);
            this.Panel45.Name = "Panel45";
            this.Panel45.Size = new System.Drawing.Size(245, 43);
            this.Panel45.TabIndex = 2;
            // 
            // lblMozo4
            // 
            this.lblMozo4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMozo4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMozo4.ForeColor = System.Drawing.Color.White;
            this.lblMozo4.Location = new System.Drawing.Point(69, 0);
            this.lblMozo4.Name = "lblMozo4";
            this.lblMozo4.Size = new System.Drawing.Size(176, 43);
            this.lblMozo4.TabIndex = 3;
            this.lblMozo4.Text = "Label12";
            this.lblMozo4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label13
            // 
            this.Label13.Dock = System.Windows.Forms.DockStyle.Left;
            this.Label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label13.ForeColor = System.Drawing.Color.White;
            this.Label13.Location = new System.Drawing.Point(0, 0);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(69, 43);
            this.Label13.TabIndex = 2;
            this.Label13.Text = "Mozo:";
            this.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Panel46
            // 
            this.Panel46.Controls.Add(this.lblmesa4);
            this.Panel46.Controls.Add(this.etiquetamesa4);
            this.Panel46.Controls.Add(this.Panel47);
            this.Panel46.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel46.Location = new System.Drawing.Point(0, 0);
            this.Panel46.Name = "Panel46";
            this.Panel46.Size = new System.Drawing.Size(245, 35);
            this.Panel46.TabIndex = 1;
            // 
            // lblmesa4
            // 
            this.lblmesa4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblmesa4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmesa4.ForeColor = System.Drawing.Color.White;
            this.lblmesa4.Location = new System.Drawing.Point(69, 0);
            this.lblmesa4.Name = "lblmesa4";
            this.lblmesa4.Size = new System.Drawing.Size(176, 34);
            this.lblmesa4.TabIndex = 1;
            this.lblmesa4.Text = "Label14";
            this.lblmesa4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // etiquetamesa4
            // 
            this.etiquetamesa4.Dock = System.Windows.Forms.DockStyle.Left;
            this.etiquetamesa4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.etiquetamesa4.ForeColor = System.Drawing.Color.White;
            this.etiquetamesa4.Location = new System.Drawing.Point(0, 0);
            this.etiquetamesa4.Name = "etiquetamesa4";
            this.etiquetamesa4.Size = new System.Drawing.Size(69, 34);
            this.etiquetamesa4.TabIndex = 0;
            this.etiquetamesa4.Text = "MESA:";
            this.etiquetamesa4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Panel47
            // 
            this.Panel47.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.Panel47.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.Panel47.Location = new System.Drawing.Point(0, 34);
            this.Panel47.Name = "Panel47";
            this.Panel47.Size = new System.Drawing.Size(245, 1);
            this.Panel47.TabIndex = 2;
            // 
            // P5
            // 
            this.P5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.P5.Controls.Add(this.datalistadoDetalledeventa5);
            this.P5.Controls.Add(this.panelm5);
            this.P5.Controls.Add(this.Panel49);
            this.P5.Controls.Add(this.Panel50);
            this.P5.Location = new System.Drawing.Point(386, 344);
            this.P5.Name = "P5";
            this.P5.Size = new System.Drawing.Size(377, 335);
            this.P5.TabIndex = 4;
            // 
            // datalistadoDetalledeventa5
            // 
            this.datalistadoDetalledeventa5.AllowUserToAddRows = false;
            this.datalistadoDetalledeventa5.AllowUserToDeleteRows = false;
            this.datalistadoDetalledeventa5.AllowUserToResizeRows = false;
            this.datalistadoDetalledeventa5.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.datalistadoDetalledeventa5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.datalistadoDetalledeventa5.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.datalistadoDetalledeventa5.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datalistadoDetalledeventa5.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.datalistadoDetalledeventa5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datalistadoDetalledeventa5.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Accion5,
            this.Volver5});
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.datalistadoDetalledeventa5.DefaultCellStyle = dataGridViewCellStyle14;
            this.datalistadoDetalledeventa5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.datalistadoDetalledeventa5.Location = new System.Drawing.Point(0, 154);
            this.datalistadoDetalledeventa5.Name = "datalistadoDetalledeventa5";
            this.datalistadoDetalledeventa5.ReadOnly = true;
            this.datalistadoDetalledeventa5.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datalistadoDetalledeventa5.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.datalistadoDetalledeventa5.RowHeadersVisible = false;
            this.datalistadoDetalledeventa5.RowHeadersWidth = 5;
            this.datalistadoDetalledeventa5.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.datalistadoDetalledeventa5.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datalistadoDetalledeventa5.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.datalistadoDetalledeventa5.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Transparent;
            this.datalistadoDetalledeventa5.RowTemplate.Height = 30;
            this.datalistadoDetalledeventa5.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datalistadoDetalledeventa5.Size = new System.Drawing.Size(377, 142);
            this.datalistadoDetalledeventa5.TabIndex = 559;
            this.datalistadoDetalledeventa5.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datalistadoDetalledeventa5_CellClick);
            // 
            // Accion5
            // 
            this.Accion5.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Accion5.HeaderText = "";
            this.Accion5.Name = "Accion5";
            this.Accion5.ReadOnly = true;
            this.Accion5.Text = "Preparar";
            // 
            // Volver5
            // 
            this.Volver5.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Volver5.HeaderText = "";
            this.Volver5.LinkColor = System.Drawing.Color.White;
            this.Volver5.Name = "Volver5";
            this.Volver5.ReadOnly = true;
            // 
            // panelm5
            // 
            this.panelm5.AutoScroll = true;
            this.panelm5.Controls.Add(this.btnver5);
            this.panelm5.Controls.Add(this.label7);
            this.panelm5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelm5.Location = new System.Drawing.Point(0, 296);
            this.panelm5.Name = "panelm5";
            this.panelm5.Size = new System.Drawing.Size(377, 39);
            this.panelm5.TabIndex = 561;
            // 
            // btnver5
            // 
            this.btnver5.BackColor = System.Drawing.Color.Transparent;
            this.btnver5.BackgroundImage = global::RestCsharp.Properties.Resources.Rojo;
            this.btnver5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnver5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnver5.FlatAppearance.BorderSize = 0;
            this.btnver5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnver5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnver5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnver5.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnver5.ForeColor = System.Drawing.Color.White;
            this.btnver5.Location = new System.Drawing.Point(298, 0);
            this.btnver5.Name = "btnver5";
            this.btnver5.Size = new System.Drawing.Size(79, 39);
            this.btnver5.TabIndex = 637;
            this.btnver5.Text = "Ver";
            this.btnver5.UseVisualStyleBackColor = false;
            this.btnver5.Click += new System.EventHandler(this.btnver5_Click);
            // 
            // label7
            // 
            this.label7.Dock = System.Windows.Forms.DockStyle.Left;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.label7.Location = new System.Drawing.Point(0, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(298, 39);
            this.label7.TabIndex = 1;
            this.label7.Text = "!Hay nota!";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Panel49
            // 
            this.Panel49.Controls.Add(this.Button7);
            this.Panel49.Controls.Add(this.Button8);
            this.Panel49.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel49.Location = new System.Drawing.Point(0, 118);
            this.Panel49.Name = "Panel49";
            this.Panel49.Size = new System.Drawing.Size(377, 36);
            this.Panel49.TabIndex = 1;
            // 
            // Button7
            // 
            this.Button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.Button7.FlatAppearance.BorderSize = 0;
            this.Button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button7.ForeColor = System.Drawing.Color.White;
            this.Button7.Location = new System.Drawing.Point(147, 6);
            this.Button7.Name = "Button7";
            this.Button7.Size = new System.Drawing.Size(151, 25);
            this.Button7.TabIndex = 0;
            this.Button7.Text = "Despachar Todos";
            this.Button7.UseVisualStyleBackColor = false;
            this.Button7.Click += new System.EventHandler(this.Button7_Click);
            // 
            // Button8
            // 
            this.Button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.Button8.FlatAppearance.BorderSize = 0;
            this.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button8.ForeColor = System.Drawing.Color.White;
            this.Button8.Location = new System.Drawing.Point(4, 6);
            this.Button8.Name = "Button8";
            this.Button8.Size = new System.Drawing.Size(137, 25);
            this.Button8.TabIndex = 0;
            this.Button8.Text = "Preparar Todos";
            this.Button8.UseVisualStyleBackColor = false;
            this.Button8.Click += new System.EventHandler(this.Button8_Click);
            // 
            // Panel50
            // 
            this.Panel50.Controls.Add(this.Panel51);
            this.Panel50.Controls.Add(this.Panel54);
            this.Panel50.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel50.Location = new System.Drawing.Point(0, 0);
            this.Panel50.Name = "Panel50";
            this.Panel50.Size = new System.Drawing.Size(377, 118);
            this.Panel50.TabIndex = 0;
            // 
            // Panel51
            // 
            this.Panel51.Controls.Add(this.btnNPedido5);
            this.Panel51.Controls.Add(this.Panel52);
            this.Panel51.Controls.Add(this.Panel53);
            this.Panel51.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Panel51.Location = new System.Drawing.Point(245, 0);
            this.Panel51.Name = "Panel51";
            this.Panel51.Size = new System.Drawing.Size(132, 118);
            this.Panel51.TabIndex = 3;
            // 
            // btnNPedido5
            // 
            this.btnNPedido5.BackColor = System.Drawing.Color.Transparent;
            this.btnNPedido5.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.btnNPedido5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnNPedido5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnNPedido5.FlatAppearance.BorderSize = 0;
            this.btnNPedido5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnNPedido5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnNPedido5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNPedido5.Font = new System.Drawing.Font("Segoe UI", 57F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNPedido5.ForeColor = System.Drawing.Color.White;
            this.btnNPedido5.Location = new System.Drawing.Point(0, 10);
            this.btnNPedido5.Name = "btnNPedido5";
            this.btnNPedido5.Size = new System.Drawing.Size(122, 108);
            this.btnNPedido5.TabIndex = 636;
            this.btnNPedido5.Text = "5";
            this.btnNPedido5.UseVisualStyleBackColor = false;
            // 
            // Panel52
            // 
            this.Panel52.Dock = System.Windows.Forms.DockStyle.Right;
            this.Panel52.Location = new System.Drawing.Point(122, 10);
            this.Panel52.Name = "Panel52";
            this.Panel52.Size = new System.Drawing.Size(10, 108);
            this.Panel52.TabIndex = 1;
            // 
            // Panel53
            // 
            this.Panel53.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel53.Location = new System.Drawing.Point(0, 0);
            this.Panel53.Name = "Panel53";
            this.Panel53.Size = new System.Drawing.Size(132, 10);
            this.Panel53.TabIndex = 0;
            // 
            // Panel54
            // 
            this.Panel54.Controls.Add(this.Panel55);
            this.Panel54.Controls.Add(this.Panel57);
            this.Panel54.Controls.Add(this.Panel58);
            this.Panel54.Dock = System.Windows.Forms.DockStyle.Left;
            this.Panel54.Location = new System.Drawing.Point(0, 0);
            this.Panel54.Name = "Panel54";
            this.Panel54.Size = new System.Drawing.Size(245, 118);
            this.Panel54.TabIndex = 560;
            // 
            // Panel55
            // 
            this.Panel55.Controls.Add(this.lblminutos5);
            this.Panel55.Controls.Add(this.lblfecha5);
            this.Panel55.Controls.Add(this.Panel56);
            this.Panel55.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Panel55.Location = new System.Drawing.Point(0, 78);
            this.Panel55.Name = "Panel55";
            this.Panel55.Size = new System.Drawing.Size(245, 40);
            this.Panel55.TabIndex = 3;
            // 
            // lblminutos5
            // 
            this.lblminutos5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblminutos5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblminutos5.ForeColor = System.Drawing.Color.White;
            this.lblminutos5.Location = new System.Drawing.Point(89, 1);
            this.lblminutos5.Name = "lblminutos5";
            this.lblminutos5.Size = new System.Drawing.Size(156, 39);
            this.lblminutos5.TabIndex = 3;
            this.lblminutos5.Text = "15 minutos";
            this.lblminutos5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblfecha5
            // 
            this.lblfecha5.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblfecha5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfecha5.ForeColor = System.Drawing.Color.White;
            this.lblfecha5.Location = new System.Drawing.Point(0, 1);
            this.lblfecha5.Name = "lblfecha5";
            this.lblfecha5.Size = new System.Drawing.Size(89, 39);
            this.lblfecha5.TabIndex = 2;
            this.lblfecha5.Text = "(8:19 pm)";
            this.lblfecha5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Panel56
            // 
            this.Panel56.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.Panel56.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel56.Location = new System.Drawing.Point(0, 0);
            this.Panel56.Name = "Panel56";
            this.Panel56.Size = new System.Drawing.Size(245, 1);
            this.Panel56.TabIndex = 4;
            // 
            // Panel57
            // 
            this.Panel57.Controls.Add(this.lblMozo5);
            this.Panel57.Controls.Add(this.Label19);
            this.Panel57.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel57.Location = new System.Drawing.Point(0, 35);
            this.Panel57.Name = "Panel57";
            this.Panel57.Size = new System.Drawing.Size(245, 43);
            this.Panel57.TabIndex = 2;
            // 
            // lblMozo5
            // 
            this.lblMozo5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMozo5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMozo5.ForeColor = System.Drawing.Color.White;
            this.lblMozo5.Location = new System.Drawing.Point(69, 0);
            this.lblMozo5.Name = "lblMozo5";
            this.lblMozo5.Size = new System.Drawing.Size(176, 43);
            this.lblMozo5.TabIndex = 3;
            this.lblMozo5.Text = "lblMozo";
            this.lblMozo5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label19
            // 
            this.Label19.Dock = System.Windows.Forms.DockStyle.Left;
            this.Label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label19.ForeColor = System.Drawing.Color.White;
            this.Label19.Location = new System.Drawing.Point(0, 0);
            this.Label19.Name = "Label19";
            this.Label19.Size = new System.Drawing.Size(69, 43);
            this.Label19.TabIndex = 2;
            this.Label19.Text = "Mozo:";
            this.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Panel58
            // 
            this.Panel58.Controls.Add(this.lblmesa5);
            this.Panel58.Controls.Add(this.etiquetamesa5);
            this.Panel58.Controls.Add(this.Panel59);
            this.Panel58.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel58.Location = new System.Drawing.Point(0, 0);
            this.Panel58.Name = "Panel58";
            this.Panel58.Size = new System.Drawing.Size(245, 35);
            this.Panel58.TabIndex = 1;
            // 
            // lblmesa5
            // 
            this.lblmesa5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblmesa5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmesa5.ForeColor = System.Drawing.Color.White;
            this.lblmesa5.Location = new System.Drawing.Point(69, 0);
            this.lblmesa5.Name = "lblmesa5";
            this.lblmesa5.Size = new System.Drawing.Size(176, 34);
            this.lblmesa5.TabIndex = 1;
            this.lblmesa5.Text = "Label20";
            this.lblmesa5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // etiquetamesa5
            // 
            this.etiquetamesa5.Dock = System.Windows.Forms.DockStyle.Left;
            this.etiquetamesa5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.etiquetamesa5.ForeColor = System.Drawing.Color.White;
            this.etiquetamesa5.Location = new System.Drawing.Point(0, 0);
            this.etiquetamesa5.Name = "etiquetamesa5";
            this.etiquetamesa5.Size = new System.Drawing.Size(69, 34);
            this.etiquetamesa5.TabIndex = 0;
            this.etiquetamesa5.Text = "MESA:";
            this.etiquetamesa5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Panel59
            // 
            this.Panel59.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.Panel59.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.Panel59.Location = new System.Drawing.Point(0, 34);
            this.Panel59.Name = "Panel59";
            this.Panel59.Size = new System.Drawing.Size(245, 1);
            this.Panel59.TabIndex = 2;
            // 
            // P6
            // 
            this.P6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.P6.Controls.Add(this.datalistadoDetalledeventa6);
            this.P6.Controls.Add(this.panelm6);
            this.P6.Controls.Add(this.Panel61);
            this.P6.Controls.Add(this.Panel62);
            this.P6.Location = new System.Drawing.Point(769, 344);
            this.P6.Name = "P6";
            this.P6.Size = new System.Drawing.Size(377, 335);
            this.P6.TabIndex = 5;
            // 
            // datalistadoDetalledeventa6
            // 
            this.datalistadoDetalledeventa6.AllowUserToAddRows = false;
            this.datalistadoDetalledeventa6.AllowUserToDeleteRows = false;
            this.datalistadoDetalledeventa6.AllowUserToResizeRows = false;
            this.datalistadoDetalledeventa6.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.datalistadoDetalledeventa6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.datalistadoDetalledeventa6.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.datalistadoDetalledeventa6.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datalistadoDetalledeventa6.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.datalistadoDetalledeventa6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datalistadoDetalledeventa6.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Accion6,
            this.Volver6});
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.datalistadoDetalledeventa6.DefaultCellStyle = dataGridViewCellStyle17;
            this.datalistadoDetalledeventa6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.datalistadoDetalledeventa6.Location = new System.Drawing.Point(0, 154);
            this.datalistadoDetalledeventa6.Name = "datalistadoDetalledeventa6";
            this.datalistadoDetalledeventa6.ReadOnly = true;
            this.datalistadoDetalledeventa6.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datalistadoDetalledeventa6.RowHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.datalistadoDetalledeventa6.RowHeadersVisible = false;
            this.datalistadoDetalledeventa6.RowHeadersWidth = 5;
            this.datalistadoDetalledeventa6.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.datalistadoDetalledeventa6.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datalistadoDetalledeventa6.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.datalistadoDetalledeventa6.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Transparent;
            this.datalistadoDetalledeventa6.RowTemplate.Height = 30;
            this.datalistadoDetalledeventa6.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datalistadoDetalledeventa6.Size = new System.Drawing.Size(377, 142);
            this.datalistadoDetalledeventa6.TabIndex = 562;
            this.datalistadoDetalledeventa6.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datalistadoDetalledeventa6_CellClick);
            // 
            // Accion6
            // 
            this.Accion6.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Accion6.HeaderText = "";
            this.Accion6.Name = "Accion6";
            this.Accion6.ReadOnly = true;
            this.Accion6.Text = "Preparar";
            // 
            // Volver6
            // 
            this.Volver6.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Volver6.HeaderText = "";
            this.Volver6.LinkColor = System.Drawing.Color.White;
            this.Volver6.Name = "Volver6";
            this.Volver6.ReadOnly = true;
            // 
            // panelm6
            // 
            this.panelm6.AutoScroll = true;
            this.panelm6.Controls.Add(this.btnver6);
            this.panelm6.Controls.Add(this.label6);
            this.panelm6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelm6.Location = new System.Drawing.Point(0, 296);
            this.panelm6.Name = "panelm6";
            this.panelm6.Size = new System.Drawing.Size(377, 39);
            this.panelm6.TabIndex = 561;
            // 
            // btnver6
            // 
            this.btnver6.BackColor = System.Drawing.Color.Transparent;
            this.btnver6.BackgroundImage = global::RestCsharp.Properties.Resources.Rojo;
            this.btnver6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnver6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnver6.FlatAppearance.BorderSize = 0;
            this.btnver6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnver6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnver6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnver6.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnver6.ForeColor = System.Drawing.Color.White;
            this.btnver6.Location = new System.Drawing.Point(298, 0);
            this.btnver6.Name = "btnver6";
            this.btnver6.Size = new System.Drawing.Size(79, 39);
            this.btnver6.TabIndex = 637;
            this.btnver6.Text = "Ver";
            this.btnver6.UseVisualStyleBackColor = false;
            this.btnver6.Click += new System.EventHandler(this.btnver6_Click);
            // 
            // label6
            // 
            this.label6.Dock = System.Windows.Forms.DockStyle.Left;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.label6.Location = new System.Drawing.Point(0, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(298, 39);
            this.label6.TabIndex = 1;
            this.label6.Text = "!Hay nota!";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Panel61
            // 
            this.Panel61.Controls.Add(this.Button10);
            this.Panel61.Controls.Add(this.Button11);
            this.Panel61.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel61.Location = new System.Drawing.Point(0, 118);
            this.Panel61.Name = "Panel61";
            this.Panel61.Size = new System.Drawing.Size(377, 36);
            this.Panel61.TabIndex = 1;
            // 
            // Button10
            // 
            this.Button10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.Button10.FlatAppearance.BorderSize = 0;
            this.Button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button10.ForeColor = System.Drawing.Color.White;
            this.Button10.Location = new System.Drawing.Point(147, 6);
            this.Button10.Name = "Button10";
            this.Button10.Size = new System.Drawing.Size(151, 25);
            this.Button10.TabIndex = 0;
            this.Button10.Text = "Despachar Todos";
            this.Button10.UseVisualStyleBackColor = false;
            this.Button10.Click += new System.EventHandler(this.Button10_Click);
            // 
            // Button11
            // 
            this.Button11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.Button11.FlatAppearance.BorderSize = 0;
            this.Button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Button11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button11.ForeColor = System.Drawing.Color.White;
            this.Button11.Location = new System.Drawing.Point(4, 6);
            this.Button11.Name = "Button11";
            this.Button11.Size = new System.Drawing.Size(137, 25);
            this.Button11.TabIndex = 0;
            this.Button11.Text = "Preparar Todos";
            this.Button11.UseVisualStyleBackColor = false;
            this.Button11.Click += new System.EventHandler(this.Button11_Click);
            // 
            // Panel62
            // 
            this.Panel62.Controls.Add(this.Panel63);
            this.Panel62.Controls.Add(this.Panel66);
            this.Panel62.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel62.Location = new System.Drawing.Point(0, 0);
            this.Panel62.Name = "Panel62";
            this.Panel62.Size = new System.Drawing.Size(377, 118);
            this.Panel62.TabIndex = 0;
            // 
            // Panel63
            // 
            this.Panel63.Controls.Add(this.btnNPedido6);
            this.Panel63.Controls.Add(this.Panel64);
            this.Panel63.Controls.Add(this.Panel65);
            this.Panel63.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Panel63.Location = new System.Drawing.Point(245, 0);
            this.Panel63.Name = "Panel63";
            this.Panel63.Size = new System.Drawing.Size(132, 118);
            this.Panel63.TabIndex = 3;
            // 
            // btnNPedido6
            // 
            this.btnNPedido6.BackColor = System.Drawing.Color.Transparent;
            this.btnNPedido6.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.btnNPedido6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnNPedido6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnNPedido6.FlatAppearance.BorderSize = 0;
            this.btnNPedido6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnNPedido6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnNPedido6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNPedido6.Font = new System.Drawing.Font("Segoe UI", 57F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNPedido6.ForeColor = System.Drawing.Color.White;
            this.btnNPedido6.Location = new System.Drawing.Point(0, 10);
            this.btnNPedido6.Name = "btnNPedido6";
            this.btnNPedido6.Size = new System.Drawing.Size(122, 108);
            this.btnNPedido6.TabIndex = 637;
            this.btnNPedido6.Text = "6";
            this.btnNPedido6.UseVisualStyleBackColor = false;
            // 
            // Panel64
            // 
            this.Panel64.Dock = System.Windows.Forms.DockStyle.Right;
            this.Panel64.Location = new System.Drawing.Point(122, 10);
            this.Panel64.Name = "Panel64";
            this.Panel64.Size = new System.Drawing.Size(10, 108);
            this.Panel64.TabIndex = 1;
            // 
            // Panel65
            // 
            this.Panel65.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel65.Location = new System.Drawing.Point(0, 0);
            this.Panel65.Name = "Panel65";
            this.Panel65.Size = new System.Drawing.Size(132, 10);
            this.Panel65.TabIndex = 0;
            // 
            // Panel66
            // 
            this.Panel66.Controls.Add(this.Panel67);
            this.Panel66.Controls.Add(this.Panel69);
            this.Panel66.Controls.Add(this.Panel70);
            this.Panel66.Dock = System.Windows.Forms.DockStyle.Left;
            this.Panel66.Location = new System.Drawing.Point(0, 0);
            this.Panel66.Name = "Panel66";
            this.Panel66.Size = new System.Drawing.Size(245, 118);
            this.Panel66.TabIndex = 560;
            // 
            // Panel67
            // 
            this.Panel67.Controls.Add(this.lblminutos6);
            this.Panel67.Controls.Add(this.lblfecha6);
            this.Panel67.Controls.Add(this.Panel68);
            this.Panel67.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Panel67.Location = new System.Drawing.Point(0, 78);
            this.Panel67.Name = "Panel67";
            this.Panel67.Size = new System.Drawing.Size(245, 40);
            this.Panel67.TabIndex = 3;
            // 
            // lblminutos6
            // 
            this.lblminutos6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblminutos6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblminutos6.ForeColor = System.Drawing.Color.White;
            this.lblminutos6.Location = new System.Drawing.Point(89, 1);
            this.lblminutos6.Name = "lblminutos6";
            this.lblminutos6.Size = new System.Drawing.Size(156, 39);
            this.lblminutos6.TabIndex = 3;
            this.lblminutos6.Text = "15 minutos";
            this.lblminutos6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblfecha6
            // 
            this.lblfecha6.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblfecha6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfecha6.ForeColor = System.Drawing.Color.White;
            this.lblfecha6.Location = new System.Drawing.Point(0, 1);
            this.lblfecha6.Name = "lblfecha6";
            this.lblfecha6.Size = new System.Drawing.Size(89, 39);
            this.lblfecha6.TabIndex = 2;
            this.lblfecha6.Text = "(8:19 pm)";
            this.lblfecha6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Panel68
            // 
            this.Panel68.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.Panel68.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel68.Location = new System.Drawing.Point(0, 0);
            this.Panel68.Name = "Panel68";
            this.Panel68.Size = new System.Drawing.Size(245, 1);
            this.Panel68.TabIndex = 4;
            // 
            // Panel69
            // 
            this.Panel69.Controls.Add(this.lblMozo6);
            this.Panel69.Controls.Add(this.Label25);
            this.Panel69.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel69.Location = new System.Drawing.Point(0, 35);
            this.Panel69.Name = "Panel69";
            this.Panel69.Size = new System.Drawing.Size(245, 43);
            this.Panel69.TabIndex = 2;
            // 
            // lblMozo6
            // 
            this.lblMozo6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMozo6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMozo6.ForeColor = System.Drawing.Color.White;
            this.lblMozo6.Location = new System.Drawing.Point(69, 0);
            this.lblMozo6.Name = "lblMozo6";
            this.lblMozo6.Size = new System.Drawing.Size(176, 43);
            this.lblMozo6.TabIndex = 3;
            this.lblMozo6.Text = "Label24";
            this.lblMozo6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label25
            // 
            this.Label25.Dock = System.Windows.Forms.DockStyle.Left;
            this.Label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label25.ForeColor = System.Drawing.Color.White;
            this.Label25.Location = new System.Drawing.Point(0, 0);
            this.Label25.Name = "Label25";
            this.Label25.Size = new System.Drawing.Size(69, 43);
            this.Label25.TabIndex = 2;
            this.Label25.Text = "Mozo:";
            this.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Panel70
            // 
            this.Panel70.Controls.Add(this.lblmesa6);
            this.Panel70.Controls.Add(this.etiquetamesa6);
            this.Panel70.Controls.Add(this.Panel71);
            this.Panel70.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel70.Location = new System.Drawing.Point(0, 0);
            this.Panel70.Name = "Panel70";
            this.Panel70.Size = new System.Drawing.Size(245, 35);
            this.Panel70.TabIndex = 1;
            // 
            // lblmesa6
            // 
            this.lblmesa6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblmesa6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmesa6.ForeColor = System.Drawing.Color.White;
            this.lblmesa6.Location = new System.Drawing.Point(69, 0);
            this.lblmesa6.Name = "lblmesa6";
            this.lblmesa6.Size = new System.Drawing.Size(176, 34);
            this.lblmesa6.TabIndex = 1;
            this.lblmesa6.Text = "Label26";
            this.lblmesa6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // etiquetamesa6
            // 
            this.etiquetamesa6.Dock = System.Windows.Forms.DockStyle.Left;
            this.etiquetamesa6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.etiquetamesa6.ForeColor = System.Drawing.Color.White;
            this.etiquetamesa6.Location = new System.Drawing.Point(0, 0);
            this.etiquetamesa6.Name = "etiquetamesa6";
            this.etiquetamesa6.Size = new System.Drawing.Size(69, 34);
            this.etiquetamesa6.TabIndex = 0;
            this.etiquetamesa6.Text = "MESA:";
            this.etiquetamesa6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Panel71
            // 
            this.Panel71.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.Panel71.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.Panel71.Location = new System.Drawing.Point(0, 34);
            this.Panel71.Name = "Panel71";
            this.Panel71.Size = new System.Drawing.Size(245, 1);
            this.Panel71.TabIndex = 2;
            // 
            // TimerP1
            // 
            this.TimerP1.Interval = 60000;
            this.TimerP1.Tick += new System.EventHandler(this.TimerP1_Tick);
            // 
            // TimerP2
            // 
            this.TimerP2.Interval = 60000;
            this.TimerP2.Tick += new System.EventHandler(this.TimerP2_Tick);
            // 
            // TimerP3
            // 
            this.TimerP3.Interval = 60000;
            this.TimerP3.Tick += new System.EventHandler(this.TimerP3_Tick);
            // 
            // TimerP4
            // 
            this.TimerP4.Interval = 60000;
            this.TimerP4.Tick += new System.EventHandler(this.TimerP4_Tick);
            // 
            // TimerP5
            // 
            this.TimerP5.Interval = 60000;
            this.TimerP5.Tick += new System.EventHandler(this.TimerP5_Tick);
            // 
            // TimerP6
            // 
            this.TimerP6.Interval = 60000;
            this.TimerP6.Tick += new System.EventHandler(this.TimerP6_Tick);
            // 
            // TimerActualizador
            // 
            this.TimerActualizador.Interval = 60000;
            this.TimerActualizador.Tick += new System.EventHandler(this.TimerActualizador_Tick);
            // 
            // TimerNUEVOSPEDIDOS
            // 
            this.TimerNUEVOSPEDIDOS.Tick += new System.EventHandler(this.TimerNUEVOSPEDIDOS_Tick);
            // 
            // PantallaCocina
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
            this.ClientSize = new System.Drawing.Size(1403, 816);
            this.Controls.Add(this.FlowLayoutPanel1);
            this.Controls.Add(this.PSinpedidos);
            this.Controls.Add(this.Panel73);
            this.Controls.Add(this.Panel75);
            this.Controls.Add(this.Panel74);
            this.Controls.Add(this.Panel72);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "PantallaCocina";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pantalla Cocina";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.PantallaCocina_Load);
            this.PSinpedidos.ResumeLayout(false);
            this.FlowLayoutPanel1.ResumeLayout(false);
            this.P1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.datalistadoDetalledeventa1)).EndInit();
            this.panelm1.ResumeLayout(false);
            this.Panel6.ResumeLayout(false);
            this.Panel2.ResumeLayout(false);
            this.Panel5.ResumeLayout(false);
            this.Panel7.ResumeLayout(false);
            this.Panel8.ResumeLayout(false);
            this.Panel4.ResumeLayout(false);
            this.Panel3.ResumeLayout(false);
            this.P2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.datalistadoDetalledeventa2)).EndInit();
            this.panelm2.ResumeLayout(false);
            this.Panel14.ResumeLayout(false);
            this.Panel15.ResumeLayout(false);
            this.Panel16.ResumeLayout(false);
            this.Panel19.ResumeLayout(false);
            this.Panel20.ResumeLayout(false);
            this.Panel22.ResumeLayout(false);
            this.Panel23.ResumeLayout(false);
            this.P3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.datalistadoDetalledeventa3)).EndInit();
            this.panelm3.ResumeLayout(false);
            this.Panel25.ResumeLayout(false);
            this.Panel26.ResumeLayout(false);
            this.Panel27.ResumeLayout(false);
            this.Panel30.ResumeLayout(false);
            this.Panel31.ResumeLayout(false);
            this.Panel33.ResumeLayout(false);
            this.Panel34.ResumeLayout(false);
            this.P4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.datalistadoDetalledeventa4)).EndInit();
            this.panelm4.ResumeLayout(false);
            this.Panel37.ResumeLayout(false);
            this.Panel38.ResumeLayout(false);
            this.Panel39.ResumeLayout(false);
            this.Panel42.ResumeLayout(false);
            this.Panel43.ResumeLayout(false);
            this.Panel45.ResumeLayout(false);
            this.Panel46.ResumeLayout(false);
            this.P5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.datalistadoDetalledeventa5)).EndInit();
            this.panelm5.ResumeLayout(false);
            this.Panel49.ResumeLayout(false);
            this.Panel50.ResumeLayout(false);
            this.Panel51.ResumeLayout(false);
            this.Panel54.ResumeLayout(false);
            this.Panel55.ResumeLayout(false);
            this.Panel57.ResumeLayout(false);
            this.Panel58.ResumeLayout(false);
            this.P6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.datalistadoDetalledeventa6)).EndInit();
            this.panelm6.ResumeLayout(false);
            this.Panel61.ResumeLayout(false);
            this.Panel62.ResumeLayout(false);
            this.Panel63.ResumeLayout(false);
            this.Panel66.ResumeLayout(false);
            this.Panel67.ResumeLayout(false);
            this.Panel69.ResumeLayout(false);
            this.Panel70.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Panel Panel72;
        internal System.Windows.Forms.Panel Panel74;
        internal System.Windows.Forms.Panel Panel75;
        internal System.Windows.Forms.Panel Panel73;
        internal System.Windows.Forms.Panel PSinpedidos;
        internal System.Windows.Forms.Label Label11;
        internal System.Windows.Forms.FlowLayoutPanel FlowLayoutPanel1;
        internal System.Windows.Forms.Panel P1;
        public System.Windows.Forms.DataGridView datalistadoDetalledeventa1;
        internal System.Windows.Forms.DataGridViewButtonColumn Accion1;
        internal System.Windows.Forms.DataGridViewLinkColumn Volver1;
        private System.Windows.Forms.Panel panelm1;
        internal System.Windows.Forms.Button btnVer1;
        internal System.Windows.Forms.Label label1;
        internal System.Windows.Forms.Panel Panel6;
        internal System.Windows.Forms.Button btnDespacharTodos1;
        internal System.Windows.Forms.Button btnPrepararTodos1;
        internal System.Windows.Forms.Panel Panel2;
        internal System.Windows.Forms.Panel Panel5;
        internal System.Windows.Forms.Button btnNPedido1;
        internal System.Windows.Forms.Panel Panel10;
        internal System.Windows.Forms.Panel Panel9;
        internal System.Windows.Forms.Panel Panel7;
        internal System.Windows.Forms.Panel Panel8;
        internal System.Windows.Forms.Label lblminutos1;
        internal System.Windows.Forms.Label lblfecha1;
        internal System.Windows.Forms.Panel Panel13;
        internal System.Windows.Forms.Panel Panel4;
        internal System.Windows.Forms.Label lblMozo1;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Panel Panel3;
        internal System.Windows.Forms.Label lblmesa1;
        internal System.Windows.Forms.Label etiquetamesa1;
        internal System.Windows.Forms.Panel Panel12;
        internal System.Windows.Forms.Panel P2;
        public System.Windows.Forms.DataGridView datalistadoDetalledeventa2;
        private System.Windows.Forms.Panel panelm2;
        internal System.Windows.Forms.Button btnver2;
        internal System.Windows.Forms.Label label2;
        internal System.Windows.Forms.Panel Panel14;
        internal System.Windows.Forms.Button btnDespacharTodos2;
        internal System.Windows.Forms.Button btnPrepararTodos2;
        internal System.Windows.Forms.Panel Panel15;
        internal System.Windows.Forms.Panel Panel16;
        internal System.Windows.Forms.Button btnNPedido2;
        internal System.Windows.Forms.Panel Panel17;
        internal System.Windows.Forms.Panel Panel18;
        internal System.Windows.Forms.Panel Panel19;
        internal System.Windows.Forms.Panel Panel20;
        internal System.Windows.Forms.Label lblminutos2;
        internal System.Windows.Forms.Label lblfecha2;
        internal System.Windows.Forms.Panel Panel21;
        internal System.Windows.Forms.Panel Panel22;
        internal System.Windows.Forms.Label lblMozo2;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.Panel Panel23;
        internal System.Windows.Forms.Label lblmesa2;
        internal System.Windows.Forms.Label etiquetamesa2;
        internal System.Windows.Forms.Panel Panel24;
        internal System.Windows.Forms.Panel P3;
        public System.Windows.Forms.DataGridView datalistadoDetalledeventa3;
        private System.Windows.Forms.Panel panelm3;
        internal System.Windows.Forms.Button btnver3;
        internal System.Windows.Forms.Label label4;
        internal System.Windows.Forms.Panel Panel25;
        internal System.Windows.Forms.Button Button1;
        internal System.Windows.Forms.Button Button2;
        internal System.Windows.Forms.Panel Panel26;
        internal System.Windows.Forms.Panel Panel27;
        internal System.Windows.Forms.Button btnNPedido3;
        internal System.Windows.Forms.Panel Panel28;
        internal System.Windows.Forms.Panel Panel29;
        internal System.Windows.Forms.Panel Panel30;
        internal System.Windows.Forms.Panel Panel31;
        internal System.Windows.Forms.Label lblminutos3;
        internal System.Windows.Forms.Label lblfecha3;
        internal System.Windows.Forms.Panel Panel32;
        internal System.Windows.Forms.Panel Panel33;
        internal System.Windows.Forms.Label lblMozo3;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Panel Panel34;
        internal System.Windows.Forms.Label lblmesa3;
        internal System.Windows.Forms.Label etiquetamesa3;
        internal System.Windows.Forms.Panel Panel35;
        internal System.Windows.Forms.Panel P4;
        public System.Windows.Forms.DataGridView datalistadoDetalledeventa4;
        private System.Windows.Forms.Panel panelm4;
        internal System.Windows.Forms.Button btnver4;
        internal System.Windows.Forms.Label label9;
        internal System.Windows.Forms.Panel Panel37;
        internal System.Windows.Forms.Button Button4;
        internal System.Windows.Forms.Button Button5;
        internal System.Windows.Forms.Panel Panel38;
        internal System.Windows.Forms.Panel Panel39;
        internal System.Windows.Forms.Button btnNPedido4;
        internal System.Windows.Forms.Panel Panel40;
        internal System.Windows.Forms.Panel Panel41;
        internal System.Windows.Forms.Panel Panel42;
        internal System.Windows.Forms.Panel Panel43;
        internal System.Windows.Forms.Label lblminutos4;
        internal System.Windows.Forms.Label lblfecha4;
        internal System.Windows.Forms.Panel Panel44;
        internal System.Windows.Forms.Panel Panel45;
        internal System.Windows.Forms.Label lblMozo4;
        internal System.Windows.Forms.Label Label13;
        internal System.Windows.Forms.Panel Panel46;
        internal System.Windows.Forms.Label lblmesa4;
        internal System.Windows.Forms.Label etiquetamesa4;
        internal System.Windows.Forms.Panel Panel47;
        internal System.Windows.Forms.Panel P5;
        public System.Windows.Forms.DataGridView datalistadoDetalledeventa5;
        private System.Windows.Forms.Panel panelm5;
        internal System.Windows.Forms.Button btnver5;
        internal System.Windows.Forms.Label label7;
        internal System.Windows.Forms.Panel Panel49;
        internal System.Windows.Forms.Button Button7;
        internal System.Windows.Forms.Button Button8;
        internal System.Windows.Forms.Panel Panel50;
        internal System.Windows.Forms.Panel Panel51;
        internal System.Windows.Forms.Button btnNPedido5;
        internal System.Windows.Forms.Panel Panel52;
        internal System.Windows.Forms.Panel Panel53;
        internal System.Windows.Forms.Panel Panel54;
        internal System.Windows.Forms.Panel Panel55;
        internal System.Windows.Forms.Label lblminutos5;
        internal System.Windows.Forms.Label lblfecha5;
        internal System.Windows.Forms.Panel Panel56;
        internal System.Windows.Forms.Panel Panel57;
        internal System.Windows.Forms.Label lblMozo5;
        internal System.Windows.Forms.Label Label19;
        internal System.Windows.Forms.Panel Panel58;
        internal System.Windows.Forms.Label lblmesa5;
        internal System.Windows.Forms.Label etiquetamesa5;
        internal System.Windows.Forms.Panel Panel59;
        internal System.Windows.Forms.Panel P6;
        private System.Windows.Forms.Panel panelm6;
        internal System.Windows.Forms.Button btnver6;
        internal System.Windows.Forms.Label label6;
        internal System.Windows.Forms.Panel Panel61;
        internal System.Windows.Forms.Button Button10;
        internal System.Windows.Forms.Button Button11;
        internal System.Windows.Forms.Panel Panel62;
        internal System.Windows.Forms.Panel Panel63;
        internal System.Windows.Forms.Button btnNPedido6;
        internal System.Windows.Forms.Panel Panel64;
        internal System.Windows.Forms.Panel Panel65;
        internal System.Windows.Forms.Panel Panel66;
        internal System.Windows.Forms.Panel Panel67;
        internal System.Windows.Forms.Label lblminutos6;
        internal System.Windows.Forms.Label lblfecha6;
        internal System.Windows.Forms.Panel Panel68;
        internal System.Windows.Forms.Panel Panel69;
        internal System.Windows.Forms.Label lblMozo6;
        internal System.Windows.Forms.Label Label25;
        internal System.Windows.Forms.Panel Panel70;
        internal System.Windows.Forms.Label lblmesa6;
        internal System.Windows.Forms.Label etiquetamesa6;
        internal System.Windows.Forms.Panel Panel71;
        private System.Windows.Forms.Timer TimerP1;
        internal System.Windows.Forms.Timer TimerP2;
        internal System.Windows.Forms.Timer TimerP3;
        internal System.Windows.Forms.Timer TimerP4;
        internal System.Windows.Forms.Timer TimerP5;
        internal System.Windows.Forms.Timer TimerP6;
        internal System.Windows.Forms.Timer TimerActualizador;
        internal System.Windows.Forms.Timer TimerNUEVOSPEDIDOS;
        public System.Windows.Forms.DataGridView datalistadoDetalledeventa6;
        private System.Windows.Forms.DataGridViewButtonColumn Accion2;
        private System.Windows.Forms.DataGridViewLinkColumn Volver2;
        private System.Windows.Forms.DataGridViewButtonColumn Accion3;
        private System.Windows.Forms.DataGridViewLinkColumn Volver3;
        private System.Windows.Forms.DataGridViewButtonColumn Accion4;
        private System.Windows.Forms.DataGridViewLinkColumn Volver4;
        private System.Windows.Forms.DataGridViewButtonColumn Accion5;
        private System.Windows.Forms.DataGridViewLinkColumn Volver5;
        private System.Windows.Forms.DataGridViewButtonColumn Accion6;
        private System.Windows.Forms.DataGridViewLinkColumn Volver6;
    }
}