using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Telerik.Reporting;
using Telerik.Reporting.Drawing;

namespace RestCsharp.Presentacion.Reportes
{
    /// <summary>
    /// Summary description for Rcodigosqr.
    /// </summary>
    public partial class Rcodigosqr : Telerik.Reporting.Report
    {
        public Rcodigosqr()
        {
            //
            // Required for telerik Reporting designer support
            //
            InitializeComponent();

            //
            // TODO: Add any constructor code after InitializeComponent call
            //
        }
    }
}