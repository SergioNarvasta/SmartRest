
namespace RestCsharp.Presentacion.Reportes
{
    partial class Rprecuenta
    {
        #region Component Designer generated code
        /// <summary>
        /// Required method for telerik Reporting designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.Reporting.TableGroup tableGroup1 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup2 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup3 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup4 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.Drawing.StyleRule styleRule1 = new Telerik.Reporting.Drawing.StyleRule();
            this.textBox3 = new Telerik.Reporting.TextBox();
            this.textBox12 = new Telerik.Reporting.TextBox();
            this.textBox14 = new Telerik.Reporting.TextBox();
            this.pageHeaderSection1 = new Telerik.Reporting.PageHeaderSection();
            this.TextBox1 = new Telerik.Reporting.TextBox();
            this.panel3 = new Telerik.Reporting.Panel();
            this.TextBox24 = new Telerik.Reporting.TextBox();
            this.TextBox25 = new Telerik.Reporting.TextBox();
            this.textBox2 = new Telerik.Reporting.TextBox();
            this.detail = new Telerik.Reporting.DetailSection();
            this.pageFooterSection1 = new Telerik.Reporting.PageFooterSection();
            this.TextBox42 = new Telerik.Reporting.TextBox();
            this.TextBox41 = new Telerik.Reporting.TextBox();
            this.TextBox16 = new Telerik.Reporting.TextBox();
            this.textBox17 = new Telerik.Reporting.TextBox();
            this.textBox18 = new Telerik.Reporting.TextBox();
            this.textBox19 = new Telerik.Reporting.TextBox();
            this.reportHeaderSection1 = new Telerik.Reporting.ReportHeaderSection();
            this.TablaDetalle = new Telerik.Reporting.Table();
            this.textBox11 = new Telerik.Reporting.TextBox();
            this.textBox13 = new Telerik.Reporting.TextBox();
            this.textBox15 = new Telerik.Reporting.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // textBox3
            // 
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.267D), Telerik.Reporting.Drawing.Unit.Cm(0.781D));
            this.textBox3.Value = "Cant";
            // 
            // textBox12
            // 
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.267D), Telerik.Reporting.Drawing.Unit.Cm(0.781D));
            this.textBox12.Value = "Producto";
            // 
            // textBox14
            // 
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.267D), Telerik.Reporting.Drawing.Unit.Cm(0.781D));
            this.textBox14.Value = "Importe";
            // 
            // pageHeaderSection1
            // 
            this.pageHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(1.4D);
            this.pageHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.TextBox1,
            this.panel3,
            this.textBox2});
            this.pageHeaderSection1.Name = "pageHeaderSection1";
            // 
            // TextBox1
            // 
            this.TextBox1.CanGrow = false;
            this.TextBox1.Docking = Telerik.Reporting.DockingStyle.Top;
            this.TextBox1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.TextBox1.Name = "TextBox1";
            this.TextBox1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.6D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.TextBox1.Style.Font.Bold = true;
            this.TextBox1.Style.Font.Name = "Courier New";
            this.TextBox1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.TextBox1.Value = "=Fields.Empresa";
            // 
            // panel3
            // 
            this.panel3.Docking = Telerik.Reporting.DockingStyle.Top;
            this.panel3.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.TextBox24,
            this.TextBox25});
            this.panel3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.panel3.Name = "panel3";
            this.panel3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.6D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            // 
            // TextBox24
            // 
            this.TextBox24.Docking = Telerik.Reporting.DockingStyle.Left;
            this.TextBox24.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.TextBox24.Name = "TextBox24";
            this.TextBox24.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.578D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.TextBox24.Style.Font.Bold = true;
            this.TextBox24.Style.Font.Name = "Courier New";
            this.TextBox24.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.TextBox24.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TextBox24.Value = "Mesa:";
            // 
            // TextBox25
            // 
            this.TextBox25.CanGrow = false;
            this.TextBox25.Docking = Telerik.Reporting.DockingStyle.Fill;
            this.TextBox25.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.578D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.TextBox25.Name = "TextBox25";
            this.TextBox25.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5.022D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.TextBox25.Style.Font.Bold = true;
            this.TextBox25.Style.Font.Name = "Courier New";
            this.TextBox25.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.TextBox25.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.TextBox25.Value = "=Fields.Mesa";
            // 
            // textBox2
            // 
            this.textBox2.CanGrow = false;
            this.textBox2.Docking = Telerik.Reporting.DockingStyle.Top;
            this.textBox2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.9D));
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.6D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox2.Style.Font.Bold = true;
            this.textBox2.Style.Font.Name = "Courier New";
            this.textBox2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox2.Value = "PRE CUENTA";
            // 
            // detail
            // 
            this.detail.Height = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.detail.Name = "detail";
            // 
            // pageFooterSection1
            // 
            this.pageFooterSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(1.3D);
            this.pageFooterSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.TextBox42,
            this.TextBox41,
            this.TextBox16,
            this.textBox17,
            this.textBox18,
            this.textBox19});
            this.pageFooterSection1.Name = "pageFooterSection1";
            // 
            // TextBox42
            // 
            this.TextBox42.CanGrow = false;
            this.TextBox42.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.34D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.TextBox42.Name = "TextBox42";
            this.TextBox42.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.238D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.TextBox42.Style.Font.Bold = true;
            this.TextBox42.Style.Font.Name = "Courier New";
            this.TextBox42.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.TextBox42.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TextBox42.Value = "Sub Total:";
            // 
            // TextBox41
            // 
            this.TextBox41.Format = "{0:N2}";
            this.TextBox41.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.578D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.TextBox41.Name = "TextBox41";
            this.TextBox41.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.565D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.TextBox41.Style.Font.Name = "Courier New";
            this.TextBox41.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.TextBox41.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TextBox41.Value = "=SUM(Fields.Importe)/(1+(IIf(Fields.Ti=\"SI\",Fields.Porcentaje_impuesto,0)/100))";
            // 
            // TextBox16
            // 
            this.TextBox16.CanGrow = false;
            this.TextBox16.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.34D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.TextBox16.Name = "TextBox16";
            this.TextBox16.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.238D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.TextBox16.Style.Font.Bold = true;
            this.TextBox16.Style.Font.Name = "Courier New";
            this.TextBox16.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.TextBox16.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TextBox16.Value = "=Fields.Impuesto";
            // 
            // textBox17
            // 
            this.textBox17.Format = "{0:N2}";
            this.textBox17.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.578D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.565D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.textBox17.Style.Font.Name = "Courier New";
            this.textBox17.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox17.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox17.Value = "=SUM(Fields.Importe)-SUM(Fields.Importe)/(1+(IIf(Fields.Ti=\"SI\",Fields.Porcentaje" +
    "_impuesto,0)/100))";
            // 
            // textBox18
            // 
            this.textBox18.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.34D), Telerik.Reporting.Drawing.Unit.Cm(0.801D));
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.238D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.textBox18.Style.Font.Bold = true;
            this.textBox18.Style.Font.Name = "Courier New";
            this.textBox18.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox18.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox18.Value = "TOTAL:";
            // 
            // textBox19
            // 
            this.textBox19.Format = "{0:N2}";
            this.textBox19.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.578D), Telerik.Reporting.Drawing.Unit.Cm(0.801D));
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.565D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.textBox19.Style.Font.Name = "Courier New";
            this.textBox19.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox19.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox19.Value = "=SUM(Fields.Importe)";
            // 
            // reportHeaderSection1
            // 
            this.reportHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(2.1D);
            this.reportHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.TablaDetalle});
            this.reportHeaderSection1.Name = "reportHeaderSection1";
            // 
            // TablaDetalle
            // 
            this.TablaDetalle.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.267D)));
            this.TablaDetalle.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.267D)));
            this.TablaDetalle.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.267D)));
            this.TablaDetalle.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.781D)));
            this.TablaDetalle.Body.SetCellContent(0, 0, this.textBox11);
            this.TablaDetalle.Body.SetCellContent(0, 1, this.textBox13);
            this.TablaDetalle.Body.SetCellContent(0, 2, this.textBox15);
            tableGroup1.Name = "tableGroup";
            tableGroup1.ReportItem = this.textBox3;
            tableGroup2.Name = "tableGroup1";
            tableGroup2.ReportItem = this.textBox12;
            tableGroup3.Name = "tableGroup2";
            tableGroup3.ReportItem = this.textBox14;
            this.TablaDetalle.ColumnGroups.Add(tableGroup1);
            this.TablaDetalle.ColumnGroups.Add(tableGroup2);
            this.TablaDetalle.ColumnGroups.Add(tableGroup3);
            this.TablaDetalle.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.textBox11,
            this.textBox13,
            this.textBox15,
            this.textBox3,
            this.textBox12,
            this.textBox14});
            this.TablaDetalle.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.342D), Telerik.Reporting.Drawing.Unit.Cm(0.3D));
            this.TablaDetalle.Name = "TablaDetalle";
            tableGroup4.Groupings.Add(new Telerik.Reporting.Grouping(null));
            tableGroup4.Name = "detailTableGroup";
            this.TablaDetalle.RowGroups.Add(tableGroup4);
            this.TablaDetalle.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6.801D), Telerik.Reporting.Drawing.Unit.Cm(1.562D));
            this.TablaDetalle.Style.Font.Name = "Consolas";
            // 
            // textBox11
            // 
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.267D), Telerik.Reporting.Drawing.Unit.Cm(0.781D));
            this.textBox11.Value = "=Fields.Cant";
            // 
            // textBox13
            // 
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.267D), Telerik.Reporting.Drawing.Unit.Cm(0.781D));
            this.textBox13.Value = "=Fields.Producto";
            // 
            // textBox15
            // 
            this.textBox15.Format = "{0:N2}";
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.267D), Telerik.Reporting.Drawing.Unit.Cm(0.781D));
            this.textBox15.Value = "=Fields.Importe";
            // 
            // Rprecuenta
            // 
            this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.pageHeaderSection1,
            this.detail,
            this.pageFooterSection1,
            this.reportHeaderSection1});
            this.Name = "Rprecuenta";
            this.PageSettings.ContinuousPaper = true;
            this.PageSettings.Landscape = false;
            this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.Custom;
            this.PageSettings.PaperSize = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Mm(80D), Telerik.Reporting.Drawing.Unit.Mm(200D));
            styleRule1.Selectors.AddRange(new Telerik.Reporting.Drawing.ISelector[] {
            new Telerik.Reporting.Drawing.TypeSelector(typeof(Telerik.Reporting.TextItemBase)),
            new Telerik.Reporting.Drawing.TypeSelector(typeof(Telerik.Reporting.HtmlTextBox))});
            styleRule1.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Point(2D);
            styleRule1.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.StyleSheet.AddRange(new Telerik.Reporting.Drawing.StyleRule[] {
            styleRule1});
            this.Width = Telerik.Reporting.Drawing.Unit.Cm(7.6D);
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

        }
        #endregion

        private Telerik.Reporting.PageHeaderSection pageHeaderSection1;
        private Telerik.Reporting.DetailSection detail;
        private Telerik.Reporting.PageFooterSection pageFooterSection1;
        internal Telerik.Reporting.TextBox TextBox1;
        private Telerik.Reporting.Panel panel3;
        internal Telerik.Reporting.TextBox TextBox24;
        internal Telerik.Reporting.TextBox TextBox25;
        internal Telerik.Reporting.TextBox textBox2;
        private Telerik.Reporting.ReportHeaderSection reportHeaderSection1;
        public Telerik.Reporting.Table TablaDetalle;
        private Telerik.Reporting.TextBox textBox11;
        private Telerik.Reporting.TextBox textBox13;
        private Telerik.Reporting.TextBox textBox15;
        private Telerik.Reporting.TextBox textBox3;
        private Telerik.Reporting.TextBox textBox12;
        private Telerik.Reporting.TextBox textBox14;
        internal Telerik.Reporting.TextBox TextBox42;
        internal Telerik.Reporting.TextBox TextBox41;
        internal Telerik.Reporting.TextBox TextBox16;
        internal Telerik.Reporting.TextBox textBox17;
        internal Telerik.Reporting.TextBox textBox18;
        internal Telerik.Reporting.TextBox textBox19;
    }
}