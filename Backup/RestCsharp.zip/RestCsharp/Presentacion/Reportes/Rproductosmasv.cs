using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Telerik.Reporting;
using Telerik.Reporting.Drawing;

namespace RestCsharp.Presentacion.Reportes
{
    /// <summary>
    /// Summary description for Rproductosmasv.
    /// </summary>
    public partial class Rproductosmasv : Telerik.Reporting.Report
    {
        public Rproductosmasv()
        {
            //
            // Required for telerik Reporting designer support
            //
            InitializeComponent();

            //
            // TODO: Add any constructor code after InitializeComponent call
            //
        }
    }
}