using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Telerik.Reporting;
using Telerik.Reporting.Drawing;

namespace RestCsharp.Presentacion.Reportes
{
    /// <summary>
    /// Summary description for Rresumenventas.
    /// </summary>
    public partial class Rresumenventas : Telerik.Reporting.Report
    {
        public Rresumenventas()
        {
            //
            // Required for telerik Reporting designer support
            //
            InitializeComponent();

            //
            // TODO: Add any constructor code after InitializeComponent call
            //
        }
    }
}