
namespace RestCsharp.Presentacion.Reportes
{
    partial class RcomprobVenta
    {
        #region Component Designer generated code
        /// <summary>
        /// Required method for telerik Reporting designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.Reporting.TableGroup tableGroup1 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup2 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup3 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup4 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.Barcodes.QRCodeEncoder qrCodeEncoder1 = new Telerik.Reporting.Barcodes.QRCodeEncoder();
            Telerik.Reporting.Drawing.StyleRule styleRule1 = new Telerik.Reporting.Drawing.StyleRule();
            this.textBox2 = new Telerik.Reporting.TextBox();
            this.textBox12 = new Telerik.Reporting.TextBox();
            this.textBox14 = new Telerik.Reporting.TextBox();
            this.detail = new Telerik.Reporting.DetailSection();
            this.pageHeaderSection1 = new Telerik.Reporting.PageHeaderSection();
            this.panel1 = new Telerik.Reporting.Panel();
            this.pictureBox1 = new Telerik.Reporting.PictureBox();
            this.TextBox1 = new Telerik.Reporting.TextBox();
            this.TextBox4 = new Telerik.Reporting.TextBox();
            this.TextBox3 = new Telerik.Reporting.TextBox();
            this.TextBox5 = new Telerik.Reporting.TextBox();
            this.panel2 = new Telerik.Reporting.Panel();
            this.TextBox6 = new Telerik.Reporting.TextBox();
            this.TextBox7 = new Telerik.Reporting.TextBox();
            this.panel3 = new Telerik.Reporting.Panel();
            this.TextBox24 = new Telerik.Reporting.TextBox();
            this.TextBox25 = new Telerik.Reporting.TextBox();
            this.panel4 = new Telerik.Reporting.Panel();
            this.TextBox8 = new Telerik.Reporting.TextBox();
            this.TextBox9 = new Telerik.Reporting.TextBox();
            this.panel5 = new Telerik.Reporting.Panel();
            this.TextBox23 = new Telerik.Reporting.TextBox();
            this.TextBox22 = new Telerik.Reporting.TextBox();
            this.reportHeaderSection1 = new Telerik.Reporting.ReportHeaderSection();
            this.TablaDetalle = new Telerik.Reporting.Table();
            this.textBox11 = new Telerik.Reporting.TextBox();
            this.textBox13 = new Telerik.Reporting.TextBox();
            this.textBox15 = new Telerik.Reporting.TextBox();
            this.TextBox42 = new Telerik.Reporting.TextBox();
            this.TextBox41 = new Telerik.Reporting.TextBox();
            this.TextBox16 = new Telerik.Reporting.TextBox();
            this.textBox17 = new Telerik.Reporting.TextBox();
            this.textBox18 = new Telerik.Reporting.TextBox();
            this.textBox19 = new Telerik.Reporting.TextBox();
            this.TextBox29 = new Telerik.Reporting.TextBox();
            this.textBox20 = new Telerik.Reporting.TextBox();
            this.TextBox30 = new Telerik.Reporting.TextBox();
            this.textBox21 = new Telerik.Reporting.TextBox();
            this.TextBox35 = new Telerik.Reporting.TextBox();
            this.textBox26 = new Telerik.Reporting.TextBox();
            this.textBox27 = new Telerik.Reporting.TextBox();
            this.textBox28 = new Telerik.Reporting.TextBox();
            this.textBox31 = new Telerik.Reporting.TextBox();
            this.textBox33 = new Telerik.Reporting.TextBox();
            this.barcode2 = new Telerik.Reporting.Barcode();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // textBox2
            // 
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.267D), Telerik.Reporting.Drawing.Unit.Cm(0.437D));
            this.textBox2.Style.Font.Bold = true;
            this.textBox2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox2.Value = "Cant";
            // 
            // textBox12
            // 
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.267D), Telerik.Reporting.Drawing.Unit.Cm(0.437D));
            this.textBox12.Style.Font.Bold = true;
            this.textBox12.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox12.Value = "Producto";
            // 
            // textBox14
            // 
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.267D), Telerik.Reporting.Drawing.Unit.Cm(0.437D));
            this.textBox14.Style.Font.Bold = true;
            this.textBox14.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox14.Value = "Importe";
            // 
            // detail
            // 
            this.detail.Height = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.detail.Name = "detail";
            // 
            // pageHeaderSection1
            // 
            this.pageHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(5.7D);
            this.pageHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.panel1,
            this.TextBox1,
            this.TextBox4,
            this.TextBox3,
            this.TextBox5,
            this.panel2,
            this.panel3,
            this.panel4,
            this.panel5});
            this.pageHeaderSection1.Name = "pageHeaderSection1";
            // 
            // panel1
            // 
            this.panel1.Docking = Telerik.Reporting.DockingStyle.Top;
            this.panel1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.pictureBox1});
            this.panel1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.panel1.Name = "panel1";
            this.panel1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.6D), Telerik.Reporting.Drawing.Unit.Cm(2.1D));
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.816D), Telerik.Reporting.Drawing.Unit.Cm(0.3D));
            this.pictureBox1.MimeType = "";
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.922D), Telerik.Reporting.Drawing.Unit.Cm(1.7D));
            this.pictureBox1.Sizing = Telerik.Reporting.Drawing.ImageSizeMode.ScaleProportional;
            this.pictureBox1.Value = "=Fields.Logo";
            // 
            // TextBox1
            // 
            this.TextBox1.CanGrow = false;
            this.TextBox1.Docking = Telerik.Reporting.DockingStyle.Top;
            this.TextBox1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(2.1D));
            this.TextBox1.Name = "TextBox1";
            this.TextBox1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.6D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.TextBox1.Style.Font.Bold = true;
            this.TextBox1.Style.Font.Name = "Courier New";
            this.TextBox1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.TextBox1.Value = "=Fields.Empresa";
            // 
            // TextBox4
            // 
            this.TextBox4.CanGrow = false;
            this.TextBox4.Docking = Telerik.Reporting.DockingStyle.Top;
            this.TextBox4.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(2.6D));
            this.TextBox4.Name = "TextBox4";
            this.TextBox4.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.6D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.TextBox4.Style.Font.Name = "Courier New";
            this.TextBox4.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.TextBox4.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.TextBox4.Value = "=Fields.Identificador_fiscal";
            // 
            // TextBox3
            // 
            this.TextBox3.CanGrow = false;
            this.TextBox3.Docking = Telerik.Reporting.DockingStyle.Top;
            this.TextBox3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(3D));
            this.TextBox3.Name = "TextBox3";
            this.TextBox3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.6D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.TextBox3.Style.Font.Name = "Courier New";
            this.TextBox3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.TextBox3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.TextBox3.Value = "=Fields.Direccion";
            // 
            // TextBox5
            // 
            this.TextBox5.CanGrow = false;
            this.TextBox5.Docking = Telerik.Reporting.DockingStyle.Top;
            this.TextBox5.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(3.4D));
            this.TextBox5.Name = "TextBox5";
            this.TextBox5.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.6D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.TextBox5.Style.Font.Name = "Courier New";
            this.TextBox5.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.TextBox5.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.TextBox5.Value = "=Fields.Departamento";
            // 
            // panel2
            // 
            this.panel2.Docking = Telerik.Reporting.DockingStyle.Top;
            this.panel2.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.TextBox6,
            this.TextBox7});
            this.panel2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(3.8D));
            this.panel2.Name = "panel2";
            this.panel2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            // 
            // TextBox6
            // 
            this.TextBox6.Docking = Telerik.Reporting.DockingStyle.Left;
            this.TextBox6.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.TextBox6.Name = "TextBox6";
            this.TextBox6.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.816D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TextBox6.Style.Font.Bold = true;
            this.TextBox6.Style.Font.Name = "Courier New";
            this.TextBox6.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.TextBox6.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TextBox6.Value = "=Fields.tipodoc";
            // 
            // TextBox7
            // 
            this.TextBox7.CanGrow = true;
            this.TextBox7.Docking = Telerik.Reporting.DockingStyle.Fill;
            this.TextBox7.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.816D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.TextBox7.Name = "TextBox7";
            this.TextBox7.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.784D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TextBox7.Style.Font.Name = "Courier New";
            this.TextBox7.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.TextBox7.Value = "=Fields.Numero_de_doc";
            // 
            // panel3
            // 
            this.panel3.Docking = Telerik.Reporting.DockingStyle.Top;
            this.panel3.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.TextBox24,
            this.TextBox25});
            this.panel3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(4.4D));
            this.panel3.Name = "panel3";
            this.panel3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.6D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            // 
            // TextBox24
            // 
            this.TextBox24.Docking = Telerik.Reporting.DockingStyle.Left;
            this.TextBox24.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.TextBox24.Name = "TextBox24";
            this.TextBox24.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.578D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.TextBox24.Style.Font.Bold = true;
            this.TextBox24.Style.Font.Name = "Courier New";
            this.TextBox24.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.TextBox24.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TextBox24.Value = "Cajero(a):";
            // 
            // TextBox25
            // 
            this.TextBox25.CanGrow = false;
            this.TextBox25.Docking = Telerik.Reporting.DockingStyle.Fill;
            this.TextBox25.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.578D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.TextBox25.Name = "TextBox25";
            this.TextBox25.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5.022D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.TextBox25.Style.Font.Bold = false;
            this.TextBox25.Style.Font.Name = "Courier New";
            this.TextBox25.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.TextBox25.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.TextBox25.Value = "=Fields.Usuario";
            // 
            // panel4
            // 
            this.panel4.Docking = Telerik.Reporting.DockingStyle.Top;
            this.panel4.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.TextBox8,
            this.TextBox9});
            this.panel4.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(4.8D));
            this.panel4.Name = "panel4";
            this.panel4.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.6D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            // 
            // TextBox8
            // 
            this.TextBox8.Docking = Telerik.Reporting.DockingStyle.Left;
            this.TextBox8.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.TextBox8.Name = "TextBox8";
            this.TextBox8.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.578D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.TextBox8.Style.Font.Bold = true;
            this.TextBox8.Style.Font.Name = "Courier New";
            this.TextBox8.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.TextBox8.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TextBox8.Value = "Fecha:";
            // 
            // TextBox9
            // 
            this.TextBox9.CanGrow = false;
            this.TextBox9.Docking = Telerik.Reporting.DockingStyle.Fill;
            this.TextBox9.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.578D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.TextBox9.Name = "TextBox9";
            this.TextBox9.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5.022D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.TextBox9.Style.Font.Name = "Courier New";
            this.TextBox9.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.TextBox9.Value = "=Fields.fecha";
            // 
            // panel5
            // 
            this.panel5.Docking = Telerik.Reporting.DockingStyle.Top;
            this.panel5.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.TextBox23,
            this.TextBox22});
            this.panel5.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(5.2D));
            this.panel5.Name = "panel5";
            this.panel5.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.6D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            // 
            // TextBox23
            // 
            this.TextBox23.Docking = Telerik.Reporting.DockingStyle.Left;
            this.TextBox23.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.TextBox23.Name = "TextBox23";
            this.TextBox23.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.578D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.TextBox23.Style.Font.Bold = true;
            this.TextBox23.Style.Font.Name = "Courier New";
            this.TextBox23.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.TextBox23.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TextBox23.Value = "Cliente:";
            // 
            // TextBox22
            // 
            this.TextBox22.CanGrow = false;
            this.TextBox22.Docking = Telerik.Reporting.DockingStyle.Fill;
            this.TextBox22.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.578D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.TextBox22.Name = "TextBox22";
            this.TextBox22.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5.022D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.TextBox22.Style.Font.Bold = false;
            this.TextBox22.Style.Font.Name = "Courier New";
            this.TextBox22.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.TextBox22.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.TextBox22.Value = "=Fields.Nombre";
            // 
            // reportHeaderSection1
            // 
            this.reportHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(9.3D);
            this.reportHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.TablaDetalle,
            this.TextBox42,
            this.TextBox41,
            this.TextBox16,
            this.textBox17,
            this.textBox18,
            this.textBox19,
            this.TextBox29,
            this.textBox20,
            this.TextBox30,
            this.textBox21,
            this.TextBox35,
            this.textBox26,
            this.textBox27,
            this.textBox28,
            this.textBox31,
            this.textBox33,
            this.barcode2});
            this.reportHeaderSection1.Name = "reportHeaderSection1";
            // 
            // TablaDetalle
            // 
            this.TablaDetalle.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.267D)));
            this.TablaDetalle.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.267D)));
            this.TablaDetalle.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.267D)));
            this.TablaDetalle.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.781D)));
            this.TablaDetalle.Body.SetCellContent(0, 0, this.textBox11);
            this.TablaDetalle.Body.SetCellContent(0, 1, this.textBox13);
            this.TablaDetalle.Body.SetCellContent(0, 2, this.textBox15);
            tableGroup1.Name = "tableGroup";
            tableGroup1.ReportItem = this.textBox2;
            tableGroup2.Name = "tableGroup1";
            tableGroup2.ReportItem = this.textBox12;
            tableGroup3.Name = "tableGroup2";
            tableGroup3.ReportItem = this.textBox14;
            this.TablaDetalle.ColumnGroups.Add(tableGroup1);
            this.TablaDetalle.ColumnGroups.Add(tableGroup2);
            this.TablaDetalle.ColumnGroups.Add(tableGroup3);
            this.TablaDetalle.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.textBox11,
            this.textBox13,
            this.textBox15,
            this.textBox2,
            this.textBox12,
            this.textBox14});
            this.TablaDetalle.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.311D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.TablaDetalle.Name = "TablaDetalle";
            tableGroup4.Groupings.Add(new Telerik.Reporting.Grouping(null));
            tableGroup4.Name = "detailTableGroup";
            this.TablaDetalle.RowGroups.Add(tableGroup4);
            this.TablaDetalle.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6.801D), Telerik.Reporting.Drawing.Unit.Cm(1.218D));
            this.TablaDetalle.Style.Font.Name = "Consolas";
            // 
            // textBox11
            // 
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.267D), Telerik.Reporting.Drawing.Unit.Cm(0.781D));
            this.textBox11.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox11.Value = "=Fields.Cant";
            // 
            // textBox13
            // 
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.267D), Telerik.Reporting.Drawing.Unit.Cm(0.781D));
            this.textBox13.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox13.Value = "=Fields.Producto";
            // 
            // textBox15
            // 
            this.textBox15.Format = "{0:N2}";
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.267D), Telerik.Reporting.Drawing.Unit.Cm(0.781D));
            this.textBox15.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox15.Value = "=Fields.Importe";
            // 
            // TextBox42
            // 
            this.TextBox42.CanGrow = false;
            this.TextBox42.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.34D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
            this.TextBox42.Name = "TextBox42";
            this.TextBox42.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.238D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.TextBox42.Style.Font.Bold = true;
            this.TextBox42.Style.Font.Name = "Courier New";
            this.TextBox42.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.TextBox42.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TextBox42.Value = "Sub Total:";
            // 
            // TextBox41
            // 
            this.TextBox41.Format = "{0:N2}";
            this.TextBox41.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.578D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
            this.TextBox41.Name = "TextBox41";
            this.TextBox41.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.565D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.TextBox41.Style.Font.Name = "Courier New";
            this.TextBox41.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.TextBox41.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TextBox41.Value = "=Fields.OPGrabadas";
            // 
            // TextBox16
            // 
            this.TextBox16.CanGrow = false;
            this.TextBox16.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.34D), Telerik.Reporting.Drawing.Unit.Cm(2.2D));
            this.TextBox16.Name = "TextBox16";
            this.TextBox16.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.238D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.TextBox16.Style.Font.Bold = true;
            this.TextBox16.Style.Font.Name = "Courier New";
            this.TextBox16.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.TextBox16.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TextBox16.Value = "=Fields.ImpuestoComp";
            // 
            // textBox17
            // 
            this.textBox17.Format = "{0:N2}";
            this.textBox17.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.578D), Telerik.Reporting.Drawing.Unit.Cm(2.2D));
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.565D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.textBox17.Style.Font.Name = "Courier New";
            this.textBox17.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox17.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox17.Value = "=Fields.Subtotal_Impuesto";
            // 
            // textBox18
            // 
            this.textBox18.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.34D), Telerik.Reporting.Drawing.Unit.Cm(2.601D));
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.238D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.textBox18.Style.Font.Bold = true;
            this.textBox18.Style.Font.Name = "Courier New";
            this.textBox18.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox18.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox18.Value = "TOTAL:";
            // 
            // textBox19
            // 
            this.textBox19.Format = "{0:N2}";
            this.textBox19.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.578D), Telerik.Reporting.Drawing.Unit.Cm(2.601D));
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.565D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.textBox19.Style.Font.Name = "Courier New";
            this.textBox19.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox19.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox19.Value = "=Fields.Monto_total";
            // 
            // TextBox29
            // 
            this.TextBox29.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.34D), Telerik.Reporting.Drawing.Unit.Cm(3.2D));
            this.TextBox29.Name = "TextBox29";
            this.TextBox29.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.238D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.TextBox29.Style.Font.Bold = true;
            this.TextBox29.Style.Font.Name = "Courier New";
            this.TextBox29.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.TextBox29.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TextBox29.Value = "Efectivo";
            // 
            // textBox20
            // 
            this.textBox20.Format = "{0:N2}";
            this.textBox20.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.578D), Telerik.Reporting.Drawing.Unit.Cm(3.2D));
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.565D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.textBox20.Style.Font.Name = "Courier New";
            this.textBox20.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox20.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox20.Value = "=Fields.Pago_con";
            // 
            // TextBox30
            // 
            this.TextBox30.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.34D), Telerik.Reporting.Drawing.Unit.Cm(3.6D));
            this.TextBox30.Name = "TextBox30";
            this.TextBox30.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.238D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.TextBox30.Style.Font.Bold = true;
            this.TextBox30.Style.Font.Name = "Courier New";
            this.TextBox30.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.TextBox30.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TextBox30.Value = "Vuelto:";
            // 
            // textBox21
            // 
            this.textBox21.Format = "{0:N2}";
            this.textBox21.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.578D), Telerik.Reporting.Drawing.Unit.Cm(3.6D));
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.565D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.textBox21.Style.Font.Name = "Courier New";
            this.textBox21.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox21.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox21.Value = "=Fields.Vuelto";
            // 
            // TextBox35
            // 
            this.TextBox35.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.178D), Telerik.Reporting.Drawing.Unit.Cm(4D));
            this.TextBox35.Name = "TextBox35";
            this.TextBox35.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.4D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.TextBox35.Style.Font.Bold = true;
            this.TextBox35.Style.Font.Name = "Courier New";
            this.TextBox35.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.TextBox35.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TextBox35.Value = "Tipo de Pago:";
            // 
            // textBox26
            // 
            this.textBox26.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.578D), Telerik.Reporting.Drawing.Unit.Cm(4D));
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.565D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.textBox26.Style.Font.Name = "Courier New";
            this.textBox26.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox26.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox26.Value = "=Fields.Tipo_de_pago";
            // 
            // textBox27
            // 
            this.textBox27.CanGrow = false;
            this.textBox27.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(4.6D));
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.6D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.textBox27.Style.Font.Bold = false;
            this.textBox27.Style.Font.Name = "Courier New";
            this.textBox27.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox27.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox27.Value = "=Fields.Agradecimiento";
            // 
            // textBox28
            // 
            this.textBox28.CanGrow = false;
            this.textBox28.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(5.199D));
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.6D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.textBox28.Style.Font.Bold = false;
            this.textBox28.Style.Font.Name = "Courier New";
            this.textBox28.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox28.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox28.Value = "=Fields.pagina_Web_Facebook";
            // 
            // textBox31
            // 
            this.textBox31.CanGrow = false;
            this.textBox31.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(5.599D));
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.6D), Telerik.Reporting.Drawing.Unit.Cm(0.4D));
            this.textBox31.Style.Font.Bold = false;
            this.textBox31.Style.Font.Name = "Courier New";
            this.textBox31.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox31.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox31.Value = "=Fields.Anuncio";
            // 
            // textBox33
            // 
            this.textBox33.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(8.6D));
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.6D), Telerik.Reporting.Drawing.Unit.Cm(0.506D));
            this.textBox33.Style.Font.Bold = false;
            this.textBox33.Style.Font.Name = "Courier New";
            this.textBox33.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox33.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox33.Value = "=Fields.Datos_fiscales_de_autorizacion";
            // 
            // barcode2
            // 
            this.barcode2.Encoder = qrCodeEncoder1;
            this.barcode2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.578D), Telerik.Reporting.Drawing.Unit.Cm(6.199D));
            this.barcode2.Name = "barcode2";
            this.barcode2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.522D), Telerik.Reporting.Drawing.Unit.Cm(2.201D));
            this.barcode2.Stretch = true;
            this.barcode2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.barcode2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.barcode2.Value = "=Fields.Usuario + Fields.Numero_de_doc + Fields.Empresa + Fields.Identificador_fi" +
    "scal";
            // 
            // RcomprobVenta
            // 
            this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.pageHeaderSection1,
            this.detail,
            this.reportHeaderSection1});
            this.Name = "RcomprobVenta";
            this.PageSettings.ContinuousPaper = true;
            this.PageSettings.Landscape = false;
            this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Mm(0D), Telerik.Reporting.Drawing.Unit.Mm(0D), Telerik.Reporting.Drawing.Unit.Mm(0D), Telerik.Reporting.Drawing.Unit.Mm(0D));
            this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.Custom;
            this.PageSettings.PaperSize = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Mm(80D), Telerik.Reporting.Drawing.Unit.Mm(200D));
            styleRule1.Selectors.AddRange(new Telerik.Reporting.Drawing.ISelector[] {
            new Telerik.Reporting.Drawing.TypeSelector(typeof(Telerik.Reporting.TextItemBase)),
            new Telerik.Reporting.Drawing.TypeSelector(typeof(Telerik.Reporting.HtmlTextBox))});
            styleRule1.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Point(2D);
            styleRule1.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.StyleSheet.AddRange(new Telerik.Reporting.Drawing.StyleRule[] {
            styleRule1});
            this.Width = Telerik.Reporting.Drawing.Unit.Cm(7.6D);
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

        }
        #endregion
        private Telerik.Reporting.DetailSection detail;
        private Telerik.Reporting.PageHeaderSection pageHeaderSection1;
        private Telerik.Reporting.ReportHeaderSection reportHeaderSection1;
        private Telerik.Reporting.Panel panel1;
        internal Telerik.Reporting.TextBox TextBox1;
        internal Telerik.Reporting.TextBox TextBox4;
        internal Telerik.Reporting.TextBox TextBox3;
        internal Telerik.Reporting.TextBox TextBox5;
        private Telerik.Reporting.Panel panel2;
        internal Telerik.Reporting.TextBox TextBox6;
        internal Telerik.Reporting.TextBox TextBox7;
        private Telerik.Reporting.Panel panel3;
        internal Telerik.Reporting.TextBox TextBox24;
        internal Telerik.Reporting.TextBox TextBox25;
        private Telerik.Reporting.Panel panel4;
        internal Telerik.Reporting.TextBox TextBox8;
        internal Telerik.Reporting.TextBox TextBox9;
        private Telerik.Reporting.Panel panel5;
        internal Telerik.Reporting.TextBox TextBox23;
        internal Telerik.Reporting.TextBox TextBox22;
        public Telerik.Reporting.Table TablaDetalle;
        private Telerik.Reporting.TextBox textBox11;
        private Telerik.Reporting.TextBox textBox13;
        private Telerik.Reporting.TextBox textBox15;
        private Telerik.Reporting.TextBox textBox2;
        private Telerik.Reporting.TextBox textBox12;
        private Telerik.Reporting.TextBox textBox14;
        internal Telerik.Reporting.TextBox TextBox42;
        internal Telerik.Reporting.TextBox TextBox41;
        internal Telerik.Reporting.TextBox TextBox16;
        internal Telerik.Reporting.TextBox textBox17;
        internal Telerik.Reporting.TextBox textBox18;
        internal Telerik.Reporting.TextBox textBox19;
        internal Telerik.Reporting.TextBox TextBox29;
        internal Telerik.Reporting.TextBox textBox20;
        internal Telerik.Reporting.TextBox TextBox30;
        internal Telerik.Reporting.TextBox textBox21;
        internal Telerik.Reporting.TextBox TextBox35;
        internal Telerik.Reporting.TextBox textBox26;
        internal Telerik.Reporting.TextBox textBox27;
        internal Telerik.Reporting.TextBox textBox28;
        internal Telerik.Reporting.TextBox textBox31;
        internal Telerik.Reporting.TextBox textBox33;
        private Telerik.Reporting.Barcode barcode2;
        private Telerik.Reporting.PictureBox pictureBox1;
    }
}