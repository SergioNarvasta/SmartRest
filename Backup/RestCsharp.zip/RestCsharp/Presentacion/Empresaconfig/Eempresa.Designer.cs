﻿
namespace RestCsharp.Presentacion.Empresaconfig
{
    partial class Eempresa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Eempresa));
            this.PanelEmpresa = new System.Windows.Forms.Panel();
            this.btnsiguiente = new System.Windows.Forms.Button();
            this.Panel2 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chPorpedido = new System.Windows.Forms.RadioButton();
            this.chGeneral = new System.Windows.Forms.RadioButton();
            this.txtRuta = new System.Windows.Forms.TextBox();
            this.Label9 = new System.Windows.Forms.Label();
            this.ToolStrip1 = new System.Windows.Forms.ToolStrip();
            this.ToolStripButton22 = new System.Windows.Forms.ToolStripButton();
            this.PanelImpuesto = new System.Windows.Forms.Panel();
            this.panelImpuestos = new System.Windows.Forms.Panel();
            this.Panel12 = new System.Windows.Forms.Panel();
            this.txtimpuesto = new System.Windows.Forms.ComboBox();
            this.Label14 = new System.Windows.Forms.Label();
            this.txtporcentaje = new System.Windows.Forms.ComboBox();
            this.Label16 = new System.Windows.Forms.Label();
            this.no = new System.Windows.Forms.RadioButton();
            this.si = new System.Windows.Forms.RadioButton();
            this.Panel6 = new System.Windows.Forms.Panel();
            this.txtmoneda = new System.Windows.Forms.ComboBox();
            this.lbleditarLogo = new System.Windows.Forms.Label();
            this.ImagenEmpresa = new System.Windows.Forms.PictureBox();
            this.Panel5 = new System.Windows.Forms.Panel();
            this.txtrazonsocial = new System.Windows.Forms.TextBox();
            this.lblempresa = new System.Windows.Forms.Label();
            this.Label8 = new System.Windows.Forms.Label();
            this.TabControl3 = new System.Windows.Forms.TabControl();
            this.TabPage5 = new System.Windows.Forms.TabPage();
            this.Label4 = new System.Windows.Forms.Label();
            this.TabPage6 = new System.Windows.Forms.TabPage();
            this.PictureBox4 = new System.Windows.Forms.PictureBox();
            this.Label17 = new System.Windows.Forms.Label();
            this.dlg = new System.Windows.Forms.OpenFileDialog();
            this.Fbd = new System.Windows.Forms.FolderBrowserDialog();
            this.checConectarsunat = new System.Windows.Forms.CheckBox();
            this.panelSunat = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.txtCodigoMoneda = new System.Windows.Forms.TextBox();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.txtdistrito = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtprovincia = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtdepartamento = new System.Windows.Forms.ComboBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.txtdireccionfiscal = new System.Windows.Forms.TextBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel22 = new System.Windows.Forms.Panel();
            this.cbxServidor = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.txtContraseñaSunat = new System.Windows.Forms.TextBox();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.txtUsuarioSunat = new System.Windows.Forms.TextBox();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.txtContraseñaCert = new System.Windows.Forms.TextBox();
            this.panel17 = new System.Windows.Forms.Panel();
            this.psunat = new System.Windows.Forms.PictureBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCertificado = new System.Windows.Forms.TextBox();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.txtRuc = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.PanelEmpresa.SuspendLayout();
            this.Panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.ToolStrip1.SuspendLayout();
            this.PanelImpuesto.SuspendLayout();
            this.panelImpuestos.SuspendLayout();
            this.Panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ImagenEmpresa)).BeginInit();
            this.TabControl3.SuspendLayout();
            this.TabPage5.SuspendLayout();
            this.TabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox4)).BeginInit();
            this.panelSunat.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.psunat)).BeginInit();
            this.panel9.SuspendLayout();
            this.panel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // PanelEmpresa
            // 
            this.PanelEmpresa.BackColor = System.Drawing.Color.White;
            this.PanelEmpresa.Controls.Add(this.btnsiguiente);
            this.PanelEmpresa.Controls.Add(this.Panel2);
            this.PanelEmpresa.Location = new System.Drawing.Point(69, 18);
            this.PanelEmpresa.Name = "PanelEmpresa";
            this.PanelEmpresa.Size = new System.Drawing.Size(644, 561);
            this.PanelEmpresa.TabIndex = 612;
            // 
            // btnsiguiente
            // 
            this.btnsiguiente.BackColor = System.Drawing.Color.Transparent;
            this.btnsiguiente.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.btnsiguiente.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnsiguiente.FlatAppearance.BorderSize = 0;
            this.btnsiguiente.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnsiguiente.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnsiguiente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsiguiente.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsiguiente.ForeColor = System.Drawing.Color.White;
            this.btnsiguiente.Location = new System.Drawing.Point(516, 498);
            this.btnsiguiente.Name = "btnsiguiente";
            this.btnsiguiente.Size = new System.Drawing.Size(125, 58);
            this.btnsiguiente.TabIndex = 594;
            this.btnsiguiente.Text = "Guardar";
            this.btnsiguiente.UseVisualStyleBackColor = false;
            this.btnsiguiente.Click += new System.EventHandler(this.btnsiguiente_Click);
            // 
            // Panel2
            // 
            this.Panel2.BackColor = System.Drawing.Color.White;
            this.Panel2.Controls.Add(this.groupBox1);
            this.Panel2.Controls.Add(this.txtRuta);
            this.Panel2.Controls.Add(this.Label9);
            this.Panel2.Controls.Add(this.ToolStrip1);
            this.Panel2.Controls.Add(this.PanelImpuesto);
            this.Panel2.Controls.Add(this.Panel6);
            this.Panel2.Controls.Add(this.TabControl3);
            this.Panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel2.Location = new System.Drawing.Point(0, 0);
            this.Panel2.Name = "Panel2";
            this.Panel2.Size = new System.Drawing.Size(644, 492);
            this.Panel2.TabIndex = 360;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chPorpedido);
            this.groupBox1.Controls.Add(this.chGeneral);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox1.Location = new System.Drawing.Point(37, 331);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(563, 94);
            this.groupBox1.TabIndex = 600;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Notas en pedidos";
            // 
            // chPorpedido
            // 
            this.chPorpedido.AutoSize = true;
            this.chPorpedido.Location = new System.Drawing.Point(194, 39);
            this.chPorpedido.Name = "chPorpedido";
            this.chPorpedido.Size = new System.Drawing.Size(179, 28);
            this.chPorpedido.TabIndex = 344;
            this.chPorpedido.TabStop = true;
            this.chPorpedido.Text = "Nota por pedido";
            this.chPorpedido.UseVisualStyleBackColor = true;
            this.chPorpedido.CheckedChanged += new System.EventHandler(this.chPorpedido_CheckedChanged);
            // 
            // chGeneral
            // 
            this.chGeneral.AutoSize = true;
            this.chGeneral.Checked = true;
            this.chGeneral.Location = new System.Drawing.Point(25, 39);
            this.chGeneral.Name = "chGeneral";
            this.chGeneral.Size = new System.Drawing.Size(148, 28);
            this.chGeneral.TabIndex = 344;
            this.chGeneral.TabStop = true;
            this.chGeneral.Text = "Nota general";
            this.chGeneral.UseVisualStyleBackColor = true;
            this.chGeneral.CheckedChanged += new System.EventHandler(this.chGeneral_CheckedChanged);
            // 
            // txtRuta
            // 
            this.txtRuta.BackColor = System.Drawing.Color.White;
            this.txtRuta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtRuta.Enabled = false;
            this.txtRuta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtRuta.Location = new System.Drawing.Point(71, 299);
            this.txtRuta.Name = "txtRuta";
            this.txtRuta.Size = new System.Drawing.Size(506, 26);
            this.txtRuta.TabIndex = 597;
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.BackColor = System.Drawing.Color.White;
            this.Label9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.Label9.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Label9.Location = new System.Drawing.Point(67, 278);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(533, 20);
            this.Label9.TabIndex = 596;
            this.Label9.Text = "Seleccione una Carpeta donde Guardar Las Copias de Seguridad\r\n";
            this.Label9.Click += new System.EventHandler(this.Label9_Click);
            // 
            // ToolStrip1
            // 
            this.ToolStrip1.AutoSize = false;
            this.ToolStrip1.BackColor = System.Drawing.Color.White;
            this.ToolStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.ToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripButton22});
            this.ToolStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.ToolStrip1.Location = new System.Drawing.Point(24, 265);
            this.ToolStrip1.Name = "ToolStrip1";
            this.ToolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.ToolStrip1.Size = new System.Drawing.Size(72, 49);
            this.ToolStrip1.TabIndex = 598;
            this.ToolStrip1.Text = "ToolStrip1";
            // 
            // ToolStripButton22
            // 
            this.ToolStripButton22.BackColor = System.Drawing.Color.White;
            this.ToolStripButton22.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ToolStripButton22.ForeColor = System.Drawing.Color.Black;
            this.ToolStripButton22.Image = ((System.Drawing.Image)(resources.GetObject("ToolStripButton22.Image")));
            this.ToolStripButton22.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ToolStripButton22.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ToolStripButton22.Name = "ToolStripButton22";
            this.ToolStripButton22.Size = new System.Drawing.Size(37, 46);
            this.ToolStripButton22.Text = "+";
            this.ToolStripButton22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ToolStripButton22.ToolTipText = "Buscar Ruta";
            this.ToolStripButton22.Click += new System.EventHandler(this.ToolStripButton22_Click);
            // 
            // PanelImpuesto
            // 
            this.PanelImpuesto.BackColor = System.Drawing.Color.White;
            this.PanelImpuesto.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PanelImpuesto.Controls.Add(this.panelImpuestos);
            this.PanelImpuesto.Controls.Add(this.Label16);
            this.PanelImpuesto.Controls.Add(this.no);
            this.PanelImpuesto.Controls.Add(this.si);
            this.PanelImpuesto.Location = new System.Drawing.Point(37, 154);
            this.PanelImpuesto.Name = "PanelImpuesto";
            this.PanelImpuesto.Size = new System.Drawing.Size(563, 99);
            this.PanelImpuesto.TabIndex = 590;
            // 
            // panelImpuestos
            // 
            this.panelImpuestos.Controls.Add(this.Panel12);
            this.panelImpuestos.Controls.Add(this.txtimpuesto);
            this.panelImpuestos.Controls.Add(this.Label14);
            this.panelImpuestos.Controls.Add(this.txtporcentaje);
            this.panelImpuestos.Location = new System.Drawing.Point(41, 39);
            this.panelImpuestos.Name = "panelImpuestos";
            this.panelImpuestos.Size = new System.Drawing.Size(233, 41);
            this.panelImpuestos.TabIndex = 564;
            this.panelImpuestos.Visible = false;
            // 
            // Panel12
            // 
            this.Panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(204)))), ((int)(((byte)(1)))));
            this.Panel12.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.Panel12.Location = new System.Drawing.Point(0, 37);
            this.Panel12.Name = "Panel12";
            this.Panel12.Size = new System.Drawing.Size(233, 4);
            this.Panel12.TabIndex = 555;
            // 
            // txtimpuesto
            // 
            this.txtimpuesto.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.txtimpuesto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.txtimpuesto.FormattingEnabled = true;
            this.txtimpuesto.Items.AddRange(new object[] {
            "IGV ",
            "IVA"});
            this.txtimpuesto.Location = new System.Drawing.Point(3, 3);
            this.txtimpuesto.Name = "txtimpuesto";
            this.txtimpuesto.Size = new System.Drawing.Size(64, 28);
            this.txtimpuesto.TabIndex = 553;
            this.txtimpuesto.Text = "IGV";
            // 
            // Label14
            // 
            this.Label14.AutoSize = true;
            this.Label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Label14.ForeColor = System.Drawing.Color.Black;
            this.Label14.Location = new System.Drawing.Point(158, 6);
            this.Label14.Name = "Label14";
            this.Label14.Size = new System.Drawing.Size(23, 20);
            this.Label14.TabIndex = 342;
            this.Label14.Text = "%";
            // 
            // txtporcentaje
            // 
            this.txtporcentaje.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.txtporcentaje.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.txtporcentaje.FormattingEnabled = true;
            this.txtporcentaje.Items.AddRange(new object[] {
            "21",
            "18",
            "3",
            "5"});
            this.txtporcentaje.Location = new System.Drawing.Point(88, 3);
            this.txtporcentaje.Name = "txtporcentaje";
            this.txtporcentaje.Size = new System.Drawing.Size(64, 28);
            this.txtporcentaje.TabIndex = 553;
            this.txtporcentaje.Text = "18";
            // 
            // Label16
            // 
            this.Label16.AutoSize = true;
            this.Label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.Label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Label16.Location = new System.Drawing.Point(31, 10);
            this.Label16.Name = "Label16";
            this.Label16.Size = new System.Drawing.Size(210, 20);
            this.Label16.TabIndex = 342;
            this.Label16.Text = "¿Vender con Impuestos?";
            // 
            // no
            // 
            this.no.AutoSize = true;
            this.no.Checked = true;
            this.no.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold);
            this.no.Location = new System.Drawing.Point(320, 5);
            this.no.Name = "no";
            this.no.Size = new System.Drawing.Size(59, 28);
            this.no.TabIndex = 555;
            this.no.TabStop = true;
            this.no.Text = "NO";
            this.no.UseVisualStyleBackColor = true;
            this.no.CheckedChanged += new System.EventHandler(this.no_CheckedChanged);
            // 
            // si
            // 
            this.si.AutoSize = true;
            this.si.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold);
            this.si.Location = new System.Drawing.Point(268, 5);
            this.si.Name = "si";
            this.si.Size = new System.Drawing.Size(46, 28);
            this.si.TabIndex = 555;
            this.si.Text = "SI";
            this.si.UseVisualStyleBackColor = true;
            this.si.CheckedChanged += new System.EventHandler(this.si_CheckedChanged);
            // 
            // Panel6
            // 
            this.Panel6.BackColor = System.Drawing.Color.White;
            this.Panel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Panel6.Controls.Add(this.txtmoneda);
            this.Panel6.Controls.Add(this.lbleditarLogo);
            this.Panel6.Controls.Add(this.ImagenEmpresa);
            this.Panel6.Controls.Add(this.Panel5);
            this.Panel6.Controls.Add(this.txtrazonsocial);
            this.Panel6.Controls.Add(this.lblempresa);
            this.Panel6.Controls.Add(this.Label8);
            this.Panel6.Location = new System.Drawing.Point(37, 9);
            this.Panel6.Name = "Panel6";
            this.Panel6.Size = new System.Drawing.Size(564, 137);
            this.Panel6.TabIndex = 589;
            // 
            // txtmoneda
            // 
            this.txtmoneda.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtmoneda.DropDownWidth = 230;
            this.txtmoneda.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.txtmoneda.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.txtmoneda.FormattingEnabled = true;
            this.txtmoneda.IntegralHeight = false;
            this.txtmoneda.Items.AddRange(new object[] {
            "$",
            "₡",
            "Q",
            "L",
            "C$",
            "B/.",
            "$",
            "$",
            "$",
            "$",
            "Bs.",
            "$",
            "$",
            "$",
            "₲",
            "S/.",
            "$",
            "Bs F",
            "€"});
            this.txtmoneda.Location = new System.Drawing.Point(221, 72);
            this.txtmoneda.Name = "txtmoneda";
            this.txtmoneda.Size = new System.Drawing.Size(83, 28);
            this.txtmoneda.TabIndex = 590;
            // 
            // lbleditarLogo
            // 
            this.lbleditarLogo.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbleditarLogo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbleditarLogo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.lbleditarLogo.ForeColor = System.Drawing.Color.White;
            this.lbleditarLogo.Location = new System.Drawing.Point(25, 106);
            this.lbleditarLogo.Name = "lbleditarLogo";
            this.lbleditarLogo.Size = new System.Drawing.Size(107, 22);
            this.lbleditarLogo.TabIndex = 588;
            this.lbleditarLogo.Text = "Cambiar";
            this.lbleditarLogo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbleditarLogo.Click += new System.EventHandler(this.lbleditarLogo_Click);
            // 
            // ImagenEmpresa
            // 
            this.ImagenEmpresa.Image = ((System.Drawing.Image)(resources.GetObject("ImagenEmpresa.Image")));
            this.ImagenEmpresa.Location = new System.Drawing.Point(25, 20);
            this.ImagenEmpresa.Name = "ImagenEmpresa";
            this.ImagenEmpresa.Size = new System.Drawing.Size(107, 108);
            this.ImagenEmpresa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ImagenEmpresa.TabIndex = 533;
            this.ImagenEmpresa.TabStop = false;
            // 
            // Panel5
            // 
            this.Panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(204)))), ((int)(((byte)(1)))));
            this.Panel5.Location = new System.Drawing.Point(140, 45);
            this.Panel5.Name = "Panel5";
            this.Panel5.Size = new System.Drawing.Size(400, 2);
            this.Panel5.TabIndex = 554;
            // 
            // txtrazonsocial
            // 
            this.txtrazonsocial.BackColor = System.Drawing.Color.White;
            this.txtrazonsocial.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtrazonsocial.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtrazonsocial.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtrazonsocial.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.txtrazonsocial.ForeColor = System.Drawing.Color.Black;
            this.txtrazonsocial.Location = new System.Drawing.Point(140, 22);
            this.txtrazonsocial.Name = "txtrazonsocial";
            this.txtrazonsocial.Size = new System.Drawing.Size(360, 22);
            this.txtrazonsocial.TabIndex = 532;
            this.txtrazonsocial.Text = "NOMBRE DE TU EMPRESA";
            // 
            // lblempresa
            // 
            this.lblempresa.AutoSize = true;
            this.lblempresa.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.lblempresa.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblempresa.Location = new System.Drawing.Point(137, 4);
            this.lblempresa.Name = "lblempresa";
            this.lblempresa.Size = new System.Drawing.Size(155, 15);
            this.lblempresa.TabIndex = 342;
            this.lblempresa.Text = "Nombre de tu Empresa";
            this.lblempresa.Visible = false;
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.Label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Label8.Location = new System.Drawing.Point(140, 75);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(78, 20);
            this.Label8.TabIndex = 342;
            this.Label8.Text = "moneda:";
            // 
            // TabControl3
            // 
            this.TabControl3.Controls.Add(this.TabPage5);
            this.TabControl3.Controls.Add(this.TabPage6);
            this.TabControl3.Location = new System.Drawing.Point(132, 773);
            this.TabControl3.Name = "TabControl3";
            this.TabControl3.SelectedIndex = 0;
            this.TabControl3.Size = new System.Drawing.Size(396, 95);
            this.TabControl3.TabIndex = 350;
            // 
            // TabPage5
            // 
            this.TabPage5.Controls.Add(this.Label4);
            this.TabPage5.Location = new System.Drawing.Point(4, 22);
            this.TabPage5.Name = "TabPage5";
            this.TabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage5.Size = new System.Drawing.Size(388, 69);
            this.TabPage5.TabIndex = 0;
            this.TabPage5.Text = "Registro sanitario de Ingreso";
            this.TabPage5.UseVisualStyleBackColor = true;
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.ForeColor = System.Drawing.Color.Black;
            this.Label4.Location = new System.Drawing.Point(12, 31);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(144, 13);
            this.Label4.TabIndex = 341;
            this.Label4.Text = "Registro sanitario de Ingreso:";
            // 
            // TabPage6
            // 
            this.TabPage6.Controls.Add(this.PictureBox4);
            this.TabPage6.Controls.Add(this.Label17);
            this.TabPage6.Location = new System.Drawing.Point(4, 22);
            this.TabPage6.Name = "TabPage6";
            this.TabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage6.Size = new System.Drawing.Size(388, 69);
            this.TabPage6.TabIndex = 1;
            this.TabPage6.Text = "Ficha tecnica";
            this.TabPage6.UseVisualStyleBackColor = true;
            // 
            // PictureBox4
            // 
            this.PictureBox4.BackColor = System.Drawing.Color.White;
            this.PictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.PictureBox4.Location = new System.Drawing.Point(92, 6);
            this.PictureBox4.Name = "PictureBox4";
            this.PictureBox4.Size = new System.Drawing.Size(79, 57);
            this.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox4.TabIndex = 346;
            this.PictureBox4.TabStop = false;
            // 
            // Label17
            // 
            this.Label17.AutoSize = true;
            this.Label17.ForeColor = System.Drawing.Color.Black;
            this.Label17.Location = new System.Drawing.Point(7, 25);
            this.Label17.Name = "Label17";
            this.Label17.Size = new System.Drawing.Size(74, 13);
            this.Label17.TabIndex = 340;
            this.Label17.Text = "Ficha tecnica:";
            // 
            // dlg
            // 
            this.dlg.FileName = "openFileDialog1";
            // 
            // checConectarsunat
            // 
            this.checConectarsunat.AutoSize = true;
            this.checConectarsunat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checConectarsunat.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.checConectarsunat.Location = new System.Drawing.Point(728, 18);
            this.checConectarsunat.Name = "checConectarsunat";
            this.checConectarsunat.Size = new System.Drawing.Size(180, 24);
            this.checConectarsunat.TabIndex = 617;
            this.checConectarsunat.Text = "Conectar a SUNAT";
            this.checConectarsunat.UseVisualStyleBackColor = true;
            this.checConectarsunat.CheckedChanged += new System.EventHandler(this.checConectarsunat_CheckedChanged);
            // 
            // panelSunat
            // 
            this.panelSunat.BackColor = System.Drawing.Color.White;
            this.panelSunat.Controls.Add(this.panel1);
            this.panelSunat.Controls.Add(this.panel10);
            this.panelSunat.Controls.Add(this.panel3);
            this.panelSunat.Controls.Add(this.panel22);
            this.panelSunat.Controls.Add(this.panel20);
            this.panelSunat.Controls.Add(this.panel18);
            this.panelSunat.Controls.Add(this.panel14);
            this.panelSunat.Controls.Add(this.psunat);
            this.panelSunat.Controls.Add(this.panel9);
            this.panelSunat.Controls.Add(this.panel7);
            this.panelSunat.Location = new System.Drawing.Point(725, 59);
            this.panelSunat.Name = "panelSunat";
            this.panelSunat.Size = new System.Drawing.Size(456, 565);
            this.panelSunat.TabIndex = 616;
            this.panelSunat.Visible = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txtCodigoMoneda);
            this.panel1.Controls.Add(this.panel15);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 420);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(456, 52);
            this.panel1.TabIndex = 628;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(139, 20);
            this.label1.TabIndex = 620;
            this.label1.Text = "Codigo moneda:";
            // 
            // txtCodigoMoneda
            // 
            this.txtCodigoMoneda.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtCodigoMoneda.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCodigoMoneda.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtCodigoMoneda.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtCodigoMoneda.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtCodigoMoneda.ForeColor = System.Drawing.Color.Black;
            this.txtCodigoMoneda.Location = new System.Drawing.Point(0, 29);
            this.txtCodigoMoneda.Name = "txtCodigoMoneda";
            this.txtCodigoMoneda.Size = new System.Drawing.Size(456, 22);
            this.txtCodigoMoneda.TabIndex = 618;
            this.txtCodigoMoneda.Text = "--------";
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(204)))), ((int)(((byte)(1)))));
            this.panel15.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel15.Location = new System.Drawing.Point(0, 51);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(456, 1);
            this.panel15.TabIndex = 619;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.label19);
            this.panel10.Controls.Add(this.txtdistrito);
            this.panel10.Controls.Add(this.label15);
            this.panel10.Controls.Add(this.txtprovincia);
            this.panel10.Controls.Add(this.label13);
            this.panel10.Controls.Add(this.txtdepartamento);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel10.Location = new System.Drawing.Point(0, 353);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(456, 67);
            this.panel10.TabIndex = 627;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.label19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label19.Location = new System.Drawing.Point(305, 8);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(63, 18);
            this.label19.TabIndex = 621;
            this.label19.Text = "Distrito";
            // 
            // txtdistrito
            // 
            this.txtdistrito.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdistrito.FormattingEnabled = true;
            this.txtdistrito.Location = new System.Drawing.Point(309, 31);
            this.txtdistrito.Name = "txtdistrito";
            this.txtdistrito.Size = new System.Drawing.Size(135, 26);
            this.txtdistrito.TabIndex = 0;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label15.Location = new System.Drawing.Point(140, 8);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(78, 18);
            this.label15.TabIndex = 621;
            this.label15.Text = "Provincia";
            // 
            // txtprovincia
            // 
            this.txtprovincia.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtprovincia.FormattingEnabled = true;
            this.txtprovincia.Location = new System.Drawing.Point(145, 31);
            this.txtprovincia.Name = "txtprovincia";
            this.txtprovincia.Size = new System.Drawing.Size(159, 26);
            this.txtprovincia.TabIndex = 0;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label13.Location = new System.Drawing.Point(0, 8);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(114, 18);
            this.label13.TabIndex = 621;
            this.label13.Text = "Departamento";
            // 
            // txtdepartamento
            // 
            this.txtdepartamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdepartamento.FormattingEnabled = true;
            this.txtdepartamento.Location = new System.Drawing.Point(4, 31);
            this.txtdepartamento.Name = "txtdepartamento";
            this.txtdepartamento.Size = new System.Drawing.Size(135, 26);
            this.txtdepartamento.TabIndex = 0;
            this.txtdepartamento.Text = "hgj";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.txtdireccionfiscal);
            this.panel3.Controls.Add(this.panel8);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 301);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(456, 52);
            this.panel3.TabIndex = 626;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label12.Location = new System.Drawing.Point(0, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(136, 20);
            this.label12.TabIndex = 620;
            this.label12.Text = "Direccion fiscal:";
            // 
            // txtdireccionfiscal
            // 
            this.txtdireccionfiscal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtdireccionfiscal.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtdireccionfiscal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtdireccionfiscal.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtdireccionfiscal.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtdireccionfiscal.ForeColor = System.Drawing.Color.Black;
            this.txtdireccionfiscal.Location = new System.Drawing.Point(0, 29);
            this.txtdireccionfiscal.Name = "txtdireccionfiscal";
            this.txtdireccionfiscal.Size = new System.Drawing.Size(456, 22);
            this.txtdireccionfiscal.TabIndex = 618;
            this.txtdireccionfiscal.Text = "--------";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(204)))), ((int)(((byte)(1)))));
            this.panel8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel8.Location = new System.Drawing.Point(0, 51);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(456, 1);
            this.panel8.TabIndex = 619;
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.cbxServidor);
            this.panel22.Controls.Add(this.label11);
            this.panel22.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel22.Location = new System.Drawing.Point(0, 261);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(456, 40);
            this.panel22.TabIndex = 625;
            // 
            // cbxServidor
            // 
            this.cbxServidor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxServidor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxServidor.FormattingEnabled = true;
            this.cbxServidor.Items.AddRange(new object[] {
            "Pruebas",
            "Produccion"});
            this.cbxServidor.Location = new System.Drawing.Point(156, 6);
            this.cbxServidor.Name = "cbxServidor";
            this.cbxServidor.Size = new System.Drawing.Size(137, 28);
            this.cbxServidor.TabIndex = 0;
            // 
            // label11
            // 
            this.label11.Dock = System.Windows.Forms.DockStyle.Left;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label11.Location = new System.Drawing.Point(0, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(150, 40);
            this.label11.TabIndex = 343;
            this.label11.Text = "Servidor SUNAT:";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.label10);
            this.panel20.Controls.Add(this.txtContraseñaSunat);
            this.panel20.Controls.Add(this.panel21);
            this.panel20.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel20.Location = new System.Drawing.Point(0, 209);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(456, 52);
            this.panel20.TabIndex = 624;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label10.Location = new System.Drawing.Point(0, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(264, 20);
            this.label10.TabIndex = 620;
            this.label10.Text = "Contraseña secundaria SUNAT:";
            // 
            // txtContraseñaSunat
            // 
            this.txtContraseñaSunat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtContraseñaSunat.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtContraseñaSunat.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtContraseñaSunat.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtContraseñaSunat.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtContraseñaSunat.ForeColor = System.Drawing.Color.Black;
            this.txtContraseñaSunat.Location = new System.Drawing.Point(0, 29);
            this.txtContraseñaSunat.Name = "txtContraseñaSunat";
            this.txtContraseñaSunat.PasswordChar = '*';
            this.txtContraseñaSunat.Size = new System.Drawing.Size(456, 22);
            this.txtContraseñaSunat.TabIndex = 618;
            this.txtContraseñaSunat.Text = "--------";
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(204)))), ((int)(((byte)(1)))));
            this.panel21.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel21.Location = new System.Drawing.Point(0, 51);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(456, 1);
            this.panel21.TabIndex = 619;
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.label6);
            this.panel18.Controls.Add(this.txtUsuarioSunat);
            this.panel18.Controls.Add(this.panel19);
            this.panel18.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel18.Location = new System.Drawing.Point(0, 148);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(456, 61);
            this.panel18.TabIndex = 623;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label6.Location = new System.Drawing.Point(0, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(233, 20);
            this.label6.TabIndex = 620;
            this.label6.Text = "Usuario secundario SUNAT:";
            // 
            // txtUsuarioSunat
            // 
            this.txtUsuarioSunat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtUsuarioSunat.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtUsuarioSunat.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtUsuarioSunat.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtUsuarioSunat.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtUsuarioSunat.ForeColor = System.Drawing.Color.Black;
            this.txtUsuarioSunat.Location = new System.Drawing.Point(0, 38);
            this.txtUsuarioSunat.Name = "txtUsuarioSunat";
            this.txtUsuarioSunat.Size = new System.Drawing.Size(456, 22);
            this.txtUsuarioSunat.TabIndex = 618;
            this.txtUsuarioSunat.Text = "--------";
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(204)))), ((int)(((byte)(1)))));
            this.panel19.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel19.Location = new System.Drawing.Point(0, 60);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(456, 1);
            this.panel19.TabIndex = 619;
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.label5);
            this.panel14.Controls.Add(this.txtContraseñaCert);
            this.panel14.Controls.Add(this.panel17);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel14.Location = new System.Drawing.Point(0, 91);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(456, 57);
            this.panel14.TabIndex = 622;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label5.Location = new System.Drawing.Point(0, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(196, 20);
            this.label5.TabIndex = 620;
            this.label5.Text = "Contraseña certificado:";
            // 
            // txtContraseñaCert
            // 
            this.txtContraseñaCert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtContraseñaCert.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtContraseñaCert.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtContraseñaCert.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtContraseñaCert.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtContraseñaCert.ForeColor = System.Drawing.Color.Black;
            this.txtContraseñaCert.Location = new System.Drawing.Point(0, 34);
            this.txtContraseñaCert.Name = "txtContraseñaCert";
            this.txtContraseñaCert.PasswordChar = '*';
            this.txtContraseñaCert.Size = new System.Drawing.Size(456, 22);
            this.txtContraseñaCert.TabIndex = 618;
            this.txtContraseñaCert.Text = "--------";
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(204)))), ((int)(((byte)(1)))));
            this.panel17.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel17.Location = new System.Drawing.Point(0, 56);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(456, 1);
            this.panel17.TabIndex = 619;
            // 
            // psunat
            // 
            this.psunat.BackColor = System.Drawing.Color.White;
            this.psunat.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.psunat.Image = global::RestCsharp.Properties.Resources.sunat;
            this.psunat.Location = new System.Drawing.Point(0, 506);
            this.psunat.Name = "psunat";
            this.psunat.Size = new System.Drawing.Size(456, 59);
            this.psunat.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.psunat.TabIndex = 0;
            this.psunat.TabStop = false;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.label3);
            this.panel9.Controls.Add(this.txtCertificado);
            this.panel9.Controls.Add(this.panel11);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel9.Location = new System.Drawing.Point(0, 30);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(456, 61);
            this.panel9.TabIndex = 621;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label3.Location = new System.Drawing.Point(0, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(270, 20);
            this.label3.TabIndex = 620;
            this.label3.Text = "Ruta certificado (Haz click aqui):";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // txtCertificado
            // 
            this.txtCertificado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtCertificado.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCertificado.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtCertificado.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtCertificado.Enabled = false;
            this.txtCertificado.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtCertificado.ForeColor = System.Drawing.Color.Black;
            this.txtCertificado.Location = new System.Drawing.Point(0, 38);
            this.txtCertificado.Name = "txtCertificado";
            this.txtCertificado.ReadOnly = true;
            this.txtCertificado.Size = new System.Drawing.Size(456, 22);
            this.txtCertificado.TabIndex = 618;
            this.txtCertificado.Text = "-";
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(204)))), ((int)(((byte)(1)))));
            this.panel11.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel11.Location = new System.Drawing.Point(0, 60);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(456, 1);
            this.panel11.TabIndex = 619;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.txtRuc);
            this.panel7.Controls.Add(this.panel4);
            this.panel7.Controls.Add(this.label2);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(456, 30);
            this.panel7.TabIndex = 620;
            // 
            // txtRuc
            // 
            this.txtRuc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtRuc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRuc.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtRuc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtRuc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtRuc.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtRuc.ForeColor = System.Drawing.Color.Black;
            this.txtRuc.Location = new System.Drawing.Point(46, 0);
            this.txtRuc.MaxLength = 11;
            this.txtRuc.Name = "txtRuc";
            this.txtRuc.Size = new System.Drawing.Size(410, 22);
            this.txtRuc.TabIndex = 618;
            this.txtRuc.Text = "-";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(204)))), ((int)(((byte)(1)))));
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(46, 29);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(410, 1);
            this.panel4.TabIndex = 619;
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Left;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 30);
            this.label2.TabIndex = 620;
            this.label2.Text = "Ruc:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Eempresa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1265, 695);
            this.Controls.Add(this.checConectarsunat);
            this.Controls.Add(this.panelSunat);
            this.Controls.Add(this.PanelEmpresa);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Eempresa";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Eempresa";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Eempresa_Load);
            this.PanelEmpresa.ResumeLayout(false);
            this.Panel2.ResumeLayout(false);
            this.Panel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ToolStrip1.ResumeLayout(false);
            this.ToolStrip1.PerformLayout();
            this.PanelImpuesto.ResumeLayout(false);
            this.PanelImpuesto.PerformLayout();
            this.panelImpuestos.ResumeLayout(false);
            this.panelImpuestos.PerformLayout();
            this.Panel6.ResumeLayout(false);
            this.Panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ImagenEmpresa)).EndInit();
            this.TabControl3.ResumeLayout(false);
            this.TabPage5.ResumeLayout(false);
            this.TabPage5.PerformLayout();
            this.TabPage6.ResumeLayout(false);
            this.TabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox4)).EndInit();
            this.panelSunat.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel22.ResumeLayout(false);
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.psunat)).EndInit();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Panel PanelEmpresa;
        private System.Windows.Forms.Button btnsiguiente;
        internal System.Windows.Forms.Panel Panel2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton chPorpedido;
        private System.Windows.Forms.RadioButton chGeneral;
        internal System.Windows.Forms.TextBox txtRuta;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.ToolStrip ToolStrip1;
        internal System.Windows.Forms.ToolStripButton ToolStripButton22;
        internal System.Windows.Forms.Panel PanelImpuesto;
        internal System.Windows.Forms.Panel panelImpuestos;
        internal System.Windows.Forms.Panel Panel12;
        internal System.Windows.Forms.ComboBox txtimpuesto;
        internal System.Windows.Forms.Label Label14;
        internal System.Windows.Forms.ComboBox txtporcentaje;
        internal System.Windows.Forms.Label Label16;
        internal System.Windows.Forms.RadioButton no;
        internal System.Windows.Forms.RadioButton si;
        internal System.Windows.Forms.Panel Panel6;
        internal System.Windows.Forms.ComboBox txtmoneda;
        internal System.Windows.Forms.Label lbleditarLogo;
        internal System.Windows.Forms.PictureBox ImagenEmpresa;
        internal System.Windows.Forms.Panel Panel5;
        internal System.Windows.Forms.TextBox txtrazonsocial;
        internal System.Windows.Forms.Label lblempresa;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.TabControl TabControl3;
        internal System.Windows.Forms.TabPage TabPage5;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.TabPage TabPage6;
        internal System.Windows.Forms.PictureBox PictureBox4;
        internal System.Windows.Forms.Label Label17;
        private System.Windows.Forms.OpenFileDialog dlg;
        private System.Windows.Forms.FolderBrowserDialog Fbd;
        private System.Windows.Forms.CheckBox checConectarsunat;
        private System.Windows.Forms.Panel panelSunat;
        private System.Windows.Forms.Panel panel1;
        internal System.Windows.Forms.Label label1;
        internal System.Windows.Forms.TextBox txtCodigoMoneda;
        internal System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel10;
        internal System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox txtdistrito;
        internal System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox txtprovincia;
        internal System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox txtdepartamento;
        private System.Windows.Forms.Panel panel3;
        internal System.Windows.Forms.Label label12;
        internal System.Windows.Forms.TextBox txtdireccionfiscal;
        internal System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.ComboBox cbxServidor;
        internal System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel20;
        internal System.Windows.Forms.Label label10;
        internal System.Windows.Forms.TextBox txtContraseñaSunat;
        internal System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel18;
        internal System.Windows.Forms.Label label6;
        internal System.Windows.Forms.TextBox txtUsuarioSunat;
        internal System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel14;
        internal System.Windows.Forms.Label label5;
        internal System.Windows.Forms.TextBox txtContraseñaCert;
        internal System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.PictureBox psunat;
        private System.Windows.Forms.Panel panel9;
        internal System.Windows.Forms.Label label3;
        internal System.Windows.Forms.TextBox txtCertificado;
        internal System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel7;
        internal System.Windows.Forms.TextBox txtRuc;
        internal System.Windows.Forms.Panel panel4;
        internal System.Windows.Forms.Label label2;
    }
}