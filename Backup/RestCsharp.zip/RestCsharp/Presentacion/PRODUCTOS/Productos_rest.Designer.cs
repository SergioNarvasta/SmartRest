﻿namespace RestCsharp.Presentacion.PRODUCTOS
{
    partial class Productos_rest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Productos_rest));
            this.panel1 = new System.Windows.Forms.Panel();
            this.Panel_grupos = new System.Windows.Forms.FlowLayoutPanel();
            this.Panel5 = new System.Windows.Forms.Panel();
            this.Label4 = new System.Windows.Forms.Label();
            this.PictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.MenuStrip2 = new System.Windows.Forms.MenuStrip();
            this.ToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.EditarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ElimarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.RestaurarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.editarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.eliminarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtgrupo = new System.Windows.Forms.TextBox();
            this.btnagregar = new System.Windows.Forms.Button();
            this.PanelvisorProductos = new System.Windows.Forms.Panel();
            this.PanelProductos = new System.Windows.Forms.FlowLayoutPanel();
            this.Panel9 = new System.Windows.Forms.Panel();
            this.Panel11 = new System.Windows.Forms.Panel();
            this.Panel29 = new System.Windows.Forms.Panel();
            this.PictureBox3 = new System.Windows.Forms.PictureBox();
            this.txtbuscarproductos = new System.Windows.Forms.TextBox();
            this.MenuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.PanelBienvienida = new System.Windows.Forms.Panel();
            this.Label3 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.Panel_grupos.SuspendLayout();
            this.Panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox2)).BeginInit();
            this.panel3.SuspendLayout();
            this.MenuStrip2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.PanelvisorProductos.SuspendLayout();
            this.Panel9.SuspendLayout();
            this.Panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox3)).BeginInit();
            this.MenuStrip1.SuspendLayout();
            this.PanelBienvienida.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.panel1.Controls.Add(this.Panel_grupos);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(397, 601);
            this.panel1.TabIndex = 1;
            // 
            // Panel_grupos
            // 
            this.Panel_grupos.AutoScroll = true;
            this.Panel_grupos.Controls.Add(this.Panel5);
            this.Panel_grupos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Panel_grupos.Location = new System.Drawing.Point(0, 105);
            this.Panel_grupos.Name = "Panel_grupos";
            this.Panel_grupos.Size = new System.Drawing.Size(397, 496);
            this.Panel_grupos.TabIndex = 1;
            // 
            // Panel5
            // 
            this.Panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.Panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Panel5.Controls.Add(this.Label4);
            this.Panel5.Controls.Add(this.PictureBox2);
            this.Panel5.Controls.Add(this.panel3);
            this.Panel5.Location = new System.Drawing.Point(3, 3);
            this.Panel5.Name = "Panel5";
            this.Panel5.Size = new System.Drawing.Size(140, 133);
            this.Panel5.TabIndex = 1;
            // 
            // Label4
            // 
            this.Label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Label4.ForeColor = System.Drawing.Color.White;
            this.Label4.Location = new System.Drawing.Point(0, 102);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(138, 29);
            this.Label4.TabIndex = 1;
            this.Label4.Text = "Cervezas";
            this.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PictureBox2
            // 
            this.PictureBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.PictureBox2.Location = new System.Drawing.Point(0, 36);
            this.PictureBox2.Name = "PictureBox2";
            this.PictureBox2.Size = new System.Drawing.Size(138, 66);
            this.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PictureBox2.TabIndex = 0;
            this.PictureBox2.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel3.Controls.Add(this.MenuStrip2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(138, 36);
            this.panel3.TabIndex = 2;
            // 
            // MenuStrip2
            // 
            this.MenuStrip2.AutoSize = false;
            this.MenuStrip2.BackColor = System.Drawing.Color.Silver;
            this.MenuStrip2.Dock = System.Windows.Forms.DockStyle.Right;
            this.MenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem2,
            this.toolStripMenuItem1});
            this.MenuStrip2.Location = new System.Drawing.Point(113, 0);
            this.MenuStrip2.Name = "MenuStrip2";
            this.MenuStrip2.Size = new System.Drawing.Size(25, 36);
            this.MenuStrip2.TabIndex = 8;
            this.MenuStrip2.Text = "MenuStrip2";
            // 
            // ToolStripMenuItem2
            // 
            this.ToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.EditarToolStripMenuItem,
            this.ElimarToolStripMenuItem,
            this.RestaurarToolStripMenuItem});
            this.ToolStripMenuItem2.Name = "ToolStripMenuItem2";
            this.ToolStripMenuItem2.Size = new System.Drawing.Size(18, 4);
            // 
            // EditarToolStripMenuItem
            // 
            this.EditarToolStripMenuItem.Name = "EditarToolStripMenuItem";
            this.EditarToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.EditarToolStripMenuItem.Text = "Editar";
            // 
            // ElimarToolStripMenuItem
            // 
            this.ElimarToolStripMenuItem.Name = "ElimarToolStripMenuItem";
            this.ElimarToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.ElimarToolStripMenuItem.Text = "Eliminar";
            // 
            // RestaurarToolStripMenuItem
            // 
            this.RestaurarToolStripMenuItem.Name = "RestaurarToolStripMenuItem";
            this.RestaurarToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.RestaurarToolStripMenuItem.Text = "Restaurar";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editarToolStripMenuItem1,
            this.eliminarToolStripMenuItem});
            this.toolStripMenuItem1.Image = global::RestCsharp.Properties.Resources.menuCajas_claro;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(18, 20);
            // 
            // editarToolStripMenuItem1
            // 
            this.editarToolStripMenuItem1.Name = "editarToolStripMenuItem1";
            this.editarToolStripMenuItem1.Size = new System.Drawing.Size(117, 22);
            this.editarToolStripMenuItem1.Text = "Editar";
            // 
            // eliminarToolStripMenuItem
            // 
            this.eliminarToolStripMenuItem.Name = "eliminarToolStripMenuItem";
            this.eliminarToolStripMenuItem.Size = new System.Drawing.Size(117, 22);
            this.eliminarToolStripMenuItem.Text = "Eliminar";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.btnagregar);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(397, 105);
            this.panel2.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(43)))), ((int)(((byte)(43)))));
            this.panel4.Controls.Add(this.pictureBox1);
            this.panel4.Controls.Add(this.txtgrupo);
            this.panel4.Location = new System.Drawing.Point(13, 65);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(292, 34);
            this.panel4.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(261, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(28, 20);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // txtgrupo
            // 
            this.txtgrupo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(43)))), ((int)(((byte)(43)))));
            this.txtgrupo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtgrupo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtgrupo.ForeColor = System.Drawing.Color.White;
            this.txtgrupo.Location = new System.Drawing.Point(3, 10);
            this.txtgrupo.Name = "txtgrupo";
            this.txtgrupo.Size = new System.Drawing.Size(243, 19);
            this.txtgrupo.TabIndex = 0;
            this.txtgrupo.TextChanged += new System.EventHandler(this.txtgrupo_TextChanged);
            // 
            // btnagregar
            // 
            this.btnagregar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnagregar.FlatAppearance.BorderSize = 0;
            this.btnagregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnagregar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnagregar.ForeColor = System.Drawing.Color.White;
            this.btnagregar.Location = new System.Drawing.Point(12, 12);
            this.btnagregar.Name = "btnagregar";
            this.btnagregar.Size = new System.Drawing.Size(143, 47);
            this.btnagregar.TabIndex = 0;
            this.btnagregar.Text = "+ Agregar Grupo";
            this.btnagregar.UseVisualStyleBackColor = false;
            this.btnagregar.Click += new System.EventHandler(this.button1_Click);
            // 
            // PanelvisorProductos
            // 
            this.PanelvisorProductos.Controls.Add(this.PanelProductos);
            this.PanelvisorProductos.Controls.Add(this.Panel9);
            this.PanelvisorProductos.Location = new System.Drawing.Point(413, 65);
            this.PanelvisorProductos.Name = "PanelvisorProductos";
            this.PanelvisorProductos.Size = new System.Drawing.Size(443, 332);
            this.PanelvisorProductos.TabIndex = 7;
            // 
            // PanelProductos
            // 
            this.PanelProductos.BackColor = System.Drawing.Color.Black;
            this.PanelProductos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelProductos.Location = new System.Drawing.Point(0, 40);
            this.PanelProductos.Name = "PanelProductos";
            this.PanelProductos.Size = new System.Drawing.Size(443, 292);
            this.PanelProductos.TabIndex = 4;
            // 
            // Panel9
            // 
            this.Panel9.BackColor = System.Drawing.Color.Black;
            this.Panel9.Controls.Add(this.Panel11);
            this.Panel9.Controls.Add(this.MenuStrip1);
            this.Panel9.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel9.Location = new System.Drawing.Point(0, 0);
            this.Panel9.Name = "Panel9";
            this.Panel9.Size = new System.Drawing.Size(443, 40);
            this.Panel9.TabIndex = 617;
            // 
            // Panel11
            // 
            this.Panel11.BackColor = System.Drawing.Color.Transparent;
            this.Panel11.Controls.Add(this.Panel29);
            this.Panel11.Controls.Add(this.PictureBox3);
            this.Panel11.Controls.Add(this.txtbuscarproductos);
            this.Panel11.Location = new System.Drawing.Point(194, 4);
            this.Panel11.Name = "Panel11";
            this.Panel11.Size = new System.Drawing.Size(300, 34);
            this.Panel11.TabIndex = 617;
            // 
            // Panel29
            // 
            this.Panel29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Panel29.Location = new System.Drawing.Point(9, 28);
            this.Panel29.Name = "Panel29";
            this.Panel29.Size = new System.Drawing.Size(255, 1);
            this.Panel29.TabIndex = 534;
            // 
            // PictureBox3
            // 
            this.PictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox3.Image")));
            this.PictureBox3.Location = new System.Drawing.Point(267, 8);
            this.PictureBox3.Name = "PictureBox3";
            this.PictureBox3.Size = new System.Drawing.Size(21, 17);
            this.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PictureBox3.TabIndex = 3;
            this.PictureBox3.TabStop = false;
            // 
            // txtbuscarproductos
            // 
            this.txtbuscarproductos.BackColor = System.Drawing.Color.Black;
            this.txtbuscarproductos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtbuscarproductos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtbuscarproductos.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.txtbuscarproductos.ForeColor = System.Drawing.Color.White;
            this.txtbuscarproductos.Location = new System.Drawing.Point(9, 9);
            this.txtbuscarproductos.Name = "txtbuscarproductos";
            this.txtbuscarproductos.Size = new System.Drawing.Size(252, 16);
            this.txtbuscarproductos.TabIndex = 2;
            this.txtbuscarproductos.TextChanged += new System.EventHandler(this.txtbuscarproductos_TextChanged);
            // 
            // MenuStrip1
            // 
            this.MenuStrip1.AutoSize = false;
            this.MenuStrip1.BackColor = System.Drawing.Color.Transparent;
            this.MenuStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.MenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem3});
            this.MenuStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.MenuStrip1.Location = new System.Drawing.Point(0, 0);
            this.MenuStrip1.Name = "MenuStrip1";
            this.MenuStrip1.ShowItemToolTips = true;
            this.MenuStrip1.Size = new System.Drawing.Size(224, 40);
            this.MenuStrip1.TabIndex = 616;
            this.MenuStrip1.Text = "MenuStrip3";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.toolStripMenuItem3.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.toolStripMenuItem3.ForeColor = System.Drawing.Color.White;
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(157, 36);
            this.toolStripMenuItem3.Text = "+ Agregar Producto";
            this.toolStripMenuItem3.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.toolStripMenuItem3.ToolTipText = "+ Agregar Grupo";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // PanelBienvienida
            // 
            this.PanelBienvienida.BackColor = System.Drawing.Color.Black;
            this.PanelBienvienida.Controls.Add(this.Label3);
            this.PanelBienvienida.Location = new System.Drawing.Point(926, 97);
            this.PanelBienvienida.Name = "PanelBienvienida";
            this.PanelBienvienida.Size = new System.Drawing.Size(356, 291);
            this.PanelBienvienida.TabIndex = 10;
            // 
            // Label3
            // 
            this.Label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.ForeColor = System.Drawing.Color.DimGray;
            this.Label3.Location = new System.Drawing.Point(0, 0);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(356, 291);
            this.Label3.TabIndex = 0;
            this.Label3.Text = "Elija un Grupo Para Iniciar ";
            this.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Productos_rest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1323, 601);
            this.Controls.Add(this.PanelBienvienida);
            this.Controls.Add(this.PanelvisorProductos);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Productos_rest";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Productos y grupos";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Productos_rest_Load);
            this.panel1.ResumeLayout(false);
            this.Panel_grupos.ResumeLayout(false);
            this.Panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox2)).EndInit();
            this.panel3.ResumeLayout(false);
            this.MenuStrip2.ResumeLayout(false);
            this.MenuStrip2.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.PanelvisorProductos.ResumeLayout(false);
            this.Panel9.ResumeLayout(false);
            this.Panel11.ResumeLayout(false);
            this.Panel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox3)).EndInit();
            this.MenuStrip1.ResumeLayout(false);
            this.MenuStrip1.PerformLayout();
            this.PanelBienvienida.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.FlowLayoutPanel Panel_grupos;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtgrupo;
        private System.Windows.Forms.Button btnagregar;
        internal System.Windows.Forms.Panel Panel5;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.PictureBox PictureBox2;
        internal System.Windows.Forms.Panel panel3;
        internal System.Windows.Forms.MenuStrip MenuStrip2;
        internal System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem2;
        internal System.Windows.Forms.ToolStripMenuItem EditarToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem ElimarToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem RestaurarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem editarToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem eliminarToolStripMenuItem;
        internal System.Windows.Forms.Panel PanelvisorProductos;
        internal System.Windows.Forms.FlowLayoutPanel PanelProductos;
        internal System.Windows.Forms.Panel Panel9;
        internal System.Windows.Forms.Panel Panel11;
        internal System.Windows.Forms.Panel Panel29;
        internal System.Windows.Forms.PictureBox PictureBox3;
        internal System.Windows.Forms.TextBox txtbuscarproductos;
        internal System.Windows.Forms.MenuStrip MenuStrip1;
        internal System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        internal System.Windows.Forms.Panel PanelBienvienida;
        internal System.Windows.Forms.Label Label3;
    }
}