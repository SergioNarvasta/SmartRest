﻿namespace RestCsharp.Presentacion.PRODUCTOS
{
    partial class Registro_de_productos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Registro_de_productos));
            this.Label1 = new System.Windows.Forms.Label();
            this.btncerrrar = new System.Windows.Forms.Button();
            this.Panel3 = new System.Windows.Forms.Panel();
            this.txtdescripcion = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtprecioventa = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnvolver = new System.Windows.Forms.Button();
            this.btnguardar = new System.Windows.Forms.Button();
            this.PanelIcono = new System.Windows.Forms.Panel();
            this.PictureBox2 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.ImagenProducto = new System.Windows.Forms.PictureBox();
            this.dlg = new System.Windows.Forms.OpenFileDialog();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtpreciocompra = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btncolor = new System.Windows.Forms.Button();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.btnguardarcambios = new System.Windows.Forms.Button();
            this.txtum = new System.Windows.Forms.ComboBox();
            this.Label49 = new System.Windows.Forms.Label();
            this.PictureBox3 = new System.Windows.Forms.PictureBox();
            this.Label27 = new System.Windows.Forms.Label();
            this.txtcodigodebarras = new System.Windows.Forms.TextBox();
            this.btnGenerarCodigo = new System.Windows.Forms.Button();
            this.dgcodigossunat = new System.Windows.Forms.DataGridView();
            this.txtcodigoSunat = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.PanelIcono.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImagenProducto)).BeginInit();
            this.flowLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgcodigossunat)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.Label1.ForeColor = System.Drawing.Color.White;
            this.Label1.Location = new System.Drawing.Point(12, 9);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(148, 37);
            this.Label1.TabIndex = 634;
            this.Label1.Text = "Productos";
            this.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btncerrrar
            // 
            this.btncerrrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.btncerrrar.FlatAppearance.BorderSize = 0;
            this.btncerrrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncerrrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.btncerrrar.ForeColor = System.Drawing.Color.White;
            this.btncerrrar.Location = new System.Drawing.Point(1086, 12);
            this.btncerrrar.Name = "btncerrrar";
            this.btncerrrar.Size = new System.Drawing.Size(64, 64);
            this.btncerrrar.TabIndex = 633;
            this.btncerrrar.Text = "X";
            this.btncerrrar.UseVisualStyleBackColor = false;
            this.btncerrrar.Click += new System.EventHandler(this.btncerrrar_Click);
            // 
            // Panel3
            // 
            this.Panel3.BackColor = System.Drawing.Color.White;
            this.Panel3.Location = new System.Drawing.Point(211, 133);
            this.Panel3.Name = "Panel3";
            this.Panel3.Size = new System.Drawing.Size(284, 1);
            this.Panel3.TabIndex = 635;
            // 
            // txtdescripcion
            // 
            this.txtdescripcion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.txtdescripcion.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtdescripcion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtdescripcion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdescripcion.ForeColor = System.Drawing.Color.White;
            this.txtdescripcion.Location = new System.Drawing.Point(211, 112);
            this.txtdescripcion.Name = "txtdescripcion";
            this.txtdescripcion.Size = new System.Drawing.Size(283, 19);
            this.txtdescripcion.TabIndex = 636;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(102, 113);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 21);
            this.label2.TabIndex = 634;
            this.label2.Text = "Descripcion:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.DarkGray;
            this.label3.Location = new System.Drawing.Point(97, 146);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 21);
            this.label3.TabIndex = 634;
            this.label3.Text = "Precio venta:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtprecioventa
            // 
            this.txtprecioventa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.txtprecioventa.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtprecioventa.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtprecioventa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtprecioventa.ForeColor = System.Drawing.Color.White;
            this.txtprecioventa.Location = new System.Drawing.Point(212, 145);
            this.txtprecioventa.Name = "txtprecioventa";
            this.txtprecioventa.Size = new System.Drawing.Size(283, 19);
            this.txtprecioventa.TabIndex = 636;
            this.txtprecioventa.TextChanged += new System.EventHandler(this.txtprecioventa_TextChanged);
            this.txtprecioventa.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtprecioventa_KeyPress);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(212, 166);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(284, 1);
            this.panel1.TabIndex = 635;
            // 
            // btnvolver
            // 
            this.btnvolver.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnvolver.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnvolver.ForeColor = System.Drawing.Color.Gray;
            this.btnvolver.Location = new System.Drawing.Point(293, 3);
            this.btnvolver.Name = "btnvolver";
            this.btnvolver.Size = new System.Drawing.Size(139, 49);
            this.btnvolver.TabIndex = 637;
            this.btnvolver.Text = "Volver";
            this.btnvolver.UseVisualStyleBackColor = true;
            this.btnvolver.Click += new System.EventHandler(this.btnvolver_Click);
            // 
            // btnguardar
            // 
            this.btnguardar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(198)))), ((int)(((byte)(91)))));
            this.btnguardar.FlatAppearance.BorderSize = 0;
            this.btnguardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnguardar.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold);
            this.btnguardar.ForeColor = System.Drawing.Color.White;
            this.btnguardar.Location = new System.Drawing.Point(3, 3);
            this.btnguardar.Name = "btnguardar";
            this.btnguardar.Size = new System.Drawing.Size(139, 50);
            this.btnguardar.TabIndex = 639;
            this.btnguardar.Text = "Guardar";
            this.btnguardar.UseVisualStyleBackColor = false;
            this.btnguardar.Click += new System.EventHandler(this.Button1_Click);
            // 
            // PanelIcono
            // 
            this.PanelIcono.Controls.Add(this.PictureBox2);
            this.PanelIcono.Controls.Add(this.label4);
            this.PanelIcono.Location = new System.Drawing.Point(225, 419);
            this.PanelIcono.Name = "PanelIcono";
            this.PanelIcono.Size = new System.Drawing.Size(148, 144);
            this.PanelIcono.TabIndex = 641;
            // 
            // PictureBox2
            // 
            this.PictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.PictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PictureBox2.BackgroundImage")));
            this.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PictureBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.PictureBox2.Location = new System.Drawing.Point(0, 91);
            this.PictureBox2.Name = "PictureBox2";
            this.PictureBox2.Size = new System.Drawing.Size(148, 25);
            this.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PictureBox2.TabIndex = 630;
            this.PictureBox2.TabStop = false;
            this.PictureBox2.Click += new System.EventHandler(this.PictureBox2_Click);
            // 
            // label4
            // 
            this.label4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label4.Dock = System.Windows.Forms.DockStyle.Top;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(0, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(148, 91);
            this.label4.TabIndex = 629;
            this.label4.Text = "Agregar Icono\r\n(Opcional)";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // ImagenProducto
            // 
            this.ImagenProducto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ImagenProducto.Image = global::RestCsharp.Properties.Resources.advertencia;
            this.ImagenProducto.Location = new System.Drawing.Point(225, 419);
            this.ImagenProducto.Name = "ImagenProducto";
            this.ImagenProducto.Size = new System.Drawing.Size(283, 144);
            this.ImagenProducto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ImagenProducto.TabIndex = 640;
            this.ImagenProducto.TabStop = false;
            // 
            // dlg
            // 
            this.dlg.FileName = "openFileDialog1";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Location = new System.Drawing.Point(211, 208);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(284, 1);
            this.panel4.TabIndex = 643;
            // 
            // txtpreciocompra
            // 
            this.txtpreciocompra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.txtpreciocompra.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtpreciocompra.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtpreciocompra.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpreciocompra.ForeColor = System.Drawing.Color.White;
            this.txtpreciocompra.Location = new System.Drawing.Point(211, 187);
            this.txtpreciocompra.Name = "txtpreciocompra";
            this.txtpreciocompra.Size = new System.Drawing.Size(283, 19);
            this.txtpreciocompra.TabIndex = 644;
            this.txtpreciocompra.TextChanged += new System.EventHandler(this.txtpreciocompra_TextChanged);
            this.txtpreciocompra.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtpreciocompra_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.DarkGray;
            this.label6.Location = new System.Drawing.Point(91, 188);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(115, 21);
            this.label6.TabIndex = 642;
            this.label6.Text = "Prec. Compra:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Location = new System.Drawing.Point(219, 309);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 20);
            this.label5.TabIndex = 645;
            this.label5.Text = "Color>>";
            // 
            // btncolor
            // 
            this.btncolor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncolor.Location = new System.Drawing.Point(289, 309);
            this.btncolor.Name = "btncolor";
            this.btncolor.Size = new System.Drawing.Size(25, 24);
            this.btncolor.TabIndex = 646;
            this.btncolor.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Location = new System.Drawing.Point(223, 339);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(317, 71);
            this.flowLayoutPanel1.TabIndex = 647;
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Controls.Add(this.btnguardar);
            this.flowLayoutPanel2.Controls.Add(this.btnguardarcambios);
            this.flowLayoutPanel2.Controls.Add(this.btnvolver);
            this.flowLayoutPanel2.Location = new System.Drawing.Point(225, 569);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(443, 78);
            this.flowLayoutPanel2.TabIndex = 648;
            // 
            // btnguardarcambios
            // 
            this.btnguardarcambios.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(198)))), ((int)(((byte)(91)))));
            this.btnguardarcambios.FlatAppearance.BorderSize = 0;
            this.btnguardarcambios.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnguardarcambios.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold);
            this.btnguardarcambios.ForeColor = System.Drawing.Color.White;
            this.btnguardarcambios.Location = new System.Drawing.Point(148, 3);
            this.btnguardarcambios.Name = "btnguardarcambios";
            this.btnguardarcambios.Size = new System.Drawing.Size(139, 49);
            this.btnguardarcambios.TabIndex = 640;
            this.btnguardarcambios.Text = "Guardar*";
            this.btnguardarcambios.UseVisualStyleBackColor = false;
            this.btnguardarcambios.Click += new System.EventHandler(this.btnguardarcambios_Click);
            // 
            // txtum
            // 
            this.txtum.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtum.FormattingEnabled = true;
            this.txtum.Location = new System.Drawing.Point(223, 227);
            this.txtum.Name = "txtum";
            this.txtum.Size = new System.Drawing.Size(212, 28);
            this.txtum.TabIndex = 650;
            // 
            // Label49
            // 
            this.Label49.AutoSize = true;
            this.Label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label49.ForeColor = System.Drawing.Color.White;
            this.Label49.Location = new System.Drawing.Point(83, 228);
            this.Label49.Name = "Label49";
            this.Label49.Size = new System.Drawing.Size(134, 20);
            this.Label49.TabIndex = 649;
            this.Label49.Text = "Unidad medida:";
            // 
            // PictureBox3
            // 
            this.PictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox3.Image")));
            this.PictureBox3.Location = new System.Drawing.Point(193, 271);
            this.PictureBox3.Name = "PictureBox3";
            this.PictureBox3.Size = new System.Drawing.Size(29, 26);
            this.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PictureBox3.TabIndex = 654;
            this.PictureBox3.TabStop = false;
            // 
            // Label27
            // 
            this.Label27.AutoSize = true;
            this.Label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.Label27.ForeColor = System.Drawing.Color.LightGray;
            this.Label27.Location = new System.Drawing.Point(34, 273);
            this.Label27.Name = "Label27";
            this.Label27.Size = new System.Drawing.Size(151, 20);
            this.Label27.TabIndex = 652;
            this.Label27.Text = "Codigo de barras:";
            // 
            // txtcodigodebarras
            // 
            this.txtcodigodebarras.BackColor = System.Drawing.Color.White;
            this.txtcodigodebarras.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtcodigodebarras.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtcodigodebarras.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcodigodebarras.ForeColor = System.Drawing.Color.Black;
            this.txtcodigodebarras.Location = new System.Drawing.Point(223, 271);
            this.txtcodigodebarras.Name = "txtcodigodebarras";
            this.txtcodigodebarras.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtcodigodebarras.Size = new System.Drawing.Size(218, 26);
            this.txtcodigodebarras.TabIndex = 651;
            this.txtcodigodebarras.Text = "0";
            // 
            // btnGenerarCodigo
            // 
            this.btnGenerarCodigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenerarCodigo.Location = new System.Drawing.Point(447, 264);
            this.btnGenerarCodigo.Name = "btnGenerarCodigo";
            this.btnGenerarCodigo.Size = new System.Drawing.Size(157, 41);
            this.btnGenerarCodigo.TabIndex = 655;
            this.btnGenerarCodigo.Text = "Generar codigo";
            this.btnGenerarCodigo.UseVisualStyleBackColor = true;
            this.btnGenerarCodigo.Click += new System.EventHandler(this.btnGenerarCodigo_Click);
            // 
            // dgcodigossunat
            // 
            this.dgcodigossunat.AllowUserToAddRows = false;
            this.dgcodigossunat.AllowUserToDeleteRows = false;
            this.dgcodigossunat.AllowUserToResizeRows = false;
            this.dgcodigossunat.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgcodigossunat.BackgroundColor = System.Drawing.Color.White;
            this.dgcodigossunat.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgcodigossunat.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgcodigossunat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgcodigossunat.ColumnHeadersVisible = false;
            this.dgcodigossunat.EnableHeadersVisualStyles = false;
            this.dgcodigossunat.Location = new System.Drawing.Point(131, 58);
            this.dgcodigossunat.Name = "dgcodigossunat";
            this.dgcodigossunat.ReadOnly = true;
            this.dgcodigossunat.RowHeadersVisible = false;
            this.dgcodigossunat.RowHeadersWidth = 9;
            this.dgcodigossunat.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgcodigossunat.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dgcodigossunat.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgcodigossunat.RowTemplate.Height = 40;
            this.dgcodigossunat.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgcodigossunat.Size = new System.Drawing.Size(371, 121);
            this.dgcodigossunat.TabIndex = 658;
            this.dgcodigossunat.Visible = false;
            this.dgcodigossunat.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgcodigossunat_CellClick);
            // 
            // txtcodigoSunat
            // 
            this.txtcodigoSunat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcodigoSunat.Location = new System.Drawing.Point(131, 27);
            this.txtcodigoSunat.Name = "txtcodigoSunat";
            this.txtcodigoSunat.Size = new System.Drawing.Size(371, 26);
            this.txtcodigoSunat.TabIndex = 657;
            this.txtcodigoSunat.TextChanged += new System.EventHandler(this.txtcodigoSunat_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(7, 30);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(120, 20);
            this.label7.TabIndex = 656;
            this.label7.Text = "Codigo sunat:";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel2.Location = new System.Drawing.Point(614, 82);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(2, 380);
            this.panel2.TabIndex = 659;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.groupBox1.Controls.Add(this.dgcodigossunat);
            this.groupBox1.Controls.Add(this.txtcodigoSunat);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(630, 90);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(518, 202);
            this.groupBox1.TabIndex = 660;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Datos SUNAT";
            // 
            // Registro_de_productos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.ClientSize = new System.Drawing.Size(1162, 652);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btnGenerarCodigo);
            this.Controls.Add(this.PictureBox3);
            this.Controls.Add(this.Label27);
            this.Controls.Add(this.txtcodigodebarras);
            this.Controls.Add(this.txtum);
            this.Controls.Add(this.Label49);
            this.Controls.Add(this.flowLayoutPanel2);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.btncolor);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.txtpreciocompra);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.PanelIcono);
            this.Controls.Add(this.ImagenProducto);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Panel3);
            this.Controls.Add(this.txtprecioventa);
            this.Controls.Add(this.txtdescripcion);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.btncerrrar);
            this.Name = "Registro_de_productos";
            this.Text = "Registro de productos";
            this.Load += new System.EventHandler(this.Registro_de_productos_Load);
            this.PanelIcono.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImagenProducto)).EndInit();
            this.flowLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgcodigossunat)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Button btncerrrar;
        internal System.Windows.Forms.Panel Panel3;
        internal System.Windows.Forms.TextBox txtdescripcion;
        internal System.Windows.Forms.Label label2;
        internal System.Windows.Forms.Label label3;
        internal System.Windows.Forms.TextBox txtprecioventa;
        internal System.Windows.Forms.Panel panel1;
        internal System.Windows.Forms.Button btnvolver;
        internal System.Windows.Forms.Button btnguardar;
        internal System.Windows.Forms.Panel PanelIcono;
        internal System.Windows.Forms.PictureBox PictureBox2;
        internal System.Windows.Forms.Label label4;
        internal System.Windows.Forms.PictureBox ImagenProducto;
        private System.Windows.Forms.OpenFileDialog dlg;
        internal System.Windows.Forms.Panel panel4;
        internal System.Windows.Forms.TextBox txtpreciocompra;
        internal System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btncolor;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.Button btnguardarcambios;
        private System.Windows.Forms.ComboBox txtum;
        internal System.Windows.Forms.Label Label49;
        internal System.Windows.Forms.PictureBox PictureBox3;
        internal System.Windows.Forms.Label Label27;
        internal System.Windows.Forms.TextBox txtcodigodebarras;
        private System.Windows.Forms.Button btnGenerarCodigo;
        internal System.Windows.Forms.DataGridView dgcodigossunat;
        private System.Windows.Forms.TextBox txtcodigoSunat;
        internal System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}