﻿namespace RestCsharp.Presentacion.PRODUCTOS
{
    partial class Grupos_De_productos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Grupos_De_productos));
            this.PanelEDICION = new System.Windows.Forms.Panel();
            this.btncolor = new System.Windows.Forms.Button();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btnguardar = new System.Windows.Forms.Button();
            this.btnguardarcambios = new System.Windows.Forms.Button();
            this.btnvolver = new System.Windows.Forms.Button();
            this.PanelIcono = new System.Windows.Forms.Panel();
            this.PictureBox2 = new System.Windows.Forms.PictureBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.Panel3 = new System.Windows.Forms.Panel();
            this.txtgrupo = new System.Windows.Forms.TextBox();
            this.ImagenGrupo = new System.Windows.Forms.PictureBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.btncerrar = new System.Windows.Forms.Button();
            this.dlg = new System.Windows.Forms.OpenFileDialog();
            this.PanelEDICION.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.PanelIcono.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImagenGrupo)).BeginInit();
            this.SuspendLayout();
            // 
            // PanelEDICION
            // 
            this.PanelEDICION.Controls.Add(this.btncolor);
            this.PanelEDICION.Controls.Add(this.flowLayoutPanel2);
            this.PanelEDICION.Controls.Add(this.label3);
            this.PanelEDICION.Controls.Add(this.flowLayoutPanel1);
            this.PanelEDICION.Controls.Add(this.PanelIcono);
            this.PanelEDICION.Controls.Add(this.Panel3);
            this.PanelEDICION.Controls.Add(this.txtgrupo);
            this.PanelEDICION.Controls.Add(this.ImagenGrupo);
            this.PanelEDICION.Location = new System.Drawing.Point(3, 60);
            this.PanelEDICION.Name = "PanelEDICION";
            this.PanelEDICION.Size = new System.Drawing.Size(328, 574);
            this.PanelEDICION.TabIndex = 633;
            this.PanelEDICION.Paint += new System.Windows.Forms.PaintEventHandler(this.PanelEDICION_Paint);
            // 
            // btncolor
            // 
            this.btncolor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncolor.Location = new System.Drawing.Point(86, 88);
            this.btncolor.Name = "btncolor";
            this.btncolor.Size = new System.Drawing.Size(25, 24);
            this.btncolor.TabIndex = 636;
            this.btncolor.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Location = new System.Drawing.Point(20, 116);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(295, 71);
            this.flowLayoutPanel2.TabIndex = 635;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(16, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 20);
            this.label3.TabIndex = 634;
            this.label3.Text = "Color>>";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.btnguardar);
            this.flowLayoutPanel1.Controls.Add(this.btnguardarcambios);
            this.flowLayoutPanel1.Controls.Add(this.btnvolver);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(33, 346);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(255, 179);
            this.flowLayoutPanel1.TabIndex = 632;
            // 
            // btnguardar
            // 
            this.btnguardar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(198)))), ((int)(((byte)(91)))));
            this.btnguardar.FlatAppearance.BorderSize = 0;
            this.btnguardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnguardar.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold);
            this.btnguardar.ForeColor = System.Drawing.Color.White;
            this.btnguardar.Location = new System.Drawing.Point(3, 3);
            this.btnguardar.Name = "btnguardar";
            this.btnguardar.Size = new System.Drawing.Size(244, 54);
            this.btnguardar.TabIndex = 619;
            this.btnguardar.Text = "Guardar";
            this.btnguardar.UseVisualStyleBackColor = false;
            this.btnguardar.Click += new System.EventHandler(this.Button1_Click);
            // 
            // btnguardarcambios
            // 
            this.btnguardarcambios.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(198)))), ((int)(((byte)(91)))));
            this.btnguardarcambios.FlatAppearance.BorderSize = 0;
            this.btnguardarcambios.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnguardarcambios.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold);
            this.btnguardarcambios.ForeColor = System.Drawing.Color.White;
            this.btnguardarcambios.Location = new System.Drawing.Point(3, 63);
            this.btnguardarcambios.Name = "btnguardarcambios";
            this.btnguardarcambios.Size = new System.Drawing.Size(244, 54);
            this.btnguardarcambios.TabIndex = 620;
            this.btnguardarcambios.Text = "Guardar*";
            this.btnguardarcambios.UseVisualStyleBackColor = false;
            this.btnguardarcambios.Click += new System.EventHandler(this.btnguardarcambios_Click);
            // 
            // btnvolver
            // 
            this.btnvolver.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnvolver.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnvolver.ForeColor = System.Drawing.Color.Gray;
            this.btnvolver.Location = new System.Drawing.Point(3, 123);
            this.btnvolver.Name = "btnvolver";
            this.btnvolver.Size = new System.Drawing.Size(244, 52);
            this.btnvolver.TabIndex = 619;
            this.btnvolver.Text = "Volver";
            this.btnvolver.UseVisualStyleBackColor = true;
            this.btnvolver.Click += new System.EventHandler(this.btnvolver_Click);
            // 
            // PanelIcono
            // 
            this.PanelIcono.Controls.Add(this.PictureBox2);
            this.PanelIcono.Controls.Add(this.Label2);
            this.PanelIcono.Location = new System.Drawing.Point(20, 196);
            this.PanelIcono.Name = "PanelIcono";
            this.PanelIcono.Size = new System.Drawing.Size(104, 144);
            this.PanelIcono.TabIndex = 631;
            // 
            // PictureBox2
            // 
            this.PictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.PictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PictureBox2.BackgroundImage")));
            this.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PictureBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.PictureBox2.Location = new System.Drawing.Point(0, 91);
            this.PictureBox2.Name = "PictureBox2";
            this.PictureBox2.Size = new System.Drawing.Size(104, 25);
            this.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PictureBox2.TabIndex = 630;
            this.PictureBox2.TabStop = false;
            this.PictureBox2.Click += new System.EventHandler(this.PictureBox2_Click);
            // 
            // Label2
            // 
            this.Label2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.Label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.ForeColor = System.Drawing.Color.White;
            this.Label2.Location = new System.Drawing.Point(0, 0);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(104, 91);
            this.Label2.TabIndex = 629;
            this.Label2.Text = "Agregar Icono\r\n(Opcional)";
            this.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Label2.Click += new System.EventHandler(this.Label2_Click);
            // 
            // Panel3
            // 
            this.Panel3.BackColor = System.Drawing.Color.White;
            this.Panel3.Location = new System.Drawing.Point(19, 79);
            this.Panel3.Name = "Panel3";
            this.Panel3.Size = new System.Drawing.Size(284, 1);
            this.Panel3.TabIndex = 1;
            // 
            // txtgrupo
            // 
            this.txtgrupo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.txtgrupo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtgrupo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtgrupo.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtgrupo.ForeColor = System.Drawing.Color.White;
            this.txtgrupo.Location = new System.Drawing.Point(20, 42);
            this.txtgrupo.Name = "txtgrupo";
            this.txtgrupo.Size = new System.Drawing.Size(283, 31);
            this.txtgrupo.TabIndex = 1;
            this.txtgrupo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ImagenGrupo
            // 
            this.ImagenGrupo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ImagenGrupo.Image = global::RestCsharp.Properties.Resources.advertencia;
            this.ImagenGrupo.Location = new System.Drawing.Point(19, 196);
            this.ImagenGrupo.Name = "ImagenGrupo";
            this.ImagenGrupo.Size = new System.Drawing.Size(296, 144);
            this.ImagenGrupo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ImagenGrupo.TabIndex = 628;
            this.ImagenGrupo.TabStop = false;
            this.ImagenGrupo.Click += new System.EventHandler(this.ImagenGrupo_Click);
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.Label1.ForeColor = System.Drawing.Color.White;
            this.Label1.Location = new System.Drawing.Point(125, 20);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(97, 37);
            this.Label1.TabIndex = 632;
            this.Label1.Text = "Grupo";
            this.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btncerrar
            // 
            this.btncerrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.btncerrar.FlatAppearance.BorderSize = 0;
            this.btncerrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncerrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.btncerrar.ForeColor = System.Drawing.Color.White;
            this.btncerrar.Location = new System.Drawing.Point(289, 4);
            this.btncerrar.Name = "btncerrar";
            this.btncerrar.Size = new System.Drawing.Size(42, 40);
            this.btncerrar.TabIndex = 631;
            this.btncerrar.Text = "X";
            this.btncerrar.UseVisualStyleBackColor = false;
            this.btncerrar.Click += new System.EventHandler(this.Button7_Click);
            // 
            // dlg
            // 
            this.dlg.FileName = "openFileDialog1";
            // 
            // Grupos_De_productos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.ClientSize = new System.Drawing.Size(387, 646);
            this.Controls.Add(this.PanelEDICION);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.btncerrar);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Grupos_De_productos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Grupo de productos";
            this.Load += new System.EventHandler(this.Grupos_De_productos_Load);
            this.PanelEDICION.ResumeLayout(false);
            this.PanelEDICION.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.PanelIcono.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImagenGrupo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Panel PanelEDICION;
        internal System.Windows.Forms.Panel PanelIcono;
        internal System.Windows.Forms.PictureBox PictureBox2;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.PictureBox ImagenGrupo;
        internal System.Windows.Forms.Panel Panel3;
        internal System.Windows.Forms.TextBox txtgrupo;
        internal System.Windows.Forms.Button btnvolver;
        internal System.Windows.Forms.Button btnguardar;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Button btncerrar;
        private System.Windows.Forms.OpenFileDialog dlg;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label label3;
        internal System.Windows.Forms.Button btnguardarcambios;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.Button btncolor;
    }
}