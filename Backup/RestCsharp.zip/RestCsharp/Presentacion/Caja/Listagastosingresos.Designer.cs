﻿
namespace RestCsharp.Presentacion.Caja
{
    partial class Listagastosingresos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Listagastosingresos));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.btnTecladoNumer = new UIDC.UI_TecladoNumerico();
            this.btnTecladoStandar = new UIDC.UI_TecladoBasico();
            this.panelSalida = new System.Windows.Forms.Panel();
            this.panelConceptos = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btnguardarConceptos = new System.Windows.Forms.Button();
            this.btnguardarcambiosConceptos = new System.Windows.Forms.Button();
            this.btnvolver = new System.Windows.Forms.Button();
            this.panel11 = new System.Windows.Forms.Panel();
            this.txtdescripcionConcepto = new System.Windows.Forms.TextBox();
            this.txtbancoseleccionado = new System.Windows.Forms.Label();
            this.datalistadoConceptos = new System.Windows.Forms.DataGridView();
            this.Editar = new System.Windows.Forms.DataGridViewImageColumn();
            this.btnvolverGastos = new System.Windows.Forms.Button();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.lbltipo = new System.Windows.Forms.Label();
            this.PanelDetalle = new System.Windows.Forms.Panel();
            this.txtfecha = new System.Windows.Forms.DateTimePicker();
            this.txtdetalle = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Label8 = new System.Windows.Forms.Label();
            this.txtimporte = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.TXTACCION = new System.Windows.Forms.Label();
            this.PanelbuscadorConceptos = new System.Windows.Forms.Panel();
            this.btnagregar = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.CONTADO = new System.Windows.Forms.RadioButton();
            this.Label11 = new System.Windows.Forms.Label();
            this.TXTIDCONCEPTO = new System.Windows.Forms.TextBox();
            this.Id_usuario = new System.Windows.Forms.Label();
            this.Label9 = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.txtBuscarconcepto = new System.Windows.Forms.TextBox();
            this.panelIngreso = new System.Windows.Forms.Panel();
            this.btnvolverIngreso = new System.Windows.Forms.Button();
            this.btnGuardarIngreso = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.dtpFechaingreso = new System.Windows.Forms.DateTimePicker();
            this.txtdescripcionIngreso = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtmontoIngreso = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.panelPrincipal = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.datalistadoIngresos = new System.Windows.Forms.DataGridView();
            this.EliminarI = new System.Windows.Forms.DataGridViewImageColumn();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lbltotalIngresos = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.datalistadoGastos = new System.Windows.Forms.DataGridView();
            this.EliminarG = new System.Windows.Forms.DataGridViewImageColumn();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lbltotalGastos = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btngasto = new System.Windows.Forms.Button();
            this.btnIngreso = new System.Windows.Forms.Button();
            this.flowLayoutPanel3.SuspendLayout();
            this.panelSalida.SuspendLayout();
            this.panelConceptos.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datalistadoConceptos)).BeginInit();
            this.PanelDetalle.SuspendLayout();
            this.PanelbuscadorConceptos.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panelIngreso.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panelPrincipal.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datalistadoIngresos)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datalistadoGastos)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.Controls.Add(this.btnTecladoNumer);
            this.flowLayoutPanel3.Controls.Add(this.btnTecladoStandar);
            this.flowLayoutPanel3.Location = new System.Drawing.Point(12, 12);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(271, 61);
            this.flowLayoutPanel3.TabIndex = 640;
            // 
            // btnTecladoNumer
            // 
            this.btnTecladoNumer.AddControl = null;
            this.btnTecladoNumer.BackColor = System.Drawing.Color.Transparent;
            this.btnTecladoNumer.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.btnTecladoNumer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTecladoNumer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTecladoNumer.FlatAppearance.BorderSize = 0;
            this.btnTecladoNumer.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnTecladoNumer.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnTecladoNumer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTecladoNumer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTecladoNumer.ForeColor = System.Drawing.Color.White;
            this.btnTecladoNumer.IconKeyBoardColor = System.Drawing.SystemColors.ControlText;
            this.btnTecladoNumer.IconKeyBoardSize = 20;
            this.btnTecladoNumer.Location = new System.Drawing.Point(3, 3);
            this.btnTecladoNumer.Mode = UIDC.UI_TecladoNumerico.SEE.Claro;
            this.btnTecladoNumer.Name = "btnTecladoNumer";
            this.btnTecladoNumer.Size = new System.Drawing.Size(124, 57);
            this.btnTecladoNumer.TabIndex = 635;
            this.btnTecladoNumer.Text = "Teclado \r\nVirtual*";
            this.btnTecladoNumer.UseVisualStyleBackColor = false;
            this.btnTecladoNumer.Visible = false;
            // 
            // btnTecladoStandar
            // 
            this.btnTecladoStandar.AddControl = null;
            this.btnTecladoStandar.BackColor = System.Drawing.Color.Transparent;
            this.btnTecladoStandar.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.btnTecladoStandar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTecladoStandar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTecladoStandar.FlatAppearance.BorderSize = 0;
            this.btnTecladoStandar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnTecladoStandar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnTecladoStandar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTecladoStandar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTecladoStandar.ForeColor = System.Drawing.Color.White;
            this.btnTecladoStandar.IconKeyBoardColor = System.Drawing.SystemColors.ControlText;
            this.btnTecladoStandar.IconKeyBoardSize = 20;
            this.btnTecladoStandar.Location = new System.Drawing.Point(133, 3);
            this.btnTecladoStandar.Mode = UIDC.UI_TecladoBasico.SEE.Claro;
            this.btnTecladoStandar.Name = "btnTecladoStandar";
            this.btnTecladoStandar.Size = new System.Drawing.Size(118, 55);
            this.btnTecladoStandar.TabIndex = 634;
            this.btnTecladoStandar.Text = "Teclado \r\nvirtual";
            this.btnTecladoStandar.TypeKeyBoard = UIDC.UI_TecladoBasico.Tec.KeyBoard;
            this.btnTecladoStandar.UseVisualStyleBackColor = false;
            this.btnTecladoStandar.Visible = false;
            // 
            // panelSalida
            // 
            this.panelSalida.BackColor = System.Drawing.Color.White;
            this.panelSalida.Controls.Add(this.panelConceptos);
            this.panelSalida.Controls.Add(this.datalistadoConceptos);
            this.panelSalida.Controls.Add(this.btnvolverGastos);
            this.panelSalida.Controls.Add(this.btnGuardar);
            this.panelSalida.Controls.Add(this.lbltipo);
            this.panelSalida.Controls.Add(this.PanelDetalle);
            this.panelSalida.Controls.Add(this.PanelbuscadorConceptos);
            this.panelSalida.Location = new System.Drawing.Point(220, 93);
            this.panelSalida.Name = "panelSalida";
            this.panelSalida.Size = new System.Drawing.Size(509, 506);
            this.panelSalida.TabIndex = 642;
            this.panelSalida.Visible = false;
            // 
            // panelConceptos
            // 
            this.panelConceptos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelConceptos.Controls.Add(this.flowLayoutPanel1);
            this.panelConceptos.Controls.Add(this.panel11);
            this.panelConceptos.Controls.Add(this.txtdescripcionConcepto);
            this.panelConceptos.Controls.Add(this.txtbancoseleccionado);
            this.panelConceptos.Location = new System.Drawing.Point(302, 308);
            this.panelConceptos.Name = "panelConceptos";
            this.panelConceptos.Size = new System.Drawing.Size(334, 159);
            this.panelConceptos.TabIndex = 537;
            this.panelConceptos.Visible = false;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.btnguardarConceptos);
            this.flowLayoutPanel1.Controls.Add(this.btnguardarcambiosConceptos);
            this.flowLayoutPanel1.Controls.Add(this.btnvolver);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(11, 60);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(301, 89);
            this.flowLayoutPanel1.TabIndex = 535;
            // 
            // btnguardarConceptos
            // 
            this.btnguardarConceptos.BackColor = System.Drawing.Color.Transparent;
            this.btnguardarConceptos.BackgroundImage = global::RestCsharp.Properties.Resources.naranja;
            this.btnguardarConceptos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnguardarConceptos.FlatAppearance.BorderSize = 0;
            this.btnguardarConceptos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnguardarConceptos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnguardarConceptos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnguardarConceptos.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnguardarConceptos.ForeColor = System.Drawing.Color.White;
            this.btnguardarConceptos.Location = new System.Drawing.Point(3, 3);
            this.btnguardarConceptos.Name = "btnguardarConceptos";
            this.btnguardarConceptos.Size = new System.Drawing.Size(117, 63);
            this.btnguardarConceptos.TabIndex = 513;
            this.btnguardarConceptos.Text = "GUARDAR";
            this.btnguardarConceptos.UseVisualStyleBackColor = false;
            this.btnguardarConceptos.Click += new System.EventHandler(this.btnguardarConceptos_Click);
            // 
            // btnguardarcambiosConceptos
            // 
            this.btnguardarcambiosConceptos.BackColor = System.Drawing.Color.Transparent;
            this.btnguardarcambiosConceptos.BackgroundImage = global::RestCsharp.Properties.Resources.naranja;
            this.btnguardarcambiosConceptos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnguardarcambiosConceptos.FlatAppearance.BorderSize = 0;
            this.btnguardarcambiosConceptos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnguardarcambiosConceptos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnguardarcambiosConceptos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnguardarcambiosConceptos.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnguardarcambiosConceptos.ForeColor = System.Drawing.Color.White;
            this.btnguardarcambiosConceptos.Location = new System.Drawing.Point(126, 3);
            this.btnguardarcambiosConceptos.Name = "btnguardarcambiosConceptos";
            this.btnguardarcambiosConceptos.Size = new System.Drawing.Size(117, 63);
            this.btnguardarcambiosConceptos.TabIndex = 514;
            this.btnguardarcambiosConceptos.Text = "GUARDAR*";
            this.btnguardarcambiosConceptos.UseVisualStyleBackColor = false;
            this.btnguardarcambiosConceptos.Click += new System.EventHandler(this.btnguardarcambiosConceptos_Click);
            // 
            // btnvolver
            // 
            this.btnvolver.BackColor = System.Drawing.Color.Transparent;
            this.btnvolver.BackgroundImage = global::RestCsharp.Properties.Resources.negro;
            this.btnvolver.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnvolver.FlatAppearance.BorderSize = 0;
            this.btnvolver.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnvolver.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnvolver.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnvolver.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnvolver.ForeColor = System.Drawing.Color.White;
            this.btnvolver.Location = new System.Drawing.Point(3, 72);
            this.btnvolver.Name = "btnvolver";
            this.btnvolver.Size = new System.Drawing.Size(117, 63);
            this.btnvolver.TabIndex = 515;
            this.btnvolver.Text = "Volver";
            this.btnvolver.UseVisualStyleBackColor = false;
            this.btnvolver.Click += new System.EventHandler(this.btnvolver_Click);
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.LightGray;
            this.panel11.Location = new System.Drawing.Point(15, 52);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(376, 2);
            this.panel11.TabIndex = 534;
            // 
            // txtdescripcionConcepto
            // 
            this.txtdescripcionConcepto.BackColor = System.Drawing.Color.White;
            this.txtdescripcionConcepto.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtdescripcionConcepto.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtdescripcionConcepto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtdescripcionConcepto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.txtdescripcionConcepto.ForeColor = System.Drawing.Color.Black;
            this.txtdescripcionConcepto.Location = new System.Drawing.Point(14, 32);
            this.txtdescripcionConcepto.Name = "txtdescripcionConcepto";
            this.txtdescripcionConcepto.Size = new System.Drawing.Size(376, 19);
            this.txtdescripcionConcepto.TabIndex = 2;
            // 
            // txtbancoseleccionado
            // 
            this.txtbancoseleccionado.AutoSize = true;
            this.txtbancoseleccionado.BackColor = System.Drawing.Color.Transparent;
            this.txtbancoseleccionado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtbancoseleccionado.ForeColor = System.Drawing.Color.Black;
            this.txtbancoseleccionado.Location = new System.Drawing.Point(10, 9);
            this.txtbancoseleccionado.Name = "txtbancoseleccionado";
            this.txtbancoseleccionado.Size = new System.Drawing.Size(82, 20);
            this.txtbancoseleccionado.TabIndex = 342;
            this.txtbancoseleccionado.Text = "Concepto:";
            // 
            // datalistadoConceptos
            // 
            this.datalistadoConceptos.AllowUserToAddRows = false;
            this.datalistadoConceptos.AllowUserToDeleteRows = false;
            this.datalistadoConceptos.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.PaleTurquoise;
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.DeepSkyBlue;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White;
            this.datalistadoConceptos.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.datalistadoConceptos.BackgroundColor = System.Drawing.Color.White;
            this.datalistadoConceptos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.datalistadoConceptos.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.datalistadoConceptos.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datalistadoConceptos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.datalistadoConceptos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datalistadoConceptos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Editar});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.datalistadoConceptos.DefaultCellStyle = dataGridViewCellStyle3;
            this.datalistadoConceptos.EnableHeadersVisualStyles = false;
            this.datalistadoConceptos.Location = new System.Drawing.Point(468, 53);
            this.datalistadoConceptos.Name = "datalistadoConceptos";
            this.datalistadoConceptos.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datalistadoConceptos.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.datalistadoConceptos.RowHeadersVisible = false;
            this.datalistadoConceptos.RowHeadersWidth = 9;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.Gainsboro;
            this.datalistadoConceptos.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.datalistadoConceptos.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.White;
            this.datalistadoConceptos.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.datalistadoConceptos.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.WhiteSmoke;
            this.datalistadoConceptos.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.datalistadoConceptos.RowTemplate.Height = 40;
            this.datalistadoConceptos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datalistadoConceptos.Size = new System.Drawing.Size(120, 53);
            this.datalistadoConceptos.TabIndex = 536;
            this.datalistadoConceptos.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datalistadoConceptos_CellClick);
            // 
            // Editar
            // 
            this.Editar.HeaderText = "";
            this.Editar.Image = global::RestCsharp.Properties.Resources.editar;
            this.Editar.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Zoom;
            this.Editar.Name = "Editar";
            this.Editar.ReadOnly = true;
            this.Editar.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // btnvolverGastos
            // 
            this.btnvolverGastos.BackColor = System.Drawing.Color.Transparent;
            this.btnvolverGastos.BackgroundImage = global::RestCsharp.Properties.Resources.negro;
            this.btnvolverGastos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnvolverGastos.FlatAppearance.BorderSize = 0;
            this.btnvolverGastos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnvolverGastos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnvolverGastos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnvolverGastos.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnvolverGastos.ForeColor = System.Drawing.Color.White;
            this.btnvolverGastos.Location = new System.Drawing.Point(158, 306);
            this.btnvolverGastos.Name = "btnvolverGastos";
            this.btnvolverGastos.Size = new System.Drawing.Size(117, 63);
            this.btnvolverGastos.TabIndex = 513;
            this.btnvolverGastos.Text = "Volver";
            this.btnvolverGastos.UseVisualStyleBackColor = false;
            this.btnvolverGastos.Click += new System.EventHandler(this.btnvolverGastos_Click);
            // 
            // btnGuardar
            // 
            this.btnGuardar.BackColor = System.Drawing.Color.Transparent;
            this.btnGuardar.BackgroundImage = global::RestCsharp.Properties.Resources.naranja;
            this.btnGuardar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnGuardar.FlatAppearance.BorderSize = 0;
            this.btnGuardar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnGuardar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnGuardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGuardar.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardar.ForeColor = System.Drawing.Color.White;
            this.btnGuardar.Location = new System.Drawing.Point(31, 306);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(117, 63);
            this.btnGuardar.TabIndex = 512;
            this.btnGuardar.Text = "GUARDAR";
            this.btnGuardar.UseVisualStyleBackColor = false;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // lbltipo
            // 
            this.lbltipo.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbltipo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.lbltipo.ForeColor = System.Drawing.Color.Black;
            this.lbltipo.Location = new System.Drawing.Point(0, 0);
            this.lbltipo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbltipo.Name = "lbltipo";
            this.lbltipo.Size = new System.Drawing.Size(509, 34);
            this.lbltipo.TabIndex = 474;
            this.lbltipo.Text = "GASTOS (-)";
            this.lbltipo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PanelDetalle
            // 
            this.PanelDetalle.BackColor = System.Drawing.Color.White;
            this.PanelDetalle.Controls.Add(this.txtfecha);
            this.PanelDetalle.Controls.Add(this.txtdetalle);
            this.PanelDetalle.Controls.Add(this.label3);
            this.PanelDetalle.Controls.Add(this.Label8);
            this.PanelDetalle.Controls.Add(this.txtimporte);
            this.PanelDetalle.Controls.Add(this.label6);
            this.PanelDetalle.Controls.Add(this.TXTACCION);
            this.PanelDetalle.Location = new System.Drawing.Point(5, 133);
            this.PanelDetalle.Name = "PanelDetalle";
            this.PanelDetalle.Size = new System.Drawing.Size(576, 167);
            this.PanelDetalle.TabIndex = 473;
            // 
            // txtfecha
            // 
            this.txtfecha.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtfecha.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtfecha.Location = new System.Drawing.Point(125, 45);
            this.txtfecha.Name = "txtfecha";
            this.txtfecha.Size = new System.Drawing.Size(169, 26);
            this.txtfecha.TabIndex = 464;
            // 
            // txtdetalle
            // 
            this.txtdetalle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtdetalle.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtdetalle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdetalle.Location = new System.Drawing.Point(125, 77);
            this.txtdetalle.Margin = new System.Windows.Forms.Padding(4);
            this.txtdetalle.Multiline = true;
            this.txtdetalle.Name = "txtdetalle";
            this.txtdetalle.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtdetalle.Size = new System.Drawing.Size(416, 78);
            this.txtdetalle.TabIndex = 217;
            this.txtdetalle.Click += new System.EventHandler(this.txtdetalle_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(54, 79);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 20);
            this.label3.TabIndex = 216;
            this.label3.Text = "Detalle:";
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.BackColor = System.Drawing.Color.Transparent;
            this.Label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label8.ForeColor = System.Drawing.Color.Black;
            this.Label8.Location = new System.Drawing.Point(60, 46);
            this.Label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(58, 20);
            this.Label8.TabIndex = 214;
            this.Label8.Text = "Fecha:";
            // 
            // txtimporte
            // 
            this.txtimporte.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtimporte.Font = new System.Drawing.Font("Arial", 12F);
            this.txtimporte.Location = new System.Drawing.Point(125, 8);
            this.txtimporte.Margin = new System.Windows.Forms.Padding(4);
            this.txtimporte.Name = "txtimporte";
            this.txtimporte.Size = new System.Drawing.Size(169, 26);
            this.txtimporte.TabIndex = 218;
            this.txtimporte.Click += new System.EventHandler(this.txtimporte_Click);
            this.txtimporte.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtimporte_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Arial", 12F);
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(67, 10);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 18);
            this.label6.TabIndex = 215;
            this.label6.Text = "Monto:";
            // 
            // TXTACCION
            // 
            this.TXTACCION.AutoSize = true;
            this.TXTACCION.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.TXTACCION.ForeColor = System.Drawing.Color.Black;
            this.TXTACCION.Location = new System.Drawing.Point(259, 91);
            this.TXTACCION.Name = "TXTACCION";
            this.TXTACCION.Size = new System.Drawing.Size(70, 20);
            this.TXTACCION.TabIndex = 528;
            this.TXTACCION.Text = "ACCION";
            // 
            // PanelbuscadorConceptos
            // 
            this.PanelbuscadorConceptos.BackColor = System.Drawing.Color.White;
            this.PanelbuscadorConceptos.Controls.Add(this.btnagregar);
            this.PanelbuscadorConceptos.Controls.Add(this.panel8);
            this.PanelbuscadorConceptos.Controls.Add(this.Label5);
            this.PanelbuscadorConceptos.Controls.Add(this.txtBuscarconcepto);
            this.PanelbuscadorConceptos.Location = new System.Drawing.Point(5, 53);
            this.PanelbuscadorConceptos.Name = "PanelbuscadorConceptos";
            this.PanelbuscadorConceptos.Size = new System.Drawing.Size(459, 74);
            this.PanelbuscadorConceptos.TabIndex = 472;
            // 
            // btnagregar
            // 
            this.btnagregar.BackColor = System.Drawing.Color.Transparent;
            this.btnagregar.BackgroundImage = global::RestCsharp.Properties.Resources.azul;
            this.btnagregar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnagregar.FlatAppearance.BorderSize = 0;
            this.btnagregar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnagregar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnagregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnagregar.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnagregar.ForeColor = System.Drawing.Color.White;
            this.btnagregar.Location = new System.Drawing.Point(355, 30);
            this.btnagregar.Name = "btnagregar";
            this.btnagregar.Size = new System.Drawing.Size(77, 38);
            this.btnagregar.TabIndex = 514;
            this.btnagregar.Text = "Agregar";
            this.btnagregar.UseVisualStyleBackColor = false;
            this.btnagregar.Click += new System.EventHandler(this.btnagregar_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.CONTADO);
            this.panel8.Controls.Add(this.Label11);
            this.panel8.Controls.Add(this.TXTIDCONCEPTO);
            this.panel8.Controls.Add(this.Id_usuario);
            this.panel8.Controls.Add(this.Label9);
            this.panel8.Location = new System.Drawing.Point(560, 141);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(11, 26);
            this.panel8.TabIndex = 465;
            // 
            // CONTADO
            // 
            this.CONTADO.AutoSize = true;
            this.CONTADO.Checked = true;
            this.CONTADO.Location = new System.Drawing.Point(103, 2);
            this.CONTADO.Margin = new System.Windows.Forms.Padding(4);
            this.CONTADO.Name = "CONTADO";
            this.CONTADO.Size = new System.Drawing.Size(70, 17);
            this.CONTADO.TabIndex = 231;
            this.CONTADO.TabStop = true;
            this.CONTADO.Text = "PAGADO";
            this.CONTADO.UseVisualStyleBackColor = true;
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.BackColor = System.Drawing.Color.Transparent;
            this.Label11.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label11.ForeColor = System.Drawing.Color.Black;
            this.Label11.Location = new System.Drawing.Point(17, 33);
            this.Label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(43, 14);
            this.Label11.TabIndex = 215;
            this.Label11.Text = "Estado:";
            // 
            // TXTIDCONCEPTO
            // 
            this.TXTIDCONCEPTO.Location = new System.Drawing.Point(24, 0);
            this.TXTIDCONCEPTO.Margin = new System.Windows.Forms.Padding(4);
            this.TXTIDCONCEPTO.Name = "TXTIDCONCEPTO";
            this.TXTIDCONCEPTO.Size = new System.Drawing.Size(47, 20);
            this.TXTIDCONCEPTO.TabIndex = 459;
            // 
            // Id_usuario
            // 
            this.Id_usuario.AutoSize = true;
            this.Id_usuario.BackColor = System.Drawing.Color.Transparent;
            this.Id_usuario.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Id_usuario.ForeColor = System.Drawing.Color.Black;
            this.Id_usuario.Location = new System.Drawing.Point(10, 11);
            this.Id_usuario.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Id_usuario.Name = "Id_usuario";
            this.Id_usuario.Size = new System.Drawing.Size(13, 14);
            this.Id_usuario.TabIndex = 216;
            this.Id_usuario.Text = "0";
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Location = new System.Drawing.Point(4, 46);
            this.Label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(111, 13);
            this.Label9.TabIndex = 222;
            this.Label9.Text = "Tipo de comprobante:";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label5.ForeColor = System.Drawing.Color.DarkGray;
            this.Label5.Location = new System.Drawing.Point(4, 9);
            this.Label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(114, 17);
            this.Label5.TabIndex = 457;
            this.Label5.Text = "Buscar concepto";
            // 
            // txtBuscarconcepto
            // 
            this.txtBuscarconcepto.BackColor = System.Drawing.Color.White;
            this.txtBuscarconcepto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBuscarconcepto.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtBuscarconcepto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtBuscarconcepto.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.txtBuscarconcepto.ForeColor = System.Drawing.Color.Black;
            this.txtBuscarconcepto.Location = new System.Drawing.Point(4, 30);
            this.txtBuscarconcepto.Margin = new System.Windows.Forms.Padding(4);
            this.txtBuscarconcepto.Name = "txtBuscarconcepto";
            this.txtBuscarconcepto.Size = new System.Drawing.Size(344, 38);
            this.txtBuscarconcepto.TabIndex = 456;
            this.txtBuscarconcepto.Click += new System.EventHandler(this.txtBuscarconcepto_Click);
            this.txtBuscarconcepto.TextChanged += new System.EventHandler(this.txtBuscarconcepto_TextChanged);
            // 
            // panelIngreso
            // 
            this.panelIngreso.BackColor = System.Drawing.Color.White;
            this.panelIngreso.Controls.Add(this.btnvolverIngreso);
            this.panelIngreso.Controls.Add(this.btnGuardarIngreso);
            this.panelIngreso.Controls.Add(this.label10);
            this.panelIngreso.Controls.Add(this.panel10);
            this.panelIngreso.Location = new System.Drawing.Point(642, 151);
            this.panelIngreso.Name = "panelIngreso";
            this.panelIngreso.Size = new System.Drawing.Size(609, 297);
            this.panelIngreso.TabIndex = 643;
            this.panelIngreso.Visible = false;
            // 
            // btnvolverIngreso
            // 
            this.btnvolverIngreso.BackColor = System.Drawing.Color.Transparent;
            this.btnvolverIngreso.BackgroundImage = global::RestCsharp.Properties.Resources.negro;
            this.btnvolverIngreso.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnvolverIngreso.FlatAppearance.BorderSize = 0;
            this.btnvolverIngreso.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnvolverIngreso.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnvolverIngreso.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnvolverIngreso.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnvolverIngreso.ForeColor = System.Drawing.Color.White;
            this.btnvolverIngreso.Location = new System.Drawing.Point(141, 210);
            this.btnvolverIngreso.Name = "btnvolverIngreso";
            this.btnvolverIngreso.Size = new System.Drawing.Size(112, 63);
            this.btnvolverIngreso.TabIndex = 513;
            this.btnvolverIngreso.Text = "Volver";
            this.btnvolverIngreso.UseVisualStyleBackColor = false;
            this.btnvolverIngreso.Click += new System.EventHandler(this.btnvolverIngreso_Click);
            // 
            // btnGuardarIngreso
            // 
            this.btnGuardarIngreso.BackColor = System.Drawing.Color.Transparent;
            this.btnGuardarIngreso.BackgroundImage = global::RestCsharp.Properties.Resources.naranja;
            this.btnGuardarIngreso.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnGuardarIngreso.FlatAppearance.BorderSize = 0;
            this.btnGuardarIngreso.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnGuardarIngreso.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnGuardarIngreso.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGuardarIngreso.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardarIngreso.ForeColor = System.Drawing.Color.White;
            this.btnGuardarIngreso.Location = new System.Drawing.Point(14, 210);
            this.btnGuardarIngreso.Name = "btnGuardarIngreso";
            this.btnGuardarIngreso.Size = new System.Drawing.Size(112, 63);
            this.btnGuardarIngreso.TabIndex = 512;
            this.btnGuardarIngreso.Text = "GUARDAR";
            this.btnGuardarIngreso.UseVisualStyleBackColor = false;
            this.btnGuardarIngreso.Click += new System.EventHandler(this.btnGuardarIngreso_Click);
            // 
            // label10
            // 
            this.label10.Dock = System.Windows.Forms.DockStyle.Top;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(0, 0);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(609, 34);
            this.label10.TabIndex = 474;
            this.label10.Text = "INGRESO (+)";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.White;
            this.panel10.Controls.Add(this.dtpFechaingreso);
            this.panel10.Controls.Add(this.txtdescripcionIngreso);
            this.panel10.Controls.Add(this.label12);
            this.panel10.Controls.Add(this.label13);
            this.panel10.Controls.Add(this.txtmontoIngreso);
            this.panel10.Controls.Add(this.label14);
            this.panel10.Controls.Add(this.label15);
            this.panel10.Location = new System.Drawing.Point(14, 37);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(576, 167);
            this.panel10.TabIndex = 473;
            // 
            // dtpFechaingreso
            // 
            this.dtpFechaingreso.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.dtpFechaingreso.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFechaingreso.Location = new System.Drawing.Point(125, 45);
            this.dtpFechaingreso.Name = "dtpFechaingreso";
            this.dtpFechaingreso.Size = new System.Drawing.Size(167, 26);
            this.dtpFechaingreso.TabIndex = 464;
            // 
            // txtdescripcionIngreso
            // 
            this.txtdescripcionIngreso.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtdescripcionIngreso.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtdescripcionIngreso.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdescripcionIngreso.Location = new System.Drawing.Point(125, 77);
            this.txtdescripcionIngreso.Margin = new System.Windows.Forms.Padding(4);
            this.txtdescripcionIngreso.Multiline = true;
            this.txtdescripcionIngreso.Name = "txtdescripcionIngreso";
            this.txtdescripcionIngreso.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtdescripcionIngreso.Size = new System.Drawing.Size(416, 78);
            this.txtdescripcionIngreso.TabIndex = 217;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(54, 79);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(63, 20);
            this.label12.TabIndex = 216;
            this.label12.Text = "Detalle:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(60, 46);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(58, 20);
            this.label13.TabIndex = 214;
            this.label13.Text = "Fecha:";
            // 
            // txtmontoIngreso
            // 
            this.txtmontoIngreso.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtmontoIngreso.Font = new System.Drawing.Font("Arial", 12F);
            this.txtmontoIngreso.Location = new System.Drawing.Point(125, 8);
            this.txtmontoIngreso.Margin = new System.Windows.Forms.Padding(4);
            this.txtmontoIngreso.Name = "txtmontoIngreso";
            this.txtmontoIngreso.Size = new System.Drawing.Size(167, 26);
            this.txtmontoIngreso.TabIndex = 218;
            this.txtmontoIngreso.Click += new System.EventHandler(this.txtmontoIngreso_Click);
            this.txtmontoIngreso.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtmontoIngreso_KeyPress);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Arial", 12F);
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(67, 10);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(55, 18);
            this.label14.TabIndex = 215;
            this.label14.Text = "Monto:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(259, 91);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(70, 20);
            this.label15.TabIndex = 528;
            this.label15.Text = "ACCION";
            // 
            // panelPrincipal
            // 
            this.panelPrincipal.Controls.Add(this.panel3);
            this.panelPrincipal.Controls.Add(this.panel2);
            this.panelPrincipal.Controls.Add(this.panel7);
            this.panelPrincipal.Location = new System.Drawing.Point(97, 131);
            this.panelPrincipal.Name = "panelPrincipal";
            this.panelPrincipal.Size = new System.Drawing.Size(978, 519);
            this.panelPrincipal.TabIndex = 641;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.datalistadoIngresos);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.Label2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(498, 63);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(480, 456);
            this.panel3.TabIndex = 1;
            // 
            // datalistadoIngresos
            // 
            this.datalistadoIngresos.AllowUserToAddRows = false;
            this.datalistadoIngresos.AllowUserToDeleteRows = false;
            this.datalistadoIngresos.AllowUserToResizeRows = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.PaleTurquoise;
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.DeepSkyBlue;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.White;
            this.datalistadoIngresos.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.datalistadoIngresos.BackgroundColor = System.Drawing.Color.White;
            this.datalistadoIngresos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.datalistadoIngresos.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.datalistadoIngresos.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datalistadoIngresos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.datalistadoIngresos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datalistadoIngresos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EliminarI});
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.datalistadoIngresos.DefaultCellStyle = dataGridViewCellStyle8;
            this.datalistadoIngresos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.datalistadoIngresos.EnableHeadersVisualStyles = false;
            this.datalistadoIngresos.Location = new System.Drawing.Point(0, 49);
            this.datalistadoIngresos.Name = "datalistadoIngresos";
            this.datalistadoIngresos.ReadOnly = true;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datalistadoIngresos.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.datalistadoIngresos.RowHeadersVisible = false;
            this.datalistadoIngresos.RowHeadersWidth = 9;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.Gainsboro;
            this.datalistadoIngresos.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.datalistadoIngresos.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.White;
            this.datalistadoIngresos.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.datalistadoIngresos.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.WhiteSmoke;
            this.datalistadoIngresos.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.datalistadoIngresos.RowTemplate.Height = 40;
            this.datalistadoIngresos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datalistadoIngresos.Size = new System.Drawing.Size(480, 346);
            this.datalistadoIngresos.TabIndex = 374;
            this.datalistadoIngresos.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datalistadoIngresos_CellClick);
            // 
            // EliminarI
            // 
            this.EliminarI.HeaderText = "";
            this.EliminarI.Image = ((System.Drawing.Image)(resources.GetObject("EliminarI.Image")));
            this.EliminarI.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Zoom;
            this.EliminarI.Name = "EliminarI";
            this.EliminarI.ReadOnly = true;
            this.EliminarI.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.lbltotalIngresos);
            this.panel5.Controls.Add(this.label4);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel5.Location = new System.Drawing.Point(0, 395);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(480, 61);
            this.panel5.TabIndex = 373;
            // 
            // lbltotalIngresos
            // 
            this.lbltotalIngresos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbltotalIngresos.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold);
            this.lbltotalIngresos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbltotalIngresos.Location = new System.Drawing.Point(78, 0);
            this.lbltotalIngresos.Name = "lbltotalIngresos";
            this.lbltotalIngresos.Size = new System.Drawing.Size(402, 61);
            this.lbltotalIngresos.TabIndex = 3;
            this.lbltotalIngresos.Text = "0.00";
            this.lbltotalIngresos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.Dock = System.Windows.Forms.DockStyle.Left;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label4.Location = new System.Drawing.Point(0, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 61);
            this.label4.TabIndex = 2;
            this.label4.Text = "Total:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label2
            // 
            this.Label2.BackColor = System.Drawing.Color.Honeydew;
            this.Label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.Label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.Location = new System.Drawing.Point(0, 0);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(480, 49);
            this.Label2.TabIndex = 371;
            this.Label2.Text = "Ingresos de caja";
            this.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.datalistadoGastos);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.Label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 63);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(498, 456);
            this.panel2.TabIndex = 0;
            // 
            // datalistadoGastos
            // 
            this.datalistadoGastos.AllowUserToAddRows = false;
            this.datalistadoGastos.AllowUserToDeleteRows = false;
            this.datalistadoGastos.AllowUserToResizeRows = false;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.PaleTurquoise;
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.DeepSkyBlue;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.White;
            this.datalistadoGastos.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle11;
            this.datalistadoGastos.BackgroundColor = System.Drawing.Color.White;
            this.datalistadoGastos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.datalistadoGastos.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.datalistadoGastos.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datalistadoGastos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.datalistadoGastos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datalistadoGastos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EliminarG});
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.datalistadoGastos.DefaultCellStyle = dataGridViewCellStyle13;
            this.datalistadoGastos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.datalistadoGastos.EnableHeadersVisualStyles = false;
            this.datalistadoGastos.Location = new System.Drawing.Point(0, 49);
            this.datalistadoGastos.Name = "datalistadoGastos";
            this.datalistadoGastos.ReadOnly = true;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datalistadoGastos.RowHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.datalistadoGastos.RowHeadersVisible = false;
            this.datalistadoGastos.RowHeadersWidth = 9;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.Gainsboro;
            this.datalistadoGastos.RowsDefaultCellStyle = dataGridViewCellStyle15;
            this.datalistadoGastos.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.White;
            this.datalistadoGastos.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.datalistadoGastos.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.WhiteSmoke;
            this.datalistadoGastos.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.datalistadoGastos.RowTemplate.Height = 40;
            this.datalistadoGastos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datalistadoGastos.Size = new System.Drawing.Size(498, 346);
            this.datalistadoGastos.TabIndex = 373;
            this.datalistadoGastos.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datalistadoGastos_CellClick);
            // 
            // EliminarG
            // 
            this.EliminarG.HeaderText = "";
            this.EliminarG.Image = ((System.Drawing.Image)(resources.GetObject("EliminarG.Image")));
            this.EliminarG.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Zoom;
            this.EliminarG.Name = "EliminarG";
            this.EliminarG.ReadOnly = true;
            this.EliminarG.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.lbltotalGastos);
            this.panel4.Controls.Add(this.Label7);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 395);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(498, 61);
            this.panel4.TabIndex = 372;
            // 
            // lbltotalGastos
            // 
            this.lbltotalGastos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbltotalGastos.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold);
            this.lbltotalGastos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbltotalGastos.Location = new System.Drawing.Point(78, 0);
            this.lbltotalGastos.Name = "lbltotalGastos";
            this.lbltotalGastos.Size = new System.Drawing.Size(420, 61);
            this.lbltotalGastos.TabIndex = 3;
            this.lbltotalGastos.Text = "0.00";
            this.lbltotalGastos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label7
            // 
            this.Label7.Dock = System.Windows.Forms.DockStyle.Left;
            this.Label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.Label7.Location = new System.Drawing.Point(0, 0);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(78, 61);
            this.Label7.TabIndex = 2;
            this.Label7.Text = "Total:";
            this.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Label1
            // 
            this.Label1.BackColor = System.Drawing.Color.LavenderBlush;
            this.Label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.Label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(0, 0);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(498, 49);
            this.Label1.TabIndex = 371;
            this.Label1.Text = "Gastos de caja";
            this.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.btngasto);
            this.panel7.Controls.Add(this.btnIngreso);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(978, 63);
            this.panel7.TabIndex = 4;
            // 
            // btngasto
            // 
            this.btngasto.BackColor = System.Drawing.Color.Transparent;
            this.btngasto.BackgroundImage = global::RestCsharp.Properties.Resources.naranja;
            this.btngasto.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btngasto.Dock = System.Windows.Forms.DockStyle.Left;
            this.btngasto.FlatAppearance.BorderSize = 0;
            this.btngasto.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btngasto.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btngasto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btngasto.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btngasto.ForeColor = System.Drawing.Color.White;
            this.btngasto.Location = new System.Drawing.Point(0, 0);
            this.btngasto.Name = "btngasto";
            this.btngasto.Size = new System.Drawing.Size(117, 63);
            this.btngasto.TabIndex = 512;
            this.btngasto.Text = "Salida de dinero";
            this.btngasto.UseVisualStyleBackColor = false;
            this.btngasto.Click += new System.EventHandler(this.btngasto_Click);
            // 
            // btnIngreso
            // 
            this.btnIngreso.BackColor = System.Drawing.Color.Transparent;
            this.btnIngreso.BackgroundImage = global::RestCsharp.Properties.Resources.verde;
            this.btnIngreso.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnIngreso.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnIngreso.FlatAppearance.BorderSize = 0;
            this.btnIngreso.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnIngreso.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnIngreso.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnIngreso.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIngreso.ForeColor = System.Drawing.Color.White;
            this.btnIngreso.Location = new System.Drawing.Point(861, 0);
            this.btnIngreso.Name = "btnIngreso";
            this.btnIngreso.Size = new System.Drawing.Size(117, 63);
            this.btnIngreso.TabIndex = 511;
            this.btnIngreso.Text = "Ingresar dinero";
            this.btnIngreso.UseVisualStyleBackColor = false;
            this.btnIngreso.Click += new System.EventHandler(this.btnIngreso_Click);
            // 
            // Listagastosingresos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1314, 722);
            this.Controls.Add(this.panelSalida);
            this.Controls.Add(this.panelIngreso);
            this.Controls.Add(this.panelPrincipal);
            this.Controls.Add(this.flowLayoutPanel3);
            this.Name = "Listagastosingresos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Listagastosingresos";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Listagastosingresos_Load);
            this.flowLayoutPanel3.ResumeLayout(false);
            this.panelSalida.ResumeLayout(false);
            this.panelConceptos.ResumeLayout(false);
            this.panelConceptos.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.datalistadoConceptos)).EndInit();
            this.PanelDetalle.ResumeLayout(false);
            this.PanelDetalle.PerformLayout();
            this.PanelbuscadorConceptos.ResumeLayout(false);
            this.PanelbuscadorConceptos.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panelIngreso.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panelPrincipal.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.datalistadoIngresos)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.datalistadoGastos)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private UIDC.UI_TecladoNumerico btnTecladoNumer;
        private UIDC.UI_TecladoBasico btnTecladoStandar;
        private System.Windows.Forms.Panel panelSalida;
        internal System.Windows.Forms.Panel panelConceptos;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button btnguardarConceptos;
        private System.Windows.Forms.Button btnguardarcambiosConceptos;
        private System.Windows.Forms.Button btnvolver;
        internal System.Windows.Forms.Panel panel11;
        internal System.Windows.Forms.TextBox txtdescripcionConcepto;
        internal System.Windows.Forms.Label txtbancoseleccionado;
        internal System.Windows.Forms.DataGridView datalistadoConceptos;
        private System.Windows.Forms.DataGridViewImageColumn Editar;
        private System.Windows.Forms.Button btnvolverGastos;
        private System.Windows.Forms.Button btnGuardar;
        internal System.Windows.Forms.Label lbltipo;
        internal System.Windows.Forms.Panel PanelDetalle;
        internal System.Windows.Forms.DateTimePicker txtfecha;
        internal System.Windows.Forms.TextBox txtdetalle;
        internal System.Windows.Forms.Label label3;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.TextBox txtimporte;
        internal System.Windows.Forms.Label label6;
        internal System.Windows.Forms.Label TXTACCION;
        internal System.Windows.Forms.Panel PanelbuscadorConceptos;
        private System.Windows.Forms.Button btnagregar;
        internal System.Windows.Forms.Panel panel8;
        internal System.Windows.Forms.RadioButton CONTADO;
        internal System.Windows.Forms.Label Label11;
        internal System.Windows.Forms.TextBox TXTIDCONCEPTO;
        internal System.Windows.Forms.Label Id_usuario;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.TextBox txtBuscarconcepto;
        private System.Windows.Forms.Panel panelIngreso;
        private System.Windows.Forms.Button btnvolverIngreso;
        private System.Windows.Forms.Button btnGuardarIngreso;
        internal System.Windows.Forms.Label label10;
        internal System.Windows.Forms.Panel panel10;
        internal System.Windows.Forms.DateTimePicker dtpFechaingreso;
        internal System.Windows.Forms.TextBox txtdescripcionIngreso;
        internal System.Windows.Forms.Label label12;
        internal System.Windows.Forms.Label label13;
        internal System.Windows.Forms.TextBox txtmontoIngreso;
        internal System.Windows.Forms.Label label14;
        internal System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panelPrincipal;
        private System.Windows.Forms.Panel panel3;
        internal System.Windows.Forms.DataGridView datalistadoIngresos;
        private System.Windows.Forms.DataGridViewImageColumn EliminarI;
        private System.Windows.Forms.Panel panel5;
        internal System.Windows.Forms.Label lbltotalIngresos;
        internal System.Windows.Forms.Label label4;
        internal System.Windows.Forms.Label Label2;
        private System.Windows.Forms.Panel panel2;
        internal System.Windows.Forms.DataGridView datalistadoGastos;
        private System.Windows.Forms.DataGridViewImageColumn EliminarG;
        private System.Windows.Forms.Panel panel4;
        internal System.Windows.Forms.Label lbltotalGastos;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Label Label1;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button btngasto;
        private System.Windows.Forms.Button btnIngreso;
    }
}