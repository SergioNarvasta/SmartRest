﻿
namespace RestCsharp.Presentacion.Licencia
{
    partial class Licencias
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnCerrar = new System.Windows.Forms.Button();
            this.btnActivacioManual = new System.Windows.Forms.Button();
            this.btncomprar = new System.Windows.Forms.Button();
            this.btnCopiar = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.Label4 = new System.Windows.Forms.Label();
            this.txtSerial = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.panel2.Controls.Add(this.btnCerrar);
            this.panel2.Controls.Add(this.btnActivacioManual);
            this.panel2.Controls.Add(this.btncomprar);
            this.panel2.Controls.Add(this.btnCopiar);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.Label4);
            this.panel2.Controls.Add(this.txtSerial);
            this.panel2.Controls.Add(this.Label2);
            this.panel2.Controls.Add(this.Label1);
            this.panel2.Location = new System.Drawing.Point(3, 18);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(800, 358);
            this.panel2.TabIndex = 2;
            // 
            // btnCerrar
            // 
            this.btnCerrar.BackColor = System.Drawing.Color.Transparent;
            this.btnCerrar.BackgroundImage = global::RestCsharp.Properties.Resources.Rojo;
            this.btnCerrar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCerrar.FlatAppearance.BorderSize = 0;
            this.btnCerrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnCerrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnCerrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCerrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCerrar.ForeColor = System.Drawing.Color.White;
            this.btnCerrar.Location = new System.Drawing.Point(746, 6);
            this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(51, 40);
            this.btnCerrar.TabIndex = 3;
            this.btnCerrar.Text = "X";
            this.btnCerrar.UseVisualStyleBackColor = false;
            this.btnCerrar.Visible = false;
            this.btnCerrar.Click += new System.EventHandler(this.btnCerrar_Click);
            // 
            // btnActivacioManual
            // 
            this.btnActivacioManual.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.btnActivacioManual.FlatAppearance.BorderSize = 0;
            this.btnActivacioManual.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnActivacioManual.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnActivacioManual.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnActivacioManual.Location = new System.Drawing.Point(163, 277);
            this.btnActivacioManual.Name = "btnActivacioManual";
            this.btnActivacioManual.Size = new System.Drawing.Size(281, 39);
            this.btnActivacioManual.TabIndex = 631;
            this.btnActivacioManual.Text = "Activar Licencia Manualmente";
            this.btnActivacioManual.UseVisualStyleBackColor = false;
            this.btnActivacioManual.Click += new System.EventHandler(this.btnActivacioManual_Click);
            // 
            // btncomprar
            // 
            this.btncomprar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(166)))), ((int)(((byte)(63)))));
            this.btncomprar.FlatAppearance.BorderSize = 0;
            this.btncomprar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncomprar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btncomprar.ForeColor = System.Drawing.Color.White;
            this.btncomprar.Location = new System.Drawing.Point(8, 277);
            this.btncomprar.Name = "btncomprar";
            this.btncomprar.Size = new System.Drawing.Size(149, 39);
            this.btncomprar.TabIndex = 629;
            this.btncomprar.Text = "Comprar ";
            this.btncomprar.UseVisualStyleBackColor = false;
            this.btncomprar.Click += new System.EventHandler(this.btncomprar_Click);
            // 
            // btnCopiar
            // 
            this.btnCopiar.Location = new System.Drawing.Point(487, 226);
            this.btnCopiar.Name = "btnCopiar";
            this.btnCopiar.Size = new System.Drawing.Size(90, 28);
            this.btnCopiar.TabIndex = 628;
            this.btnCopiar.Text = "Copiar";
            this.btnCopiar.UseVisualStyleBackColor = true;
            this.btnCopiar.Click += new System.EventHandler(this.btnCopiar_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(166)))), ((int)(((byte)(63)))));
            this.panel6.Location = new System.Drawing.Point(161, 254);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(310, 1);
            this.panel6.TabIndex = 622;
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.BackColor = System.Drawing.Color.Transparent;
            this.Label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label4.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.Label4.Location = new System.Drawing.Point(23, 232);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(134, 20);
            this.Label4.TabIndex = 620;
            this.Label4.Text = "Notas del pedido*";
            // 
            // txtSerial
            // 
            this.txtSerial.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.txtSerial.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSerial.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSerial.ForeColor = System.Drawing.Color.White;
            this.txtSerial.Location = new System.Drawing.Point(161, 229);
            this.txtSerial.Name = "txtSerial";
            this.txtSerial.Size = new System.Drawing.Size(310, 19);
            this.txtSerial.TabIndex = 618;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.BackColor = System.Drawing.Color.Transparent;
            this.Label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold);
            this.Label2.ForeColor = System.Drawing.Color.White;
            this.Label2.Location = new System.Drawing.Point(4, 189);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(668, 24);
            this.Label2.TabIndex = 612;
            this.Label2.Text = "Usa este dato cuando se te pida en tu Compra (es muy IMPORTANTE)";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.BackColor = System.Drawing.Color.Transparent;
            this.Label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.Label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.Label1.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.Label1.Location = new System.Drawing.Point(0, 0);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(288, 46);
            this.Label1.TabIndex = 6;
            this.Label1.Text = "Activar licencia";
            // 
            // Licencias
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.Controls.Add(this.panel2);
            this.Name = "Licencias";
            this.Size = new System.Drawing.Size(909, 407);
            this.Load += new System.EventHandler(this.Licencias_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        internal System.Windows.Forms.Button btnActivacioManual;
        internal System.Windows.Forms.Button btncomprar;
        internal System.Windows.Forms.Button btnCopiar;
        internal System.Windows.Forms.Panel panel6;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.TextBox txtSerial;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label1;
        public System.Windows.Forms.Button btnCerrar;
    }
}
