﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RestCsharp.Logica
{
    public class Limpresoras
    {
        public int Id_impresora { get; set; }
        public int Id_Areas_de_Impresion { get; set; }
        public string Impresora { get; set; }
        public int Idcaja { get; set; }

    }
}
