﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RestCsharp.Logica
{
    public class Lareasimpresion
    {
        public int Id_area { get; set; }
        public string Area { get; set; }
        public string Codigo { get; set; }

    }
}
