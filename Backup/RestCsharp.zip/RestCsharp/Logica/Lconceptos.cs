﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RestCsharp.Logica
{
    public class Lconceptos
    {
        public int idconcepto { get; set; }
        public string descripcion { get; set; }

    }
}
