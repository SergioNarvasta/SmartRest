﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RestCsharp.Logica
{
    public class Lmarcan
    {
        public string S { get; set; }
        public string F { get; set; }
        public string E { get; set; }
        public string FA { get; set; }
    }
}
