﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RestCsharp.Logica
{
   public  class LiniciosSesion
    {
        public int Idsesion { get; set; }
        public int IdCaja { get; set; }
        public int IdUsuario { get; set; }
    }
}
