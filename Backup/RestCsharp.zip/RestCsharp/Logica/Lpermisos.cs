﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RestCsharp.Logica
{
  public  class Lpermisos
    {
        public int IdPermiso { get; set; }
        public int IdModulo { get; set; }
        public int IdUsuario { get; set; }

    }
}
