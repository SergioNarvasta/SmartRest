﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RestCsharp.Logica
{
   public  class Lmodulos
    {
        public int IdModulo { get; set; }
        public string Modulo { get; set; }
    }
}
