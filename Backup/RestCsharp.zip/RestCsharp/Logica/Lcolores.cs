﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RestCsharp.Logica
{
   public class Lcolores
    {
        public int Idcolor { get; set; }
        public string colorhtml { get; set; }
    }
}
