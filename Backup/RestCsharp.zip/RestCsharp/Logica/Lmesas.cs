﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RestCsharp.Logica
{
  public   class Lmesas
    {
        public int Id_mesa { get; set; }
        public string Mesa { get; set; }
        public int Id_salon { get; set; }
        public string Estado_de_vida { get; set; }
        public string Estado_de_Disponibilidad { get; set; }
    }
}
