﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RestCsharp.Logica
{
   public class Lserializacion
    {
        public int Id_serializacion { get; set; }
        public string Serie { get; set; }
        public string Cantidad_de_numeros { get; set; }
        public int numerofin { get; set; }
        public string Tipo { get; set; }
        public string Por_defecto { get; set; }
        public string Envioinmediato { get; set; }

    }
}
